"use strict";
cc._RF.push(module, 'ed7dakMh5xHTr5n8dEFcWgu', 'use_reversed_rotateBy');
// migration/use_reversed_rotateBy.js

"use strict";

cc.RotateBy._reverse = true;

cc._RF.pop();