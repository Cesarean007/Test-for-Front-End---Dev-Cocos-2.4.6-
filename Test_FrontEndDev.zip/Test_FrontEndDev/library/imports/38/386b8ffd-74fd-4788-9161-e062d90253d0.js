"use strict";
cc._RF.push(module, '386b8/9dP1HiJFh4GLZAlPQ', 'NetworkLog');
// scripts/NetworkLog.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NetworkLog = void 0;
var NetworkLog = /** @class */ (function () {
    function NetworkLog() {
    }
    /**
     * Writes a reel-rolling result to history in local storage.
     * @param result The result to write.
     */
    NetworkLog.appendResult = function (result) {
        var xhr = new XMLHttpRequest();
        var url = "https://slot-test-server2.firebaseapp.com/result";
        xhr.open("POST", url, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.setRequestHeader("Accept", "*/*");
        // xhr.onreadystatechange = function () {
        //     if (xhr.readyState === 4 && xhr.status === 200) {
        //     }
        // };
        xhr.send(JSON.stringify(result));
    };
    return NetworkLog;
}());
exports.NetworkLog = NetworkLog;

cc._RF.pop();