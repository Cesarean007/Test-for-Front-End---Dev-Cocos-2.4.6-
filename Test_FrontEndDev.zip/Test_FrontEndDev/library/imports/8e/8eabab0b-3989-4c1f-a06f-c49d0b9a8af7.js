"use strict";
cc._RF.push(module, '8eabasLOYlMH6BvxJ0Lmor3', 'Dice');
// scripts/Dice.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Dice = void 0;
var Dice = /** @class */ (function () {
    function Dice() {
    }
    /**
     * Returns a random integer between min (inclusive) and max (exclusive).
     * @param min Minimum value (inclusive).
     * @param max Maximum value (exclusive).
     */
    Dice.randomInt = function (min, max) {
        return Math.floor(Math.random() * (max - min)) + min;
    };
    /**
     * Returns a random integer between 0 (inclusive) and max (exclusive).
     * @param max Maximum value (exclusive).
     */
    Dice.roll = function (max) {
        return Dice.randomInt(0, max);
    };
    /**
     * Returns a random integer between 0 (inclusive) and max (exclusive) that is different from a specific value.
     * @param max Maximum value (exclusive).
     * @param except Any result except by this number.
     */
    Dice.rollDifferent = function (max, except) {
        var roll = Dice.roll(max - 1);
        return (roll < except) ? roll : roll + 1;
    };
    return Dice;
}());
exports.Dice = Dice;

cc._RF.pop();