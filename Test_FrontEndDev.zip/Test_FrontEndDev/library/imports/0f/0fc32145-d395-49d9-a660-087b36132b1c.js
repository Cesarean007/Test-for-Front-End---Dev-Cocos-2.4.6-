"use strict";
cc._RF.push(module, '0fc32FF05VJ2aZgCHs2Eysc', 'use_v2.1-2.2.1_cc.Toggle_event');
// migration/use_v2.1-2.2.1_cc.Toggle_event.js

"use strict";

if (cc.Toggle) {
  cc.Toggle._triggerEventInScript_isChecked = true;
}

cc._RF.pop();