"use strict";
cc._RF.push(module, '6abe1dbO/dPpKL6YIjM54sl', 'SlotRoller');
// scripts/slots/SlotRoller.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SlotRoller = void 0;
var Dice_1 = require("../Dice");
/**
 * Rolls the reels.
 */
var SlotRoller = /** @class */ (function () {
    function SlotRoller() {
    }
    // ====================================================
    // Public
    // ====================================================
    /**
     * Returns results based on a predefined probability list.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.roll = function (tileCount, reelCount) {
        var result = {
            reels: [],
            equalLines: [],
            equalTile: 0
        };
        var roll = Dice_1.Dice.roll(100);
        if (roll < SlotRoller.ROLL_ALL_EQUAL) {
            result = SlotRoller.allLinesResult(tileCount, reelCount);
        }
        else if (roll < SlotRoller.ROLL_TWO_LINES) {
            result = SlotRoller.twoLinesResult(tileCount, reelCount);
        }
        else if (roll < SlotRoller.ROLL_SINGLE_LINE) {
            result = SlotRoller.singleLineResult(tileCount, reelCount);
        }
        else {
            result = SlotRoller.noLinesResult(tileCount, reelCount);
        }
        return result;
    };
    // ====================================================
    // Private
    // ====================================================
    /**
     * Creates an empty matrix of a given size.
     * @param reelCount Column count.
     */
    SlotRoller.createEmptyMatrix = function (reelCount) {
        var result = [];
        for (var j = 0; j < reelCount; j++) {
            result.push([]);
        }
        return result;
    };
    /**
     * Generates a line containing at least one different tile.
     * @param reelCount Line length.
     */
    SlotRoller.createUnequalLine = function (tileCount, reelCount) {
        var result = [];
        var uniqueValues = [];
        for (var j = 0; j < reelCount; ++j) {
            result[j] = Dice_1.Dice.roll(tileCount);
            if (!uniqueValues.includes(result[j])) {
                uniqueValues.push(result[j]);
            }
        }
        if (uniqueValues.length <= 1) {
            var differentPosition = Dice_1.Dice.roll(length);
            var differentValue = Dice_1.Dice.rollDifferent(reelCount, uniqueValues[0]);
            result[differentPosition] = differentValue;
        }
        return result;
    };
    /**
     * Returns a result according to the following condition:
     *  - All lines are SOLELY composed by THE SAME tile.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.allLinesResult = function (tileCount, reelCount) {
        var result = {
            reels: SlotRoller.createEmptyMatrix(reelCount),
            equalLines: [],
            equalTile: Dice_1.Dice.roll(tileCount)
        };
        // Saves equal lines
        for (var i = 0; i < this.REEL_LENGTH; ++i) {
            result.equalLines.push(i);
        }
        SlotRoller.populateMatrix(result, tileCount, reelCount);
        return result;
    };
    /**
     * Returns a result according to the following condition:
     *  - All lines contain AT LEAST ONE different tile.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.noLinesResult = function (tileCount, reelCount) {
        var result = {
            reels: SlotRoller.createEmptyMatrix(reelCount),
            equalLines: [],
            equalTile: -1
        };
        SlotRoller.populateMatrix(result, tileCount, reelCount);
        return result;
    };
    /**
     * Returns a result according to the following condition:
     *  - There is one line that contains AT LEAST ONE different tile.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.twoLinesResult = function (tileCount, reelCount) {
        var result = {
            reels: SlotRoller.createEmptyMatrix(reelCount),
            equalLines: [],
            equalTile: Dice_1.Dice.roll(tileCount)
        };
        // Saves equal lines
        var differentLine = Dice_1.Dice.roll(this.REEL_LENGTH);
        for (var i = 0; i < this.REEL_LENGTH; i++) {
            if (i != differentLine) {
                result.equalLines.push(i);
            }
        }
        SlotRoller.populateMatrix(result, tileCount, reelCount);
        return result;
    };
    /**
     * Returns a result according to the following condition:
     * - There is ONLY ONE line whose tiles are all the same.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.singleLineResult = function (tileCount, reelCount) {
        var result = {
            reels: SlotRoller.createEmptyMatrix(reelCount),
            equalLines: [Dice_1.Dice.roll(this.REEL_LENGTH)],
            equalTile: Dice_1.Dice.roll(tileCount)
        };
        SlotRoller.populateMatrix(result, tileCount, reelCount);
        return result;
    };
    /**
     * Populates a tile matrix from an IResult interface.
     * @param result Contains the matrix to edit.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.populateMatrix = function (result, tileCount, reelCount) {
        for (var i = 0; i < this.REEL_LENGTH; ++i) {
            if (result.equalLines.includes(i)) {
                for (var j = 0; j < reelCount; ++j) {
                    result.reels[j][i] = result.equalTile;
                }
            }
            else {
                var unequalLine = this.createUnequalLine(tileCount, reelCount);
                for (var j = 0; j < reelCount; ++j) {
                    result.reels[j][i] = unequalLine[j];
                }
            }
        }
    };
    SlotRoller.ROLL_ALL_EQUAL = 7;
    SlotRoller.ROLL_TWO_LINES = 10 + SlotRoller.ROLL_ALL_EQUAL; // 17
    SlotRoller.ROLL_SINGLE_LINE = 33 + SlotRoller.ROLL_TWO_LINES; // 50
    SlotRoller.REEL_LENGTH = 3;
    return SlotRoller;
}());
exports.SlotRoller = SlotRoller;

cc._RF.pop();