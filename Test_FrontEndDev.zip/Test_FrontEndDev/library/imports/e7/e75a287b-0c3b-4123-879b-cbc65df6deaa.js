"use strict";
cc._RF.push(module, 'e75a2h7DDtBI4eby8Zd9t6q', 'IResult');
// scripts/slots/IResult.ts



cc._RF.pop();