interface IResult {
    reels: Array<Array<number>>,
    equalLines: Array<number>,
    equalTile: number
}