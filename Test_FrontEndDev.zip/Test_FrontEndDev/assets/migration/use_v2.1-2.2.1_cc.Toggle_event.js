if (cc.Toggle) {
    cc.Toggle._triggerEventInScript_isChecked = true;
}
