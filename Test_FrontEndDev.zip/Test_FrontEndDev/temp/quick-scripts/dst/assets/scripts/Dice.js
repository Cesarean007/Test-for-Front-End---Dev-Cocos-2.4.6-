
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Dice.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8eabasLOYlMH6BvxJ0Lmor3', 'Dice');
// scripts/Dice.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Dice = void 0;
var Dice = /** @class */ (function () {
    function Dice() {
    }
    /**
     * Returns a random integer between min (inclusive) and max (exclusive).
     * @param min Minimum value (inclusive).
     * @param max Maximum value (exclusive).
     */
    Dice.randomInt = function (min, max) {
        return Math.floor(Math.random() * (max - min)) + min;
    };
    /**
     * Returns a random integer between 0 (inclusive) and max (exclusive).
     * @param max Maximum value (exclusive).
     */
    Dice.roll = function (max) {
        return Dice.randomInt(0, max);
    };
    /**
     * Returns a random integer between 0 (inclusive) and max (exclusive) that is different from a specific value.
     * @param max Maximum value (exclusive).
     * @param except Any result except by this number.
     */
    Dice.rollDifferent = function (max, except) {
        var roll = Dice.roll(max - 1);
        return (roll < except) ? roll : roll + 1;
    };
    return Dice;
}());
exports.Dice = Dice;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcRGljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtJQUFBO0lBMkJBLENBQUM7SUExQkc7Ozs7T0FJRztJQUNXLGNBQVMsR0FBdkIsVUFBeUIsR0FBVyxFQUFFLEdBQVc7UUFDN0MsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUN6RCxDQUFDO0lBRUQ7OztPQUdHO0lBQ1csU0FBSSxHQUFsQixVQUFvQixHQUFXO1FBQzNCLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDbEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDVyxrQkFBYSxHQUEzQixVQUE2QixHQUFXLEVBQUUsTUFBYztRQUNwRCxJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsQ0FBQztRQUM5QixPQUFPLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNMLFdBQUM7QUFBRCxDQTNCQSxBQTJCQyxJQUFBO0FBM0JxQixvQkFBSSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBhYnN0cmFjdCBjbGFzcyBEaWNlIHtcbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGEgcmFuZG9tIGludGVnZXIgYmV0d2VlbiBtaW4gKGluY2x1c2l2ZSkgYW5kIG1heCAoZXhjbHVzaXZlKS5cbiAgICAgKiBAcGFyYW0gbWluIE1pbmltdW0gdmFsdWUgKGluY2x1c2l2ZSkuXG4gICAgICogQHBhcmFtIG1heCBNYXhpbXVtIHZhbHVlIChleGNsdXNpdmUpLlxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgcmFuZG9tSW50IChtaW46IG51bWJlciwgbWF4OiBudW1iZXIpIHtcbiAgICAgICAgcmV0dXJuIE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIChtYXggLSBtaW4pKSArIG1pbjtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGEgcmFuZG9tIGludGVnZXIgYmV0d2VlbiAwIChpbmNsdXNpdmUpIGFuZCBtYXggKGV4Y2x1c2l2ZSkuXG4gICAgICogQHBhcmFtIG1heCBNYXhpbXVtIHZhbHVlIChleGNsdXNpdmUpLlxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgcm9sbCAobWF4OiBudW1iZXIpIHtcbiAgICAgICAgcmV0dXJuIERpY2UucmFuZG9tSW50KDAsIG1heCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyBhIHJhbmRvbSBpbnRlZ2VyIGJldHdlZW4gMCAoaW5jbHVzaXZlKSBhbmQgbWF4IChleGNsdXNpdmUpIHRoYXQgaXMgZGlmZmVyZW50IGZyb20gYSBzcGVjaWZpYyB2YWx1ZS5cbiAgICAgKiBAcGFyYW0gbWF4IE1heGltdW0gdmFsdWUgKGV4Y2x1c2l2ZSkuXG4gICAgICogQHBhcmFtIGV4Y2VwdCBBbnkgcmVzdWx0IGV4Y2VwdCBieSB0aGlzIG51bWJlci5cbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHJvbGxEaWZmZXJlbnQgKG1heDogbnVtYmVyLCBleGNlcHQ6IG51bWJlcikge1xuICAgICAgICBjb25zdCByb2xsID0gRGljZS5yb2xsKG1heC0xKTtcbiAgICAgICAgcmV0dXJuIChyb2xsIDwgZXhjZXB0KSA/IHJvbGwgOiByb2xsICsgMTtcbiAgICB9XG59Il19