
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/NetworkLog.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '386b8/9dP1HiJFh4GLZAlPQ', 'NetworkLog');
// scripts/NetworkLog.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NetworkLog = void 0;
var NetworkLog = /** @class */ (function () {
    function NetworkLog() {
    }
    /**
     * Writes a reel-rolling result to history in local storage.
     * @param result The result to write.
     */
    NetworkLog.appendResult = function (result) {
        var xhr = new XMLHttpRequest();
        var url = "https://slot-test-server2.firebaseapp.com/result";
        xhr.open("POST", url, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.setRequestHeader("Accept", "*/*");
        // xhr.onreadystatechange = function () {
        //     if (xhr.readyState === 4 && xhr.status === 200) {
        //     }
        // };
        xhr.send(JSON.stringify(result));
    };
    return NetworkLog;
}());
exports.NetworkLog = NetworkLog;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcTmV0d29ya0xvZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtJQUFBO0lBb0JBLENBQUM7SUFsQkc7OztPQUdHO0lBQ1csdUJBQVksR0FBMUIsVUFBNEIsTUFBZTtRQUN2QyxJQUFJLEdBQUcsR0FBRyxJQUFJLGNBQWMsRUFBRSxDQUFDO1FBQy9CLElBQUksR0FBRyxHQUFHLGtEQUFrRCxDQUFDO1FBQzdELEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUM1QixHQUFHLENBQUMsZ0JBQWdCLENBQUMsY0FBYyxFQUFFLGtCQUFrQixDQUFDLENBQUM7UUFDekQsR0FBRyxDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN0Qyx5Q0FBeUM7UUFDekMsd0RBQXdEO1FBRXhELFFBQVE7UUFDUixLQUFLO1FBQ0wsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVMLGlCQUFDO0FBQUQsQ0FwQkEsQUFvQkMsSUFBQTtBQXBCcUIsZ0NBQVUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgYWJzdHJhY3QgY2xhc3MgTmV0d29ya0xvZyB7XG4gICAgXG4gICAgLyoqXG4gICAgICogV3JpdGVzIGEgcmVlbC1yb2xsaW5nIHJlc3VsdCB0byBoaXN0b3J5IGluIGxvY2FsIHN0b3JhZ2UuXG4gICAgICogQHBhcmFtIHJlc3VsdCBUaGUgcmVzdWx0IHRvIHdyaXRlLlxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgYXBwZW5kUmVzdWx0IChyZXN1bHQ6IElSZXN1bHQpIHtcbiAgICAgICAgdmFyIHhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuICAgICAgICB2YXIgdXJsID0gXCJodHRwczovL3Nsb3QtdGVzdC1zZXJ2ZXIyLmZpcmViYXNlYXBwLmNvbS9yZXN1bHRcIjtcbiAgICAgICAgeGhyLm9wZW4oXCJQT1NUXCIsIHVybCwgdHJ1ZSk7XG4gICAgICAgIHhoci5zZXRSZXF1ZXN0SGVhZGVyKFwiQ29udGVudC1UeXBlXCIsIFwiYXBwbGljYXRpb24vanNvblwiKTtcbiAgICAgICAgeGhyLnNldFJlcXVlc3RIZWFkZXIoXCJBY2NlcHRcIiwgXCIqLypcIik7XG4gICAgICAgIC8vIHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIC8vICAgICBpZiAoeGhyLnJlYWR5U3RhdGUgPT09IDQgJiYgeGhyLnN0YXR1cyA9PT0gMjAwKSB7XG5cbiAgICAgICAgLy8gICAgIH1cbiAgICAgICAgLy8gfTtcbiAgICAgICAgeGhyLnNlbmQoSlNPTi5zdHJpbmdpZnkocmVzdWx0KSk7XG4gICAgfVxuXG59XG4iXX0=