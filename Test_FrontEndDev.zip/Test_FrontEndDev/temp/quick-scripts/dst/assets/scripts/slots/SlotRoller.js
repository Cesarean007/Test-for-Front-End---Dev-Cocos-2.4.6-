
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/slots/SlotRoller.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6abe1dbO/dPpKL6YIjM54sl', 'SlotRoller');
// scripts/slots/SlotRoller.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SlotRoller = void 0;
var Dice_1 = require("../Dice");
/**
 * Rolls the reels.
 */
var SlotRoller = /** @class */ (function () {
    function SlotRoller() {
    }
    // ====================================================
    // Public
    // ====================================================
    /**
     * Returns results based on a predefined probability list.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.roll = function (tileCount, reelCount) {
        var result = {
            reels: [],
            equalLines: [],
            equalTile: 0
        };
        var roll = Dice_1.Dice.roll(100);
        if (roll < SlotRoller.ROLL_ALL_EQUAL) {
            result = SlotRoller.allLinesResult(tileCount, reelCount);
        }
        else if (roll < SlotRoller.ROLL_TWO_LINES) {
            result = SlotRoller.twoLinesResult(tileCount, reelCount);
        }
        else if (roll < SlotRoller.ROLL_SINGLE_LINE) {
            result = SlotRoller.singleLineResult(tileCount, reelCount);
        }
        else {
            result = SlotRoller.noLinesResult(tileCount, reelCount);
        }
        return result;
    };
    // ====================================================
    // Private
    // ====================================================
    /**
     * Creates an empty matrix of a given size.
     * @param reelCount Column count.
     */
    SlotRoller.createEmptyMatrix = function (reelCount) {
        var result = [];
        for (var j = 0; j < reelCount; j++) {
            result.push([]);
        }
        return result;
    };
    /**
     * Generates a line containing at least one different tile.
     * @param reelCount Line length.
     */
    SlotRoller.createUnequalLine = function (tileCount, reelCount) {
        var result = [];
        var uniqueValues = [];
        for (var j = 0; j < reelCount; ++j) {
            result[j] = Dice_1.Dice.roll(tileCount);
            if (!uniqueValues.includes(result[j])) {
                uniqueValues.push(result[j]);
            }
        }
        if (uniqueValues.length <= 1) {
            var differentPosition = Dice_1.Dice.roll(length);
            var differentValue = Dice_1.Dice.rollDifferent(reelCount, uniqueValues[0]);
            result[differentPosition] = differentValue;
        }
        return result;
    };
    /**
     * Returns a result according to the following condition:
     *  - All lines are SOLELY composed by THE SAME tile.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.allLinesResult = function (tileCount, reelCount) {
        var result = {
            reels: SlotRoller.createEmptyMatrix(reelCount),
            equalLines: [],
            equalTile: Dice_1.Dice.roll(tileCount)
        };
        // Saves equal lines
        for (var i = 0; i < this.REEL_LENGTH; ++i) {
            result.equalLines.push(i);
        }
        SlotRoller.populateMatrix(result, tileCount, reelCount);
        return result;
    };
    /**
     * Returns a result according to the following condition:
     *  - All lines contain AT LEAST ONE different tile.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.noLinesResult = function (tileCount, reelCount) {
        var result = {
            reels: SlotRoller.createEmptyMatrix(reelCount),
            equalLines: [],
            equalTile: -1
        };
        SlotRoller.populateMatrix(result, tileCount, reelCount);
        return result;
    };
    /**
     * Returns a result according to the following condition:
     *  - There is one line that contains AT LEAST ONE different tile.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.twoLinesResult = function (tileCount, reelCount) {
        var result = {
            reels: SlotRoller.createEmptyMatrix(reelCount),
            equalLines: [],
            equalTile: Dice_1.Dice.roll(tileCount)
        };
        // Saves equal lines
        var differentLine = Dice_1.Dice.roll(this.REEL_LENGTH);
        for (var i = 0; i < this.REEL_LENGTH; i++) {
            if (i != differentLine) {
                result.equalLines.push(i);
            }
        }
        SlotRoller.populateMatrix(result, tileCount, reelCount);
        return result;
    };
    /**
     * Returns a result according to the following condition:
     * - There is ONLY ONE line whose tiles are all the same.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.singleLineResult = function (tileCount, reelCount) {
        var result = {
            reels: SlotRoller.createEmptyMatrix(reelCount),
            equalLines: [Dice_1.Dice.roll(this.REEL_LENGTH)],
            equalTile: Dice_1.Dice.roll(tileCount)
        };
        SlotRoller.populateMatrix(result, tileCount, reelCount);
        return result;
    };
    /**
     * Populates a tile matrix from an IResult interface.
     * @param result Contains the matrix to edit.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.populateMatrix = function (result, tileCount, reelCount) {
        for (var i = 0; i < this.REEL_LENGTH; ++i) {
            if (result.equalLines.includes(i)) {
                for (var j = 0; j < reelCount; ++j) {
                    result.reels[j][i] = result.equalTile;
                }
            }
            else {
                var unequalLine = this.createUnequalLine(tileCount, reelCount);
                for (var j = 0; j < reelCount; ++j) {
                    result.reels[j][i] = unequalLine[j];
                }
            }
        }
    };
    SlotRoller.ROLL_ALL_EQUAL = 7;
    SlotRoller.ROLL_TWO_LINES = 10 + SlotRoller.ROLL_ALL_EQUAL; // 17
    SlotRoller.ROLL_SINGLE_LINE = 33 + SlotRoller.ROLL_TWO_LINES; // 50
    SlotRoller.REEL_LENGTH = 3;
    return SlotRoller;
}());
exports.SlotRoller = SlotRoller;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcc2xvdHNcXFNsb3RSb2xsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0NBQStCO0FBRS9COztHQUVHO0FBQ0g7SUFBQTtJQTJMQSxDQUFDO0lBbkxHLHVEQUF1RDtJQUN2RCxTQUFTO0lBQ1QsdURBQXVEO0lBQ3ZEOzs7O09BSUc7SUFDVyxlQUFJLEdBQWxCLFVBQW1CLFNBQWlCLEVBQUUsU0FBaUI7UUFDbkQsSUFBSSxNQUFNLEdBQUc7WUFDVCxLQUFLLEVBQUUsRUFBRTtZQUNULFVBQVUsRUFBRSxFQUFFO1lBQ2QsU0FBUyxFQUFFLENBQUM7U0FDZixDQUFDO1FBRUYsSUFBTSxJQUFJLEdBQUcsV0FBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM1QixJQUFJLElBQUksR0FBRyxVQUFVLENBQUMsY0FBYyxFQUFFO1lBQ2xDLE1BQU0sR0FBRyxVQUFVLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQztTQUM1RDthQUNJLElBQUksSUFBSSxHQUFHLFVBQVUsQ0FBQyxjQUFjLEVBQUU7WUFDdkMsTUFBTSxHQUFHLFVBQVUsQ0FBQyxjQUFjLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1NBQzVEO2FBQ0ksSUFBSSxJQUFJLEdBQUcsVUFBVSxDQUFDLGdCQUFnQixFQUFFO1lBQ3pDLE1BQU0sR0FBRyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1NBQzlEO2FBQ0k7WUFDRCxNQUFNLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7U0FDM0Q7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBR0QsdURBQXVEO0lBQ3ZELFVBQVU7SUFDVix1REFBdUQ7SUFDdkQ7OztPQUdHO0lBQ1ksNEJBQWlCLEdBQWhDLFVBQWlDLFNBQWlCO1FBQzlDLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQztRQUNoQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2hDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDbkI7UUFDRCxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBRUQ7OztPQUdHO0lBQ1ksNEJBQWlCLEdBQWhDLFVBQWlDLFNBQWlCLEVBQUUsU0FBaUI7UUFDakUsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2hCLElBQUksWUFBWSxHQUFHLEVBQUUsQ0FBQztRQUV0QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ2hDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxXQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ2pDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNuQyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2hDO1NBQ0o7UUFFRCxJQUFHLFlBQVksQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO1lBQ3pCLElBQU0saUJBQWlCLEdBQUcsV0FBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUM1QyxJQUFNLGNBQWMsR0FBRyxXQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN0RSxNQUFNLENBQUMsaUJBQWlCLENBQUMsR0FBRyxjQUFjLENBQUM7U0FDOUM7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDWSx5QkFBYyxHQUE3QixVQUE4QixTQUFpQixFQUFFLFNBQWlCO1FBQzlELElBQUksTUFBTSxHQUFHO1lBQ1QsS0FBSyxFQUFFLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUM7WUFDOUMsVUFBVSxFQUFFLEVBQUU7WUFDZCxTQUFTLEVBQUUsV0FBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7U0FDbEMsQ0FBQztRQUVGLG9CQUFvQjtRQUNwQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUN2QyxNQUFNLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM3QjtRQUVELFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUV4RCxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDWSx3QkFBYSxHQUE1QixVQUE2QixTQUFpQixFQUFFLFNBQWlCO1FBQzdELElBQUksTUFBTSxHQUFHO1lBQ1QsS0FBSyxFQUFFLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUM7WUFDOUMsVUFBVSxFQUFFLEVBQUU7WUFDZCxTQUFTLEVBQUUsQ0FBQyxDQUFDO1NBQ2hCLENBQUM7UUFFRixVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFFeEQsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ1kseUJBQWMsR0FBN0IsVUFBOEIsU0FBaUIsRUFBRSxTQUFpQjtRQUM5RCxJQUFJLE1BQU0sR0FBRztZQUNULEtBQUssRUFBRSxVQUFVLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDO1lBQzlDLFVBQVUsRUFBRSxFQUFFO1lBQ2QsU0FBUyxFQUFFLFdBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1NBQ2xDLENBQUM7UUFFRixvQkFBb0I7UUFDcEIsSUFBTSxhQUFhLEdBQUcsV0FBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDbEQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDdkMsSUFBSSxDQUFDLElBQUksYUFBYSxFQUFFO2dCQUNwQixNQUFNLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM3QjtTQUNKO1FBRUQsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBRXhELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNZLDJCQUFnQixHQUEvQixVQUFnQyxTQUFpQixFQUFFLFNBQWlCO1FBQ2hFLElBQUksTUFBTSxHQUFHO1lBQ1QsS0FBSyxFQUFFLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUM7WUFDOUMsVUFBVSxFQUFFLENBQUMsV0FBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDekMsU0FBUyxFQUFFLFdBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1NBQ2xDLENBQUM7UUFFRixVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFFeEQsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ1kseUJBQWMsR0FBN0IsVUFBOEIsTUFBZSxFQUFFLFNBQWlCLEVBQUUsU0FBaUI7UUFDL0UsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDdkMsSUFBSSxNQUFNLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDL0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDaEMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDO2lCQUN6QzthQUNKO2lCQUNJO2dCQUNELElBQU0sV0FBVyxHQUFrQixJQUFJLENBQUMsaUJBQWlCLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUNoRixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUNoQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDdkM7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQXZMZSx5QkFBYyxHQUFXLENBQUMsQ0FBQztJQUMzQix5QkFBYyxHQUFXLEVBQUUsR0FBRyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUssS0FBSztJQUNsRSwyQkFBZ0IsR0FBVyxFQUFFLEdBQUcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFHLEtBQUs7SUFFbEUsc0JBQVcsR0FBVyxDQUFDLENBQUE7SUFxTDNDLGlCQUFDO0NBM0xELEFBMkxDLElBQUE7QUEzTFksZ0NBQVUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaWNlIH0gZnJvbSBcIi4uL0RpY2VcIjtcblxuLyoqXG4gKiBSb2xscyB0aGUgcmVlbHMuXG4gKi9cbmV4cG9ydCBjbGFzcyBTbG90Um9sbGVyIHtcblxuICAgIHN0YXRpYyByZWFkb25seSBST0xMX0FMTF9FUVVBTDogbnVtYmVyID0gNztcbiAgICBzdGF0aWMgcmVhZG9ubHkgUk9MTF9UV09fTElORVM6IG51bWJlciA9IDEwICsgU2xvdFJvbGxlci5ST0xMX0FMTF9FUVVBTDsgICAgIC8vIDE3XG4gICAgc3RhdGljIHJlYWRvbmx5IFJPTExfU0lOR0xFX0xJTkU6IG51bWJlciA9IDMzICsgU2xvdFJvbGxlci5ST0xMX1RXT19MSU5FUzsgICAvLyA1MFxuXG4gICAgc3RhdGljIHJlYWRvbmx5IFJFRUxfTEVOR1RIOiBudW1iZXIgPSAzXG5cbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgLy8gUHVibGljXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIC8qKlxuICAgICAqIFJldHVybnMgcmVzdWx0cyBiYXNlZCBvbiBhIHByZWRlZmluZWQgcHJvYmFiaWxpdHkgbGlzdC5cbiAgICAgKiBAcGFyYW0gdGlsZUNvdW50IEFtb3VudCBvZiB1bmlxdWUgdGlsZSB0ZXh0dXJlcy5cbiAgICAgKiBAcGFyYW0gcmVlbENvdW50IEFtb3VudCBvZiB2ZXJ0aWNhbCByb2xsaW5nIGxpbmVzIGluIHRoaXMgbWFjaGluZS5cbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHJvbGwodGlsZUNvdW50OiBudW1iZXIsIHJlZWxDb3VudDogbnVtYmVyKTogSVJlc3VsdCB7XG4gICAgICAgIHZhciByZXN1bHQgPSB7XG4gICAgICAgICAgICByZWVsczogW10sXG4gICAgICAgICAgICBlcXVhbExpbmVzOiBbXSxcbiAgICAgICAgICAgIGVxdWFsVGlsZTogMFxuICAgICAgICB9O1xuICAgIFxuICAgICAgICBjb25zdCByb2xsID0gRGljZS5yb2xsKDEwMCk7XG4gICAgICAgIGlmIChyb2xsIDwgU2xvdFJvbGxlci5ST0xMX0FMTF9FUVVBTCkge1xuICAgICAgICAgICAgcmVzdWx0ID0gU2xvdFJvbGxlci5hbGxMaW5lc1Jlc3VsdCh0aWxlQ291bnQsIHJlZWxDb3VudCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAocm9sbCA8IFNsb3RSb2xsZXIuUk9MTF9UV09fTElORVMpIHtcbiAgICAgICAgICAgIHJlc3VsdCA9IFNsb3RSb2xsZXIudHdvTGluZXNSZXN1bHQodGlsZUNvdW50LCByZWVsQ291bnQpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHJvbGwgPCBTbG90Um9sbGVyLlJPTExfU0lOR0xFX0xJTkUpIHtcbiAgICAgICAgICAgIHJlc3VsdCA9IFNsb3RSb2xsZXIuc2luZ2xlTGluZVJlc3VsdCh0aWxlQ291bnQsIHJlZWxDb3VudCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICByZXN1bHQgPSBTbG90Um9sbGVyLm5vTGluZXNSZXN1bHQodGlsZUNvdW50LCByZWVsQ291bnQpO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cblxuXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIC8vIFByaXZhdGVcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBhbiBlbXB0eSBtYXRyaXggb2YgYSBnaXZlbiBzaXplLlxuICAgICAqIEBwYXJhbSByZWVsQ291bnQgQ29sdW1uIGNvdW50LlxuICAgICAqL1xuICAgIHByaXZhdGUgc3RhdGljIGNyZWF0ZUVtcHR5TWF0cml4KHJlZWxDb3VudDogbnVtYmVyKTogQXJyYXk8QXJyYXk8bnVtYmVyPj4ge1xuICAgICAgICB2YXIgcmVzdWx0ID0gW107XG4gICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgcmVlbENvdW50OyBqKyspIHtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKFtdKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdlbmVyYXRlcyBhIGxpbmUgY29udGFpbmluZyBhdCBsZWFzdCBvbmUgZGlmZmVyZW50IHRpbGUuXG4gICAgICogQHBhcmFtIHJlZWxDb3VudCBMaW5lIGxlbmd0aC5cbiAgICAgKi9cbiAgICBwcml2YXRlIHN0YXRpYyBjcmVhdGVVbmVxdWFsTGluZSh0aWxlQ291bnQ6IG51bWJlciwgcmVlbENvdW50OiBudW1iZXIpOiBBcnJheTxudW1iZXI+IHtcbiAgICAgICAgdmFyIHJlc3VsdCA9IFtdO1xuICAgICAgICB2YXIgdW5pcXVlVmFsdWVzID0gW107XG5cbiAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCByZWVsQ291bnQ7ICsraikge1xuICAgICAgICAgICAgcmVzdWx0W2pdID0gRGljZS5yb2xsKHRpbGVDb3VudCk7XG4gICAgICAgICAgICBpZiAoIXVuaXF1ZVZhbHVlcy5pbmNsdWRlcyhyZXN1bHRbal0pKSB7XG4gICAgICAgICAgICAgICAgdW5pcXVlVmFsdWVzLnB1c2gocmVzdWx0W2pdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmKHVuaXF1ZVZhbHVlcy5sZW5ndGggPD0gMSkge1xuICAgICAgICAgICAgY29uc3QgZGlmZmVyZW50UG9zaXRpb24gPSBEaWNlLnJvbGwobGVuZ3RoKTtcbiAgICAgICAgICAgIGNvbnN0IGRpZmZlcmVudFZhbHVlID0gRGljZS5yb2xsRGlmZmVyZW50KHJlZWxDb3VudCwgdW5pcXVlVmFsdWVzWzBdKTtcbiAgICAgICAgICAgIHJlc3VsdFtkaWZmZXJlbnRQb3NpdGlvbl0gPSBkaWZmZXJlbnRWYWx1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyBhIHJlc3VsdCBhY2NvcmRpbmcgdG8gdGhlIGZvbGxvd2luZyBjb25kaXRpb246XG4gICAgICogIC0gQWxsIGxpbmVzIGFyZSBTT0xFTFkgY29tcG9zZWQgYnkgVEhFIFNBTUUgdGlsZS5cbiAgICAgKiBAcGFyYW0gdGlsZUNvdW50IEFtb3VudCBvZiB1bmlxdWUgdGlsZSB0ZXh0dXJlcy5cbiAgICAgKiBAcGFyYW0gcmVlbENvdW50IEFtb3VudCBvZiB2ZXJ0aWNhbCByb2xsaW5nIGxpbmVzIGluIHRoaXMgbWFjaGluZS5cbiAgICAgKi9cbiAgICBwcml2YXRlIHN0YXRpYyBhbGxMaW5lc1Jlc3VsdCh0aWxlQ291bnQ6IG51bWJlciwgcmVlbENvdW50OiBudW1iZXIpOiBJUmVzdWx0IHtcbiAgICAgICAgdmFyIHJlc3VsdCA9IHtcbiAgICAgICAgICAgIHJlZWxzOiBTbG90Um9sbGVyLmNyZWF0ZUVtcHR5TWF0cml4KHJlZWxDb3VudCksXG4gICAgICAgICAgICBlcXVhbExpbmVzOiBbXSxcbiAgICAgICAgICAgIGVxdWFsVGlsZTogRGljZS5yb2xsKHRpbGVDb3VudClcbiAgICAgICAgfTtcbiAgICAgICAgXG4gICAgICAgIC8vIFNhdmVzIGVxdWFsIGxpbmVzXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5SRUVMX0xFTkdUSDsgKytpKSB7XG4gICAgICAgICAgICByZXN1bHQuZXF1YWxMaW5lcy5wdXNoKGkpO1xuICAgICAgICB9XG5cbiAgICAgICAgU2xvdFJvbGxlci5wb3B1bGF0ZU1hdHJpeChyZXN1bHQsIHRpbGVDb3VudCwgcmVlbENvdW50KTtcblxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgYSByZXN1bHQgYWNjb3JkaW5nIHRvIHRoZSBmb2xsb3dpbmcgY29uZGl0aW9uOlxuICAgICAqICAtIEFsbCBsaW5lcyBjb250YWluIEFUIExFQVNUIE9ORSBkaWZmZXJlbnQgdGlsZS5cbiAgICAgKiBAcGFyYW0gdGlsZUNvdW50IEFtb3VudCBvZiB1bmlxdWUgdGlsZSB0ZXh0dXJlcy5cbiAgICAgKiBAcGFyYW0gcmVlbENvdW50IEFtb3VudCBvZiB2ZXJ0aWNhbCByb2xsaW5nIGxpbmVzIGluIHRoaXMgbWFjaGluZS5cbiAgICAgKi9cbiAgICBwcml2YXRlIHN0YXRpYyBub0xpbmVzUmVzdWx0KHRpbGVDb3VudDogbnVtYmVyLCByZWVsQ291bnQ6IG51bWJlcik6IElSZXN1bHQge1xuICAgICAgICB2YXIgcmVzdWx0ID0ge1xuICAgICAgICAgICAgcmVlbHM6IFNsb3RSb2xsZXIuY3JlYXRlRW1wdHlNYXRyaXgocmVlbENvdW50KSxcbiAgICAgICAgICAgIGVxdWFsTGluZXM6IFtdLFxuICAgICAgICAgICAgZXF1YWxUaWxlOiAtMVxuICAgICAgICB9O1xuXG4gICAgICAgIFNsb3RSb2xsZXIucG9wdWxhdGVNYXRyaXgocmVzdWx0LCB0aWxlQ291bnQsIHJlZWxDb3VudCk7XG5cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGEgcmVzdWx0IGFjY29yZGluZyB0byB0aGUgZm9sbG93aW5nIGNvbmRpdGlvbjpcbiAgICAgKiAgLSBUaGVyZSBpcyBvbmUgbGluZSB0aGF0IGNvbnRhaW5zIEFUIExFQVNUIE9ORSBkaWZmZXJlbnQgdGlsZS5cbiAgICAgKiBAcGFyYW0gdGlsZUNvdW50IEFtb3VudCBvZiB1bmlxdWUgdGlsZSB0ZXh0dXJlcy5cbiAgICAgKiBAcGFyYW0gcmVlbENvdW50IEFtb3VudCBvZiB2ZXJ0aWNhbCByb2xsaW5nIGxpbmVzIGluIHRoaXMgbWFjaGluZS5cbiAgICAgKi9cbiAgICBwcml2YXRlIHN0YXRpYyB0d29MaW5lc1Jlc3VsdCh0aWxlQ291bnQ6IG51bWJlciwgcmVlbENvdW50OiBudW1iZXIpOiBJUmVzdWx0IHtcbiAgICAgICAgdmFyIHJlc3VsdCA9IHtcbiAgICAgICAgICAgIHJlZWxzOiBTbG90Um9sbGVyLmNyZWF0ZUVtcHR5TWF0cml4KHJlZWxDb3VudCksXG4gICAgICAgICAgICBlcXVhbExpbmVzOiBbXSxcbiAgICAgICAgICAgIGVxdWFsVGlsZTogRGljZS5yb2xsKHRpbGVDb3VudClcbiAgICAgICAgfTtcblxuICAgICAgICAvLyBTYXZlcyBlcXVhbCBsaW5lc1xuICAgICAgICBjb25zdCBkaWZmZXJlbnRMaW5lID0gRGljZS5yb2xsKHRoaXMuUkVFTF9MRU5HVEgpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuUkVFTF9MRU5HVEg7IGkrKykge1xuICAgICAgICAgICAgaWYgKGkgIT0gZGlmZmVyZW50TGluZSkge1xuICAgICAgICAgICAgICAgIHJlc3VsdC5lcXVhbExpbmVzLnB1c2goaSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBTbG90Um9sbGVyLnBvcHVsYXRlTWF0cml4KHJlc3VsdCwgdGlsZUNvdW50LCByZWVsQ291bnQpO1xuXG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyBhIHJlc3VsdCBhY2NvcmRpbmcgdG8gdGhlIGZvbGxvd2luZyBjb25kaXRpb246XG4gICAgICogLSBUaGVyZSBpcyBPTkxZIE9ORSBsaW5lIHdob3NlIHRpbGVzIGFyZSBhbGwgdGhlIHNhbWUuXG4gICAgICogQHBhcmFtIHRpbGVDb3VudCBBbW91bnQgb2YgdW5pcXVlIHRpbGUgdGV4dHVyZXMuXG4gICAgICogQHBhcmFtIHJlZWxDb3VudCBBbW91bnQgb2YgdmVydGljYWwgcm9sbGluZyBsaW5lcyBpbiB0aGlzIG1hY2hpbmUuXG4gICAgICovXG4gICAgcHJpdmF0ZSBzdGF0aWMgc2luZ2xlTGluZVJlc3VsdCh0aWxlQ291bnQ6IG51bWJlciwgcmVlbENvdW50OiBudW1iZXIpOiBJUmVzdWx0IHtcbiAgICAgICAgdmFyIHJlc3VsdCA9IHtcbiAgICAgICAgICAgIHJlZWxzOiBTbG90Um9sbGVyLmNyZWF0ZUVtcHR5TWF0cml4KHJlZWxDb3VudCksXG4gICAgICAgICAgICBlcXVhbExpbmVzOiBbRGljZS5yb2xsKHRoaXMuUkVFTF9MRU5HVEgpXSxcbiAgICAgICAgICAgIGVxdWFsVGlsZTogRGljZS5yb2xsKHRpbGVDb3VudClcbiAgICAgICAgfTtcblxuICAgICAgICBTbG90Um9sbGVyLnBvcHVsYXRlTWF0cml4KHJlc3VsdCwgdGlsZUNvdW50LCByZWVsQ291bnQpO1xuXG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIFxuICAgIC8qKlxuICAgICAqIFBvcHVsYXRlcyBhIHRpbGUgbWF0cml4IGZyb20gYW4gSVJlc3VsdCBpbnRlcmZhY2UuXG4gICAgICogQHBhcmFtIHJlc3VsdCBDb250YWlucyB0aGUgbWF0cml4IHRvIGVkaXQuXG4gICAgICogQHBhcmFtIHRpbGVDb3VudCBBbW91bnQgb2YgdW5pcXVlIHRpbGUgdGV4dHVyZXMuXG4gICAgICogQHBhcmFtIHJlZWxDb3VudCBBbW91bnQgb2YgdmVydGljYWwgcm9sbGluZyBsaW5lcyBpbiB0aGlzIG1hY2hpbmUuXG4gICAgICovXG4gICAgcHJpdmF0ZSBzdGF0aWMgcG9wdWxhdGVNYXRyaXgocmVzdWx0OiBJUmVzdWx0LCB0aWxlQ291bnQ6IG51bWJlciwgcmVlbENvdW50OiBudW1iZXIpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLlJFRUxfTEVOR1RIOyArK2kpIHtcbiAgICAgICAgICAgIGlmIChyZXN1bHQuZXF1YWxMaW5lcy5pbmNsdWRlcyhpKSkge1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgcmVlbENvdW50OyArK2opIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnJlZWxzW2pdW2ldID0gcmVzdWx0LmVxdWFsVGlsZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zdCB1bmVxdWFsTGluZTogQXJyYXk8bnVtYmVyPiA9IHRoaXMuY3JlYXRlVW5lcXVhbExpbmUodGlsZUNvdW50LCByZWVsQ291bnQpO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgcmVlbENvdW50OyArK2opIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnJlZWxzW2pdW2ldID0gdW5lcXVhbExpbmVbal07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSAgIFxuXG59Il19