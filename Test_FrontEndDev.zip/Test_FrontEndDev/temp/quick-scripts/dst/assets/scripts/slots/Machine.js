
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/slots/Machine.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e75a3lPjzhNLb8z3HrM6PP0', 'Machine');
// scripts/slots/Machine.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var SlotEnum_1 = require("../SlotEnum");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Machine = /** @class */ (function (_super) {
    __extends(Machine, _super);
    function Machine() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.button = null;
        _this.glows = null;
        _this._reelPrefab = null;
        _this.audioJackpot = null;
        _this.Jackpot = null;
        _this._numberOfReels = 3;
        _this.reels = [];
        _this.spinning = false;
        return _this;
    }
    Object.defineProperty(Machine.prototype, "reelPrefab", {
        get: function () {
            return this._reelPrefab;
        },
        set: function (newPrefab) {
            this._reelPrefab = newPrefab;
            this.node.removeAllChildren();
            if (newPrefab !== null) {
                this.createMachine();
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Machine.prototype, "numberOfReels", {
        get: function () {
            return this._numberOfReels;
        },
        set: function (newNumber) {
            this._numberOfReels = newNumber;
            if (this.reelPrefab !== null) {
                this.createMachine();
            }
        },
        enumerable: false,
        configurable: true
    });
    Machine.prototype.createMachine = function () {
        this.node.destroyAllChildren();
        this.reels = [];
        var newReel;
        for (var i = 0; i < this.numberOfReels; i += 1) {
            newReel = cc.instantiate(this.reelPrefab);
            this.node.addChild(newReel);
            this.reels[i] = newReel;
            var reelScript = newReel.getComponent('Reel');
            reelScript.shuffle();
            reelScript.reelAnchor.getComponent(cc.Layout).enabled = false;
        }
        this.node.getComponent(cc.Widget).updateAlignment();
    };
    Machine.prototype.spin = function () {
        this.spinning = true;
        this.button.getChildByName('Label').getComponent(cc.Label).string = 'STOP';
        this.disableGlow();
        for (var i = 0; i < this.numberOfReels; i += 1) {
            var theReel = this.reels[i].getComponent('Reel');
            if (i % 2) {
                theReel.spinDirection = SlotEnum_1.default.Direction.Down;
            }
            else {
                theReel.spinDirection = SlotEnum_1.default.Direction.Up;
            }
            theReel.doSpin(0.03 * i);
        }
    };
    Machine.prototype.lock = function () {
        this.button.getComponent(cc.Button).interactable = false;
    };
    Machine.prototype.stop = function (result) {
        var _this = this;
        if (result === void 0) { result = null; }
        setTimeout(function () {
            _this.spinning = false;
            _this.button.getComponent(cc.Button).interactable = true;
            _this.button.getChildByName('Label').getComponent(cc.Label).string = 'SPIN';
            _this.enableGlow(result);
        }, 2500);
        var rngMod = Math.random() / 2;
        var _loop_1 = function (i) {
            var spinDelay = i < 2 + rngMod ? i / 4 : rngMod * (i - 2) + i / 4;
            var theReel = this_1.reels[i].getComponent('Reel');
            setTimeout(function () {
                theReel.readyStop(result.reels[i]);
            }, spinDelay * 1000);
        };
        var this_1 = this;
        for (var i = 0; i < this.numberOfReels; i += 1) {
            _loop_1(i);
        }
    };
    Machine.prototype.enableGlow = function (result) {
        if (result === void 0) { result = null; }
        for (var _i = 0, _a = result.equalLines; _i < _a.length; _i++) {
            var lineIndex = _a[_i];
            try {
                var line = this.glows.children[lineIndex];
                for (var _b = 0, _c = line.children; _b < _c.length; _b++) {
                    var glow = _c[_b];
                    var skel = glow.getComponent('sp.Skeleton');
                    skel.animation = "loop";
                    cc.audioEngine.playEffect(this.audioJackpot, false);
                    this.Jackpot.active = true;
                }
            }
            catch (error) {
                console.log(error);
            }
        }
    };
    Machine.prototype.disableGlow = function () {
        try {
            for (var _i = 0, _a = this.glows.children; _i < _a.length; _i++) {
                var line = _a[_i];
                for (var _b = 0, _c = line.children; _b < _c.length; _b++) {
                    var glow = _c[_b];
                    var skel = glow.getComponent('sp.Skeleton');
                    skel.animation = null;
                    this.Jackpot.active = false;
                }
            }
        }
        catch (error) {
            console.log(error);
        }
    };
    __decorate([
        property(cc.Node)
    ], Machine.prototype, "button", void 0);
    __decorate([
        property(cc.Node)
    ], Machine.prototype, "glows", void 0);
    __decorate([
        property(cc.Prefab)
    ], Machine.prototype, "_reelPrefab", void 0);
    __decorate([
        property({ type: cc.AudioClip })
    ], Machine.prototype, "audioJackpot", void 0);
    __decorate([
        property(cc.Node)
    ], Machine.prototype, "Jackpot", void 0);
    __decorate([
        property({ type: cc.Prefab })
    ], Machine.prototype, "reelPrefab", null);
    __decorate([
        property({ type: cc.Integer })
    ], Machine.prototype, "_numberOfReels", void 0);
    __decorate([
        property({ type: cc.Integer, range: [3, 6], slide: true })
    ], Machine.prototype, "numberOfReels", null);
    Machine = __decorate([
        ccclass
    ], Machine);
    return Machine;
}(cc.Component));
exports.default = Machine;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcc2xvdHNcXE1hY2hpbmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsd0NBQThCO0FBRXhCLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQXFDLDJCQUFZO0lBQWpEO1FBQUEscUVBMElDO1FBeElRLFlBQU0sR0FBWSxJQUFJLENBQUM7UUFHdkIsV0FBSyxHQUFZLElBQUksQ0FBQztRQUd0QixpQkFBVyxHQUFHLElBQUksQ0FBQztRQUcxQixrQkFBWSxHQUFpQixJQUFJLENBQUM7UUFHM0IsYUFBTyxHQUFZLElBQUksQ0FBQztRQWlCeEIsb0JBQWMsR0FBRyxDQUFDLENBQUM7UUFlbEIsV0FBSyxHQUFHLEVBQUUsQ0FBQztRQUVaLGNBQVEsR0FBRyxLQUFLLENBQUM7O0lBMEYxQixDQUFDO0lBekhDLHNCQUFJLCtCQUFVO2FBQWQ7WUFDRSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDMUIsQ0FBQzthQUVELFVBQWUsU0FBb0I7WUFDakMsSUFBSSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUM7WUFDN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1lBRTlCLElBQUksU0FBUyxLQUFLLElBQUksRUFBRTtnQkFDdEIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2FBQ3RCO1FBQ0gsQ0FBQzs7O09BVEE7SUFlRCxzQkFBSSxrQ0FBYTthQUFqQjtZQUNFLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQztRQUM3QixDQUFDO2FBRUQsVUFBa0IsU0FBaUI7WUFDakMsSUFBSSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7WUFFaEMsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLElBQUksRUFBRTtnQkFDNUIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2FBQ3RCO1FBQ0gsQ0FBQzs7O09BUkE7SUFjRCwrQkFBYSxHQUFiO1FBQ0UsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQy9CLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBRWhCLElBQUksT0FBZ0IsQ0FBQztRQUNyQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzlDLE9BQU8sR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUMxQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUM1QixJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQztZQUV4QixJQUFNLFVBQVUsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2hELFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNyQixVQUFVLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztTQUMvRDtRQUVELElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUN0RCxDQUFDO0lBRUQsc0JBQUksR0FBSjtRQUNFLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUN6RSxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFFckIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUM5QyxJQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUVuRCxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ1QsT0FBTyxDQUFDLGFBQWEsR0FBRyxrQkFBRyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7YUFDNUM7aUJBQU07Z0JBQ0wsT0FBTyxDQUFDLGFBQWEsR0FBRyxrQkFBRyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7YUFDMUM7WUFFQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQztTQUM1QjtJQUNILENBQUM7SUFFRCxzQkFBSSxHQUFKO1FBQ0UsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7SUFDM0QsQ0FBQztJQUVELHNCQUFJLEdBQUosVUFBSyxNQUFzQjtRQUEzQixpQkFpQkM7UUFqQkksdUJBQUEsRUFBQSxhQUFzQjtRQUN6QixVQUFVLENBQUM7WUFDVCxLQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztZQUN0QixLQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztZQUN0RCxLQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7WUFDN0UsS0FBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMxQixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFVCxJQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dDQUN4QixDQUFDO1lBQ1IsSUFBTSxTQUFTLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3BFLElBQU0sT0FBTyxHQUFHLE9BQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUVuRCxVQUFVLENBQUM7Z0JBQ1QsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDckMsQ0FBQyxFQUFFLFNBQVMsR0FBRyxJQUFJLENBQUMsQ0FBQzs7O1FBTnZCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUMsSUFBSSxDQUFDO29CQUFyQyxDQUFDO1NBT1Q7SUFDSCxDQUFDO0lBRUMsNEJBQVUsR0FBVixVQUFXLE1BQXNCO1FBQXRCLHVCQUFBLEVBQUEsYUFBc0I7UUFDN0IsS0FBd0IsVUFBaUIsRUFBakIsS0FBQSxNQUFNLENBQUMsVUFBVSxFQUFqQixjQUFpQixFQUFqQixJQUFpQixFQUFFO1lBQXRDLElBQU0sU0FBUyxTQUFBO1lBQ3RCLElBQUk7Z0JBQ0YsSUFBTSxJQUFJLEdBQVksSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUE7Z0JBQ3BELEtBQW1CLFVBQWEsRUFBYixLQUFBLElBQUksQ0FBQyxRQUFRLEVBQWIsY0FBYSxFQUFiLElBQWEsRUFBRTtvQkFBN0IsSUFBTSxJQUFJLFNBQUE7b0JBQ2IsSUFBTSxJQUFJLEdBQWdCLElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUM7b0JBQ3pELElBQUksQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDO29CQUN4QixFQUFFLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO29CQUNwRCxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7aUJBQzlCO2FBQ0Y7WUFBQyxPQUFPLEtBQUssRUFBRTtnQkFDZCxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3BCO1NBQ0Y7SUFDSCxDQUFDO0lBRUQsNkJBQVcsR0FBWDtRQUNFLElBQUk7WUFDRixLQUFtQixVQUFtQixFQUFuQixLQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFuQixjQUFtQixFQUFuQixJQUFtQixFQUFFO2dCQUFuQyxJQUFNLElBQUksU0FBQTtnQkFDYixLQUFtQixVQUFhLEVBQWIsS0FBQSxJQUFJLENBQUMsUUFBUSxFQUFiLGNBQWEsRUFBYixJQUFhLEVBQUU7b0JBQTdCLElBQU0sSUFBSSxTQUFBO29CQUNiLElBQU0sSUFBSSxHQUFnQixJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO29CQUN6RCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztvQkFDdEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO2lCQUMvQjthQUNGO1NBQ0Y7UUFBQyxPQUFPLEtBQUssRUFBRTtZQUNkLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDcEI7SUFDSCxDQUFDO0lBdklEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7MkNBQ1k7SUFHOUI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzswQ0FDVztJQUc3QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDO2dEQUNNO0lBRzFCO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQztpREFDQztJQUdsQztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzRDQUNhO0lBRy9CO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQzs2Q0FHN0I7SUFZRDtRQURDLFFBQVEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7bURBQ0w7SUFHMUI7UUFEQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDO2dEQUcxRDtJQXBDa0IsT0FBTztRQUQzQixPQUFPO09BQ2EsT0FBTyxDQTBJM0I7SUFBRCxjQUFDO0NBMUlELEFBMElDLENBMUlvQyxFQUFFLENBQUMsU0FBUyxHQTBJaEQ7a0JBMUlvQixPQUFPIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEF1eCBmcm9tICcuLi9TbG90RW51bSc7XG5cbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNYWNoaW5lIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcbiAgQHByb3BlcnR5KGNjLk5vZGUpXG4gIHB1YmxpYyBidXR0b246IGNjLk5vZGUgPSBudWxsO1xuXG4gIEBwcm9wZXJ0eShjYy5Ob2RlKVxuICBwdWJsaWMgZ2xvd3M6IGNjLk5vZGUgPSBudWxsO1xuXG4gIEBwcm9wZXJ0eShjYy5QcmVmYWIpXG4gIHB1YmxpYyBfcmVlbFByZWZhYiA9IG51bGw7XG5cbiAgQHByb3BlcnR5KHsgdHlwZTogY2MuQXVkaW9DbGlwIH0pXG4gIGF1ZGlvSmFja3BvdDogY2MuQXVkaW9DbGlwID0gbnVsbDtcblxuICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgcHVibGljIEphY2twb3Q6IGNjLk5vZGUgPSBudWxsO1xuXG4gIEBwcm9wZXJ0eSh7IHR5cGU6IGNjLlByZWZhYiB9KVxuICBnZXQgcmVlbFByZWZhYigpOiBjYy5QcmVmYWIge1xuICAgIHJldHVybiB0aGlzLl9yZWVsUHJlZmFiO1xuICB9XG5cbiAgc2V0IHJlZWxQcmVmYWIobmV3UHJlZmFiOiBjYy5QcmVmYWIpIHtcbiAgICB0aGlzLl9yZWVsUHJlZmFiID0gbmV3UHJlZmFiO1xuICAgIHRoaXMubm9kZS5yZW1vdmVBbGxDaGlsZHJlbigpO1xuXG4gICAgaWYgKG5ld1ByZWZhYiAhPT0gbnVsbCkge1xuICAgICAgdGhpcy5jcmVhdGVNYWNoaW5lKCk7XG4gICAgfVxuICB9XG5cbiAgQHByb3BlcnR5KHsgdHlwZTogY2MuSW50ZWdlciB9KVxuICBwdWJsaWMgX251bWJlck9mUmVlbHMgPSAzO1xuXG4gIEBwcm9wZXJ0eSh7IHR5cGU6IGNjLkludGVnZXIsIHJhbmdlOiBbMywgNl0sIHNsaWRlOiB0cnVlIH0pXG4gIGdldCBudW1iZXJPZlJlZWxzKCk6IG51bWJlciB7XG4gICAgcmV0dXJuIHRoaXMuX251bWJlck9mUmVlbHM7XG4gIH1cblxuICBzZXQgbnVtYmVyT2ZSZWVscyhuZXdOdW1iZXI6IG51bWJlcikge1xuICAgIHRoaXMuX251bWJlck9mUmVlbHMgPSBuZXdOdW1iZXI7XG5cbiAgICBpZiAodGhpcy5yZWVsUHJlZmFiICE9PSBudWxsKSB7XG4gICAgICB0aGlzLmNyZWF0ZU1hY2hpbmUoKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHJlZWxzID0gW107XG5cbiAgcHVibGljIHNwaW5uaW5nID0gZmFsc2U7XG5cbiAgY3JlYXRlTWFjaGluZSgpOiB2b2lkIHtcbiAgICB0aGlzLm5vZGUuZGVzdHJveUFsbENoaWxkcmVuKCk7XG4gICAgdGhpcy5yZWVscyA9IFtdO1xuXG4gICAgbGV0IG5ld1JlZWw6IGNjLk5vZGU7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLm51bWJlck9mUmVlbHM7IGkgKz0gMSkge1xuICAgICAgbmV3UmVlbCA9IGNjLmluc3RhbnRpYXRlKHRoaXMucmVlbFByZWZhYik7XG4gICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQobmV3UmVlbCk7XG4gICAgICB0aGlzLnJlZWxzW2ldID0gbmV3UmVlbDtcblxuICAgICAgY29uc3QgcmVlbFNjcmlwdCA9IG5ld1JlZWwuZ2V0Q29tcG9uZW50KCdSZWVsJyk7XG4gICAgICByZWVsU2NyaXB0LnNodWZmbGUoKTtcbiAgICAgIHJlZWxTY3JpcHQucmVlbEFuY2hvci5nZXRDb21wb25lbnQoY2MuTGF5b3V0KS5lbmFibGVkID0gZmFsc2U7XG4gICAgfVxuXG4gICAgdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5XaWRnZXQpLnVwZGF0ZUFsaWdubWVudCgpO1xuICB9XG5cbiAgc3BpbigpOiB2b2lkIHtcbiAgICB0aGlzLnNwaW5uaW5nID0gdHJ1ZTtcbiAgICB0aGlzLmJ1dHRvbi5nZXRDaGlsZEJ5TmFtZSgnTGFiZWwnKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9ICdTVE9QJztcbiAgICAgIHRoaXMuZGlzYWJsZUdsb3coKTtcblxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5udW1iZXJPZlJlZWxzOyBpICs9IDEpIHtcbiAgICAgIGNvbnN0IHRoZVJlZWwgPSB0aGlzLnJlZWxzW2ldLmdldENvbXBvbmVudCgnUmVlbCcpO1xuXG4gICAgICBpZiAoaSAlIDIpIHtcbiAgICAgICAgdGhlUmVlbC5zcGluRGlyZWN0aW9uID0gQXV4LkRpcmVjdGlvbi5Eb3duO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhlUmVlbC5zcGluRGlyZWN0aW9uID0gQXV4LkRpcmVjdGlvbi5VcDtcbiAgICAgIH1cblxuICAgICAgICB0aGVSZWVsLmRvU3BpbigwLjAzICogaSk7XG4gICAgfVxuICB9XG5cbiAgbG9jaygpOiB2b2lkIHtcbiAgICB0aGlzLmJ1dHRvbi5nZXRDb21wb25lbnQoY2MuQnV0dG9uKS5pbnRlcmFjdGFibGUgPSBmYWxzZTtcbiAgfVxuXG4gIHN0b3AocmVzdWx0OiBJUmVzdWx0ID0gbnVsbCk6IHZvaWQge1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGhpcy5zcGlubmluZyA9IGZhbHNlO1xuICAgICAgdGhpcy5idXR0b24uZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikuaW50ZXJhY3RhYmxlID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5idXR0b24uZ2V0Q2hpbGRCeU5hbWUoJ0xhYmVsJykuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSAnU1BJTic7XG4gICAgICB0aGlzLmVuYWJsZUdsb3cocmVzdWx0KTtcbiAgICB9LCAyNTAwKTtcblxuICAgIGNvbnN0IHJuZ01vZCA9IE1hdGgucmFuZG9tKCkgLyAyO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5udW1iZXJPZlJlZWxzOyBpICs9IDEpIHtcbiAgICAgIGNvbnN0IHNwaW5EZWxheSA9IGkgPCAyICsgcm5nTW9kID8gaSAvIDQgOiBybmdNb2QgKiAoaSAtIDIpICsgaSAvIDQ7XG4gICAgICBjb25zdCB0aGVSZWVsID0gdGhpcy5yZWVsc1tpXS5nZXRDb21wb25lbnQoJ1JlZWwnKTtcblxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHRoZVJlZWwucmVhZHlTdG9wKHJlc3VsdC5yZWVsc1tpXSk7XG4gICAgICB9LCBzcGluRGVsYXkgKiAxMDAwKTtcbiAgICB9XG4gIH1cblxuICAgIGVuYWJsZUdsb3cocmVzdWx0OiBJUmVzdWx0ID0gbnVsbCk6IHZvaWQge1xuICAgICAgICBmb3IgKGNvbnN0IGxpbmVJbmRleCBvZiByZXN1bHQuZXF1YWxMaW5lcykge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgbGluZTogY2MuTm9kZSA9IHRoaXMuZ2xvd3MuY2hpbGRyZW5bbGluZUluZGV4XVxuICAgICAgICBmb3IgKGNvbnN0IGdsb3cgb2YgbGluZS5jaGlsZHJlbikge1xuICAgICAgICAgIGNvbnN0IHNrZWw6IHNwLlNrZWxldG9uID0gZ2xvdy5nZXRDb21wb25lbnQoJ3NwLlNrZWxldG9uJyk7XG4gICAgICAgICAgICBza2VsLmFuaW1hdGlvbiA9IFwibG9vcFwiO1xuICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLmF1ZGlvSmFja3BvdCwgZmFsc2UpO1xuICAgICAgICAgICAgdGhpcy5KYWNrcG90LmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBkaXNhYmxlR2xvdygpOiB2b2lkIHtcbiAgICB0cnkge1xuICAgICAgZm9yIChjb25zdCBsaW5lIG9mIHRoaXMuZ2xvd3MuY2hpbGRyZW4pIHtcbiAgICAgICAgZm9yIChjb25zdCBnbG93IG9mIGxpbmUuY2hpbGRyZW4pIHtcbiAgICAgICAgICBjb25zdCBza2VsOiBzcC5Ta2VsZXRvbiA9IGdsb3cuZ2V0Q29tcG9uZW50KCdzcC5Ta2VsZXRvbicpO1xuICAgICAgICAgICAgc2tlbC5hbmltYXRpb24gPSBudWxsO1xuICAgICAgICAgICAgdGhpcy5KYWNrcG90LmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcbiAgICB9XG4gIH1cbn1cbiJdfQ==