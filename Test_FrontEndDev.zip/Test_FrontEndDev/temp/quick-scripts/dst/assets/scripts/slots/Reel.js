
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/slots/Reel.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '91e54zzGJ5Os6qxY73m4+B5', 'Reel');
// scripts/slots/Reel.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var SlotEnum_1 = require("../SlotEnum");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Reel = /** @class */ (function (_super) {
    __extends(Reel, _super);
    function Reel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.reelAnchor = null;
        _this.spinDirection = SlotEnum_1.default.Direction.Down;
        _this.tiles = [];
        _this._tilePrefab = null;
        _this.result = [];
        _this.stopSpinning = false;
        return _this;
    }
    Object.defineProperty(Reel.prototype, "tilePrefab", {
        get: function () {
            return this._tilePrefab;
        },
        set: function (newPrefab) {
            this._tilePrefab = newPrefab;
            this.reelAnchor.removeAllChildren();
            this.tiles = [];
            if (newPrefab !== null) {
                this.createReel();
                this.shuffle();
            }
        },
        enumerable: false,
        configurable: true
    });
    Reel.prototype.createReel = function () {
        var newTile;
        for (var i = 0; i < 5; i += 1) {
            newTile = cc.instantiate(this.tilePrefab);
            this.reelAnchor.addChild(newTile);
            this.tiles[i] = newTile;
        }
    };
    Reel.prototype.shuffle = function () {
        for (var i = 0; i < this.tiles.length; i += 1) {
            this.tiles[i].getComponent('Tile').setRandom();
        }
    };
    Reel.prototype.readyStop = function (newResult) {
        var check = this.spinDirection === SlotEnum_1.default.Direction.Down || newResult == null;
        this.result = check ? newResult : newResult.reverse();
        this.stopSpinning = true;
    };
    Reel.prototype.changeCallback = function (element) {
        if (element === void 0) { element = null; }
        var el = element;
        var dirModifier = this.spinDirection === SlotEnum_1.default.Direction.Down ? -1 : 1;
        if (el.position.y * dirModifier > 288) {
            el.position = cc.v2(0, -288 * dirModifier);
            var pop = null;
            if (this.result != null && this.result.length > 0) {
                pop = this.result.pop();
            }
            if (pop != null && pop >= 0) {
                el.getComponent('Tile').setTile(pop);
            }
            else {
                el.getComponent('Tile').setRandom();
            }
        }
    };
    Reel.prototype.checkEndCallback = function (element) {
        if (element === void 0) { element = null; }
        var el = element;
        if (this.stopSpinning) {
            this.getComponent(cc.AudioSource).play();
            this.doStop(el);
        }
        else {
            this.doSpinning(el);
        }
    };
    Reel.prototype.doSpin = function (windUp) {
        var _this = this;
        this.stopSpinning = false;
        this.reelAnchor.children.forEach(function (element) {
            var dirModifier = _this.spinDirection === SlotEnum_1.default.Direction.Down ? -1 : 1;
            var delay = cc.tween(element).delay(windUp);
            var start = cc.tween(element).by(0.25, { position: cc.v2(0, 144 * dirModifier) }, { easing: 'backIn' });
            var doChange = cc.tween().call(function () { return _this.changeCallback(element); });
            var callSpinning = cc.tween(element).call(function () { return _this.doSpinning(element, 5); });
            delay
                .then(start)
                .then(doChange)
                .then(callSpinning)
                .start();
        });
    };
    Reel.prototype.doSpinning = function (element, times) {
        var _this = this;
        if (element === void 0) { element = null; }
        if (times === void 0) { times = 1; }
        var dirModifier = this.spinDirection === SlotEnum_1.default.Direction.Down ? -1 : 1;
        var move = cc.tween().by(0.04, { position: cc.v2(0, 144 * dirModifier) });
        var doChange = cc.tween().call(function () { return _this.changeCallback(element); });
        var repeat = cc.tween(element).repeat(times, move.then(doChange));
        var checkEnd = cc.tween().call(function () { return _this.checkEndCallback(element); });
        repeat.then(checkEnd).start();
    };
    Reel.prototype.doStop = function (element) {
        var _this = this;
        if (element === void 0) { element = null; }
        var dirModifier = this.spinDirection === SlotEnum_1.default.Direction.Down ? -1 : 1;
        var move = cc.tween(element).by(0.04, { position: cc.v2(0, 144 * dirModifier) });
        var doChange = cc.tween().call(function () { return _this.changeCallback(element); });
        var end = cc.tween().by(0.2, { position: cc.v2(0, 144 * dirModifier) }, { easing: 'bounceOut' });
        move
            .then(doChange)
            .then(move)
            .then(doChange)
            .then(end)
            .then(doChange)
            .start();
    };
    __decorate([
        property({ type: cc.Node })
    ], Reel.prototype, "reelAnchor", void 0);
    __decorate([
        property({ type: cc.Enum(SlotEnum_1.default.Direction) })
    ], Reel.prototype, "spinDirection", void 0);
    __decorate([
        property({ type: [cc.Node], visible: false })
    ], Reel.prototype, "tiles", void 0);
    __decorate([
        property({ type: cc.Prefab })
    ], Reel.prototype, "_tilePrefab", void 0);
    __decorate([
        property({ type: cc.Prefab })
    ], Reel.prototype, "tilePrefab", null);
    Reel = __decorate([
        ccclass
    ], Reel);
    return Reel;
}(cc.Component));
exports.default = Reel;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcc2xvdHNcXFJlZWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsd0NBQThCO0FBRXhCLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQWtDLHdCQUFZO0lBQTlDO1FBQUEscUVBZ0lDO1FBOUhRLGdCQUFVLEdBQUcsSUFBSSxDQUFDO1FBR2xCLG1CQUFhLEdBQUcsa0JBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDO1FBR2xDLFdBQUssR0FBRyxFQUFFLENBQUM7UUFHWixpQkFBVyxHQUFHLElBQUksQ0FBQztRQWtCbEIsWUFBTSxHQUFrQixFQUFFLENBQUM7UUFFNUIsa0JBQVksR0FBRyxLQUFLLENBQUM7O0lBaUc5QixDQUFDO0lBbEhDLHNCQUFJLDRCQUFVO2FBQWQ7WUFDRSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDMUIsQ0FBQzthQUVELFVBQWUsU0FBb0I7WUFDakMsSUFBSSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUM7WUFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1lBQ3BDLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO1lBRWhCLElBQUksU0FBUyxLQUFLLElBQUksRUFBRTtnQkFDdEIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNsQixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDaEI7UUFDSCxDQUFDOzs7T0FYQTtJQWlCRCx5QkFBVSxHQUFWO1FBQ0UsSUFBSSxPQUFnQixDQUFDO1FBQ3JCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUM3QixPQUFPLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDMUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxPQUFPLENBQUM7U0FDekI7SUFDSCxDQUFDO0lBRUQsc0JBQU8sR0FBUDtRQUNFLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzdDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO1NBQ2hEO0lBQ0gsQ0FBQztJQUVELHdCQUFTLEdBQVQsVUFBVSxTQUF3QjtRQUNoQyxJQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxLQUFLLGtCQUFHLENBQUMsU0FBUyxDQUFDLElBQUksSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDO1FBQzdFLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUN0RCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztJQUMzQixDQUFDO0lBRUQsNkJBQWMsR0FBZCxVQUFlLE9BQXVCO1FBQXZCLHdCQUFBLEVBQUEsY0FBdUI7UUFDcEMsSUFBTSxFQUFFLEdBQUcsT0FBTyxDQUFDO1FBQ25CLElBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLEtBQUssa0JBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZFLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsV0FBVyxHQUFHLEdBQUcsRUFBRTtZQUNyQyxFQUFFLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLFdBQVcsQ0FBQyxDQUFDO1lBRTNDLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQztZQUNmLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUNqRCxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQzthQUN6QjtZQUVELElBQUksR0FBRyxJQUFJLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxFQUFFO2dCQUMzQixFQUFFLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUN0QztpQkFBTTtnQkFDTCxFQUFFLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO2FBQ3JDO1NBQ0Y7SUFDSCxDQUFDO0lBRUQsK0JBQWdCLEdBQWhCLFVBQWlCLE9BQXVCO1FBQXZCLHdCQUFBLEVBQUEsY0FBdUI7UUFDdEMsSUFBTSxFQUFFLEdBQUcsT0FBTyxDQUFDO1FBQ25CLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRTtZQUNyQixJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUN6QyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQ2pCO2FBQU07WUFDTCxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQ3JCO0lBQ0gsQ0FBQztJQUVELHFCQUFNLEdBQU4sVUFBTyxNQUFjO1FBQXJCLGlCQWlCQztRQWhCQyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztRQUUxQixJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsVUFBQSxPQUFPO1lBQ3RDLElBQU0sV0FBVyxHQUFHLEtBQUksQ0FBQyxhQUFhLEtBQUssa0JBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRXZFLElBQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzlDLElBQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLEdBQUcsV0FBVyxDQUFDLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1lBQzFHLElBQU0sUUFBUSxHQUFHLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBTSxPQUFBLEtBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEVBQTVCLENBQTRCLENBQUMsQ0FBQztZQUNyRSxJQUFNLFlBQVksR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFNLE9BQUEsS0FBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQTNCLENBQTJCLENBQUMsQ0FBQztZQUUvRSxLQUFLO2lCQUNGLElBQUksQ0FBQyxLQUFLLENBQUM7aUJBQ1gsSUFBSSxDQUFDLFFBQVEsQ0FBQztpQkFDZCxJQUFJLENBQUMsWUFBWSxDQUFDO2lCQUNsQixLQUFLLEVBQUUsQ0FBQztRQUNiLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELHlCQUFVLEdBQVYsVUFBVyxPQUF1QixFQUFFLEtBQVM7UUFBN0MsaUJBU0M7UUFUVSx3QkFBQSxFQUFBLGNBQXVCO1FBQUUsc0JBQUEsRUFBQSxTQUFTO1FBQzNDLElBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLEtBQUssa0JBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRXZFLElBQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsR0FBRyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDNUUsSUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFNLE9BQUEsS0FBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsRUFBNUIsQ0FBNEIsQ0FBQyxDQUFDO1FBQ3JFLElBQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDcEUsSUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFNLE9BQUEsS0FBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxFQUE5QixDQUE4QixDQUFDLENBQUM7UUFFdkUsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUNoQyxDQUFDO0lBRUQscUJBQU0sR0FBTixVQUFPLE9BQXVCO1FBQTlCLGlCQWNDO1FBZE0sd0JBQUEsRUFBQSxjQUF1QjtRQUM1QixJQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsYUFBYSxLQUFLLGtCQUFHLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV2RSxJQUFNLElBQUksR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxRQUFRLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxHQUFHLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNuRixJQUFNLFFBQVEsR0FBRyxFQUFFLENBQUMsS0FBSyxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQU0sT0FBQSxLQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxFQUE1QixDQUE0QixDQUFDLENBQUM7UUFDckUsSUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxRQUFRLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxHQUFHLFdBQVcsQ0FBQyxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUVuRyxJQUFJO2FBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQzthQUNkLElBQUksQ0FBQyxJQUFJLENBQUM7YUFDVixJQUFJLENBQUMsUUFBUSxDQUFDO2FBQ2QsSUFBSSxDQUFDLEdBQUcsQ0FBQzthQUNULElBQUksQ0FBQyxRQUFRLENBQUM7YUFDZCxLQUFLLEVBQUUsQ0FBQztJQUNiLENBQUM7SUE3SEQ7UUFEQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDOzRDQUNIO0lBR3pCO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsa0JBQUcsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDOytDQUNEO0lBRzFDO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQzt1Q0FDM0I7SUFHbkI7UUFEQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDOzZDQUNKO0lBRzFCO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQzswQ0FHN0I7SUFoQmtCLElBQUk7UUFEeEIsT0FBTztPQUNhLElBQUksQ0FnSXhCO0lBQUQsV0FBQztDQWhJRCxBQWdJQyxDQWhJaUMsRUFBRSxDQUFDLFNBQVMsR0FnSTdDO2tCQWhJb0IsSUFBSSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBBdXggZnJvbSAnLi4vU2xvdEVudW0nO1xuXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVlbCBleHRlbmRzIGNjLkNvbXBvbmVudCB7XG4gIEBwcm9wZXJ0eSh7IHR5cGU6IGNjLk5vZGUgfSlcbiAgcHVibGljIHJlZWxBbmNob3IgPSBudWxsO1xuXG4gIEBwcm9wZXJ0eSh7IHR5cGU6IGNjLkVudW0oQXV4LkRpcmVjdGlvbikgfSlcbiAgcHVibGljIHNwaW5EaXJlY3Rpb24gPSBBdXguRGlyZWN0aW9uLkRvd247XG5cbiAgQHByb3BlcnR5KHsgdHlwZTogW2NjLk5vZGVdLCB2aXNpYmxlOiBmYWxzZSB9KVxuICBwcml2YXRlIHRpbGVzID0gW107XG5cbiAgQHByb3BlcnR5KHsgdHlwZTogY2MuUHJlZmFiIH0pXG4gIHB1YmxpYyBfdGlsZVByZWZhYiA9IG51bGw7XG5cbiAgQHByb3BlcnR5KHsgdHlwZTogY2MuUHJlZmFiIH0pXG4gIGdldCB0aWxlUHJlZmFiKCk6IGNjLlByZWZhYiB7XG4gICAgcmV0dXJuIHRoaXMuX3RpbGVQcmVmYWI7XG4gIH1cblxuICBzZXQgdGlsZVByZWZhYihuZXdQcmVmYWI6IGNjLlByZWZhYikge1xuICAgIHRoaXMuX3RpbGVQcmVmYWIgPSBuZXdQcmVmYWI7XG4gICAgdGhpcy5yZWVsQW5jaG9yLnJlbW92ZUFsbENoaWxkcmVuKCk7XG4gICAgdGhpcy50aWxlcyA9IFtdO1xuXG4gICAgaWYgKG5ld1ByZWZhYiAhPT0gbnVsbCkge1xuICAgICAgdGhpcy5jcmVhdGVSZWVsKCk7XG4gICAgICB0aGlzLnNodWZmbGUoKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHJlc3VsdDogQXJyYXk8bnVtYmVyPiA9IFtdO1xuXG4gIHB1YmxpYyBzdG9wU3Bpbm5pbmcgPSBmYWxzZTtcblxuICBjcmVhdGVSZWVsKCk6IHZvaWQge1xuICAgIGxldCBuZXdUaWxlOiBjYy5Ob2RlO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgNTsgaSArPSAxKSB7XG4gICAgICBuZXdUaWxlID0gY2MuaW5zdGFudGlhdGUodGhpcy50aWxlUHJlZmFiKTtcbiAgICAgIHRoaXMucmVlbEFuY2hvci5hZGRDaGlsZChuZXdUaWxlKTtcbiAgICAgIHRoaXMudGlsZXNbaV0gPSBuZXdUaWxlO1xuICAgIH1cbiAgfVxuXG4gIHNodWZmbGUoKTogdm9pZCB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLnRpbGVzLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgICB0aGlzLnRpbGVzW2ldLmdldENvbXBvbmVudCgnVGlsZScpLnNldFJhbmRvbSgpO1xuICAgIH1cbiAgfVxuXG4gIHJlYWR5U3RvcChuZXdSZXN1bHQ6IEFycmF5PG51bWJlcj4pOiB2b2lkIHtcbiAgICBjb25zdCBjaGVjayA9IHRoaXMuc3BpbkRpcmVjdGlvbiA9PT0gQXV4LkRpcmVjdGlvbi5Eb3duIHx8IG5ld1Jlc3VsdCA9PSBudWxsO1xuICAgIHRoaXMucmVzdWx0ID0gY2hlY2sgPyBuZXdSZXN1bHQgOiBuZXdSZXN1bHQucmV2ZXJzZSgpO1xuICAgIHRoaXMuc3RvcFNwaW5uaW5nID0gdHJ1ZTtcbiAgfVxuXG4gIGNoYW5nZUNhbGxiYWNrKGVsZW1lbnQ6IGNjLk5vZGUgPSBudWxsKTogdm9pZCB7XG4gICAgY29uc3QgZWwgPSBlbGVtZW50O1xuICAgIGNvbnN0IGRpck1vZGlmaWVyID0gdGhpcy5zcGluRGlyZWN0aW9uID09PSBBdXguRGlyZWN0aW9uLkRvd24gPyAtMSA6IDE7XG4gICAgaWYgKGVsLnBvc2l0aW9uLnkgKiBkaXJNb2RpZmllciA+IDI4OCkge1xuICAgICAgZWwucG9zaXRpb24gPSBjYy52MigwLCAtMjg4ICogZGlyTW9kaWZpZXIpO1xuXG4gICAgICBsZXQgcG9wID0gbnVsbDtcbiAgICAgIGlmICh0aGlzLnJlc3VsdCAhPSBudWxsICYmIHRoaXMucmVzdWx0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgcG9wID0gdGhpcy5yZXN1bHQucG9wKCk7XG4gICAgICB9XG5cbiAgICAgIGlmIChwb3AgIT0gbnVsbCAmJiBwb3AgPj0gMCkge1xuICAgICAgICBlbC5nZXRDb21wb25lbnQoJ1RpbGUnKS5zZXRUaWxlKHBvcCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBlbC5nZXRDb21wb25lbnQoJ1RpbGUnKS5zZXRSYW5kb20oKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBjaGVja0VuZENhbGxiYWNrKGVsZW1lbnQ6IGNjLk5vZGUgPSBudWxsKTogdm9pZCB7XG4gICAgY29uc3QgZWwgPSBlbGVtZW50O1xuICAgIGlmICh0aGlzLnN0b3BTcGlubmluZykge1xuICAgICAgdGhpcy5nZXRDb21wb25lbnQoY2MuQXVkaW9Tb3VyY2UpLnBsYXkoKTtcbiAgICAgIHRoaXMuZG9TdG9wKGVsKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5kb1NwaW5uaW5nKGVsKTtcbiAgICB9XG4gIH1cblxuICBkb1NwaW4od2luZFVwOiBudW1iZXIpOiB2b2lkIHtcbiAgICB0aGlzLnN0b3BTcGlubmluZyA9IGZhbHNlO1xuXG4gICAgdGhpcy5yZWVsQW5jaG9yLmNoaWxkcmVuLmZvckVhY2goZWxlbWVudCA9PiB7XG4gICAgICBjb25zdCBkaXJNb2RpZmllciA9IHRoaXMuc3BpbkRpcmVjdGlvbiA9PT0gQXV4LkRpcmVjdGlvbi5Eb3duID8gLTEgOiAxO1xuXG4gICAgICBjb25zdCBkZWxheSA9IGNjLnR3ZWVuKGVsZW1lbnQpLmRlbGF5KHdpbmRVcCk7XG4gICAgICBjb25zdCBzdGFydCA9IGNjLnR3ZWVuKGVsZW1lbnQpLmJ5KDAuMjUsIHsgcG9zaXRpb246IGNjLnYyKDAsIDE0NCAqIGRpck1vZGlmaWVyKSB9LCB7IGVhc2luZzogJ2JhY2tJbicgfSk7XG4gICAgICBjb25zdCBkb0NoYW5nZSA9IGNjLnR3ZWVuKCkuY2FsbCgoKSA9PiB0aGlzLmNoYW5nZUNhbGxiYWNrKGVsZW1lbnQpKTtcbiAgICAgIGNvbnN0IGNhbGxTcGlubmluZyA9IGNjLnR3ZWVuKGVsZW1lbnQpLmNhbGwoKCkgPT4gdGhpcy5kb1NwaW5uaW5nKGVsZW1lbnQsIDUpKTtcblxuICAgICAgZGVsYXlcbiAgICAgICAgLnRoZW4oc3RhcnQpXG4gICAgICAgIC50aGVuKGRvQ2hhbmdlKVxuICAgICAgICAudGhlbihjYWxsU3Bpbm5pbmcpXG4gICAgICAgIC5zdGFydCgpO1xuICAgIH0pO1xuICB9XG5cbiAgZG9TcGlubmluZyhlbGVtZW50OiBjYy5Ob2RlID0gbnVsbCwgdGltZXMgPSAxKTogdm9pZCB7XG4gICAgY29uc3QgZGlyTW9kaWZpZXIgPSB0aGlzLnNwaW5EaXJlY3Rpb24gPT09IEF1eC5EaXJlY3Rpb24uRG93biA/IC0xIDogMTtcblxuICAgIGNvbnN0IG1vdmUgPSBjYy50d2VlbigpLmJ5KDAuMDQsIHsgcG9zaXRpb246IGNjLnYyKDAsIDE0NCAqIGRpck1vZGlmaWVyKSB9KTtcbiAgICBjb25zdCBkb0NoYW5nZSA9IGNjLnR3ZWVuKCkuY2FsbCgoKSA9PiB0aGlzLmNoYW5nZUNhbGxiYWNrKGVsZW1lbnQpKTtcbiAgICBjb25zdCByZXBlYXQgPSBjYy50d2VlbihlbGVtZW50KS5yZXBlYXQodGltZXMsIG1vdmUudGhlbihkb0NoYW5nZSkpO1xuICAgIGNvbnN0IGNoZWNrRW5kID0gY2MudHdlZW4oKS5jYWxsKCgpID0+IHRoaXMuY2hlY2tFbmRDYWxsYmFjayhlbGVtZW50KSk7XG5cbiAgICByZXBlYXQudGhlbihjaGVja0VuZCkuc3RhcnQoKTtcbiAgfVxuXG4gIGRvU3RvcChlbGVtZW50OiBjYy5Ob2RlID0gbnVsbCk6IHZvaWQge1xuICAgIGNvbnN0IGRpck1vZGlmaWVyID0gdGhpcy5zcGluRGlyZWN0aW9uID09PSBBdXguRGlyZWN0aW9uLkRvd24gPyAtMSA6IDE7XG5cbiAgICBjb25zdCBtb3ZlID0gY2MudHdlZW4oZWxlbWVudCkuYnkoMC4wNCwgeyBwb3NpdGlvbjogY2MudjIoMCwgMTQ0ICogZGlyTW9kaWZpZXIpIH0pO1xuICAgIGNvbnN0IGRvQ2hhbmdlID0gY2MudHdlZW4oKS5jYWxsKCgpID0+IHRoaXMuY2hhbmdlQ2FsbGJhY2soZWxlbWVudCkpO1xuICAgIGNvbnN0IGVuZCA9IGNjLnR3ZWVuKCkuYnkoMC4yLCB7IHBvc2l0aW9uOiBjYy52MigwLCAxNDQgKiBkaXJNb2RpZmllcikgfSwgeyBlYXNpbmc6ICdib3VuY2VPdXQnIH0pO1xuXG4gICAgbW92ZVxuICAgICAgLnRoZW4oZG9DaGFuZ2UpXG4gICAgICAudGhlbihtb3ZlKVxuICAgICAgLnRoZW4oZG9DaGFuZ2UpXG4gICAgICAudGhlbihlbmQpXG4gICAgICAudGhlbihkb0NoYW5nZSlcbiAgICAgIC5zdGFydCgpO1xuICB9XG59XG4iXX0=