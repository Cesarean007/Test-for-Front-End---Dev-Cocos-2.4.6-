
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/LogGenerator.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6c700uea35D1LbqeXU/UA+6', 'LogGenerator');
// scripts/LogGenerator.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogGenerator = void 0;
var SlotRoller_1 = require("./slots/SlotRoller");
/**
 * Generates javascript log files.
 * This class is a helper tool for debug purposes only.
 */
var LogGenerator = /** @class */ (function () {
    function LogGenerator() {
    }
    /**
     * Save text to file and download it.
     * @param filename Generated file name.
     * @param text Text to save.
     */
    LogGenerator.download = function (filename, text) {
        var element = document.createElement('a');
        element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
        element.setAttribute('download', filename);
        element.style.display = 'none';
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
    };
    /**
     * Generate javascript log file and download it.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     * @param length Amount of rolls (iterations) in log history.
     */
    LogGenerator.generateBaseLog = function (tileCount, reelCount, length) {
        var log = [];
        for (var i = 0; i < length; i++) {
            log.push(SlotRoller_1.SlotRoller.roll(tileCount, reelCount));
        }
        LogGenerator.download('log.js', "module.exports = {\n\thistory: " + JSON.stringify(log) + "\n}");
    };
    return LogGenerator;
}());
exports.LogGenerator = LogGenerator;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcTG9nR2VuZXJhdG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGlEQUErQztBQUUvQzs7O0dBR0c7QUFDSDtJQUFBO0lBK0JBLENBQUM7SUE3Qkc7Ozs7T0FJRztJQUNXLHFCQUFRLEdBQXRCLFVBQXVCLFFBQWdCLEVBQUUsSUFBWTtRQUNqRCxJQUFJLE9BQU8sR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLGdDQUFnQyxHQUFHLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDMUYsT0FBTyxDQUFDLFlBQVksQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFDM0MsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDO1FBQy9CLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ25DLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNoQixRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDVyw0QkFBZSxHQUE3QixVQUE4QixTQUFpQixFQUFFLFNBQWlCLEVBQUUsTUFBYztRQUM5RSxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7UUFDYixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzdCLEdBQUcsQ0FBQyxJQUFJLENBQUMsdUJBQVUsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUM7U0FDbkQ7UUFDRCxZQUFZLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxvQ0FBa0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBSyxDQUFDLENBQUM7SUFDaEcsQ0FBQztJQUVMLG1CQUFDO0FBQUQsQ0EvQkEsQUErQkMsSUFBQTtBQS9CcUIsb0NBQVkiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTbG90Um9sbGVyIH0gZnJvbSBcIi4vc2xvdHMvU2xvdFJvbGxlclwiXG5cbi8qKlxuICogR2VuZXJhdGVzIGphdmFzY3JpcHQgbG9nIGZpbGVzLlxuICogVGhpcyBjbGFzcyBpcyBhIGhlbHBlciB0b29sIGZvciBkZWJ1ZyBwdXJwb3NlcyBvbmx5LlxuICovXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgTG9nR2VuZXJhdG9yIHtcblxuICAgIC8qKlxuICAgICAqIFNhdmUgdGV4dCB0byBmaWxlIGFuZCBkb3dubG9hZCBpdC5cbiAgICAgKiBAcGFyYW0gZmlsZW5hbWUgR2VuZXJhdGVkIGZpbGUgbmFtZS5cbiAgICAgKiBAcGFyYW0gdGV4dCBUZXh0IHRvIHNhdmUuXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBkb3dubG9hZChmaWxlbmFtZTogc3RyaW5nLCB0ZXh0OiBzdHJpbmcpOiB2b2lkIHtcbiAgICAgICAgdmFyIGVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlKCdocmVmJywgJ2RhdGE6dGV4dC9wbGFpbjtjaGFyc2V0PXV0Zi04LCcgKyBlbmNvZGVVUklDb21wb25lbnQodGV4dCkpO1xuICAgICAgICBlbGVtZW50LnNldEF0dHJpYnV0ZSgnZG93bmxvYWQnLCBmaWxlbmFtZSk7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUuZGlzcGxheSA9ICdub25lJztcbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChlbGVtZW50KTtcbiAgICAgICAgZWxlbWVudC5jbGljaygpO1xuICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGVsZW1lbnQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdlbmVyYXRlIGphdmFzY3JpcHQgbG9nIGZpbGUgYW5kIGRvd25sb2FkIGl0LlxuICAgICAqIEBwYXJhbSB0aWxlQ291bnQgQW1vdW50IG9mIHVuaXF1ZSB0aWxlIHRleHR1cmVzLlxuICAgICAqIEBwYXJhbSByZWVsQ291bnQgQW1vdW50IG9mIHZlcnRpY2FsIHJvbGxpbmcgbGluZXMgaW4gdGhpcyBtYWNoaW5lLlxuICAgICAqIEBwYXJhbSBsZW5ndGggQW1vdW50IG9mIHJvbGxzIChpdGVyYXRpb25zKSBpbiBsb2cgaGlzdG9yeS5cbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGdlbmVyYXRlQmFzZUxvZyh0aWxlQ291bnQ6IG51bWJlciwgcmVlbENvdW50OiBudW1iZXIsIGxlbmd0aDogbnVtYmVyKSB7XG4gICAgICAgIGxldCBsb2cgPSBbXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgbG9nLnB1c2goU2xvdFJvbGxlci5yb2xsKHRpbGVDb3VudCwgcmVlbENvdW50KSk7XG4gICAgICAgIH1cbiAgICAgICAgTG9nR2VuZXJhdG9yLmRvd25sb2FkKCdsb2cuanMnLCBgbW9kdWxlLmV4cG9ydHMgPSB7XFxuXFx0aGlzdG9yeTogJHtKU09OLnN0cmluZ2lmeShsb2cpfVxcbn1gKTtcbiAgICB9XG4gICAgXG59XG4iXX0=