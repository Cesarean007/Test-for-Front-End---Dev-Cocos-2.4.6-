
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/GameManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7462271VdFN4J38ivhu1fP1', 'GameManager');
// scripts/GameManager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var SlotRoller_1 = require("./slots/SlotRoller");
var NetworkLog_1 = require("./NetworkLog");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameManager = /** @class */ (function (_super) {
    __extends(GameManager, _super);
    function GameManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // ====================================================
        // Attributes
        // ====================================================
        _this.machine = null;
        _this.audioClick = null;
        _this.block = false;
        _this.result = null;
        _this._reelCount = 0;
        _this._tileCount = 0;
        return _this;
    }
    Object.defineProperty(GameManager.prototype, "reelCount", {
        get: function () {
            if (this._reelCount <= 0) {
                try {
                    this._reelCount = this.machine.getComponent('Machine').numberOfReels;
                }
                catch (error) {
                    this._reelCount = 0;
                }
            }
            return this._reelCount;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(GameManager.prototype, "tileCount", {
        get: function () {
            if (this._tileCount <= 0) {
                try {
                    this._tileCount = this.machine.getChildByName('Reel').getChildByName('In').getChildByName('Tile').getComponent('Tile').tileCount;
                }
                catch (error) {
                    this._tileCount = 0;
                }
            }
            return this._tileCount;
        },
        enumerable: false,
        configurable: true
    });
    // ====================================================
    // Methods
    // ====================================================
    GameManager.prototype.start = function () {
        this.machine.getComponent('Machine').createMachine();
    };
    GameManager.prototype.update = function () {
        if (this.block && this.result != null) {
            this.informStop();
            this.result = null;
        }
    };
    GameManager.prototype.click = function () {
        cc.audioEngine.playEffect(this.audioClick, false);
        if (this.machine.getComponent('Machine').spinning === false) {
            this.block = false;
            this.machine.getComponent('Machine').spin();
            this.requestResult();
        }
        else if (!this.block) {
            this.block = true;
            this.machine.getComponent('Machine').lock();
        }
    };
    GameManager.prototype.requestResult = function () {
        return __awaiter(this, void 0, Promise, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        this.result = null;
                        _a = this;
                        return [4 /*yield*/, this.getAnswer()];
                    case 1:
                        _a.result = _b.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    GameManager.prototype.getAnswer = function () {
        var _this = this;
        return new Promise(function (resolve) {
            setTimeout(function () {
                var result = SlotRoller_1.SlotRoller.roll(_this.tileCount, _this.reelCount);
                resolve(result);
                NetworkLog_1.NetworkLog.appendResult(result);
            }, 1000 + 500 * Math.random());
        });
    };
    GameManager.prototype.informStop = function () {
        this.machine.getComponent('Machine').stop(this.result);
    };
    __decorate([
        property(cc.Node)
    ], GameManager.prototype, "machine", void 0);
    __decorate([
        property({ type: cc.AudioClip })
    ], GameManager.prototype, "audioClick", void 0);
    GameManager = __decorate([
        ccclass
    ], GameManager);
    return GameManager;
}(cc.Component));
exports.default = GameManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcR2FtZU1hbmFnZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsaURBQStDO0FBQy9DLDJDQUEwQztBQUVwQyxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUF5QywrQkFBWTtJQUFyRDtRQUFBLHFFQXdGQztRQXRGQyx1REFBdUQ7UUFDdkQsYUFBYTtRQUNiLHVEQUF1RDtRQUV2RCxhQUFPLEdBQVksSUFBSSxDQUFDO1FBR3hCLGdCQUFVLEdBQWlCLElBQUksQ0FBQztRQUV4QixXQUFLLEdBQUcsS0FBSyxDQUFDO1FBQ2QsWUFBTSxHQUFZLElBQUksQ0FBQztRQUV2QixnQkFBVSxHQUFXLENBQUMsQ0FBQztRQWF2QixnQkFBVSxHQUFXLENBQUMsQ0FBQzs7SUE2RGpDLENBQUM7SUF6RUMsc0JBQUksa0NBQVM7YUFBYjtZQUNFLElBQUksSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLEVBQUU7Z0JBQ3hCLElBQUk7b0JBQ0YsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxhQUFhLENBQUM7aUJBQ3RFO2dCQUFDLE9BQU8sS0FBSyxFQUFFO29CQUNkLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO2lCQUNyQjthQUNGO1lBRUQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO1FBQ3pCLENBQUM7OztPQUFBO0lBR0Qsc0JBQUksa0NBQVM7YUFBYjtZQUNFLElBQUksSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLEVBQUU7Z0JBQ3hCLElBQUk7b0JBQ0YsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUM7aUJBQ2xJO2dCQUFDLE9BQU8sS0FBSyxFQUFFO29CQUNkLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO2lCQUNyQjthQUNGO1lBRUQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO1FBQ3pCLENBQUM7OztPQUFBO0lBR0QsdURBQXVEO0lBQ3ZELFVBQVU7SUFDVix1REFBdUQ7SUFDdkQsMkJBQUssR0FBTDtRQUNFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3ZELENBQUM7SUFFRCw0QkFBTSxHQUFOO1FBQ0UsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxFQUFFO1lBQ3JDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNsQixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztTQUNwQjtJQUNILENBQUM7SUFFRCwyQkFBSyxHQUFMO1FBQ0UsRUFBRSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUNsRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsS0FBSyxLQUFLLEVBQUU7WUFDM0QsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7WUFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDNUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1NBQ3RCO2FBQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDdEIsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7WUFDbEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7U0FDN0M7SUFDSCxDQUFDO0lBRUssbUNBQWEsR0FBbkI7dUNBQXVCLE9BQU87Ozs7O3dCQUM1QixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQzt3QkFDbkIsS0FBQSxJQUFJLENBQUE7d0JBQVUscUJBQU0sSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFBOzt3QkFBcEMsR0FBSyxNQUFNLEdBQUcsU0FBc0IsQ0FBQzs7Ozs7S0FDdEM7SUFFRCwrQkFBUyxHQUFUO1FBQUEsaUJBUUM7UUFQQyxPQUFPLElBQUksT0FBTyxDQUFVLFVBQUEsT0FBTztZQUNqQyxVQUFVLENBQUM7Z0JBQ1QsSUFBTSxNQUFNLEdBQVksdUJBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ3hFLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDaEIsdUJBQVUsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbEMsQ0FBQyxFQUFFLElBQUksR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDakMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsZ0NBQVUsR0FBVjtRQUNFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDekQsQ0FBQztJQTlFRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO2dEQUNNO0lBR3hCO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQzttREFDRDtJQVRiLFdBQVc7UUFEL0IsT0FBTztPQUNhLFdBQVcsQ0F3Ri9CO0lBQUQsa0JBQUM7Q0F4RkQsQUF3RkMsQ0F4RndDLEVBQUUsQ0FBQyxTQUFTLEdBd0ZwRDtrQkF4Rm9CLFdBQVciLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTbG90Um9sbGVyIH0gZnJvbSBcIi4vc2xvdHMvU2xvdFJvbGxlclwiXG5pbXBvcnQgeyBOZXR3b3JrTG9nIH0gZnJvbSBcIi4vTmV0d29ya0xvZ1wiO1xuXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgR2FtZU1hbmFnZXIgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgLy8gQXR0cmlidXRlc1xuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gIEBwcm9wZXJ0eShjYy5Ob2RlKVxuICBtYWNoaW5lOiBjYy5Ob2RlID0gbnVsbDtcblxuICBAcHJvcGVydHkoeyB0eXBlOiBjYy5BdWRpb0NsaXAgfSlcbiAgYXVkaW9DbGljazogY2MuQXVkaW9DbGlwID0gbnVsbDtcblxuICBwcml2YXRlIGJsb2NrID0gZmFsc2U7XG4gIHByaXZhdGUgcmVzdWx0OiBJUmVzdWx0ID0gbnVsbDtcbiAgXG4gIHByaXZhdGUgX3JlZWxDb3VudDogbnVtYmVyID0gMDtcbiAgZ2V0IHJlZWxDb3VudCgpOiBudW1iZXIge1xuICAgIGlmICh0aGlzLl9yZWVsQ291bnQgPD0gMCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgdGhpcy5fcmVlbENvdW50ID0gdGhpcy5tYWNoaW5lLmdldENvbXBvbmVudCgnTWFjaGluZScpLm51bWJlck9mUmVlbHM7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aGlzLl9yZWVsQ291bnQgPSAwO1xuICAgICAgfVxuICAgIH1cbiAgICBcbiAgICByZXR1cm4gdGhpcy5fcmVlbENvdW50O1xuICB9XG4gIFxuICBwcml2YXRlIF90aWxlQ291bnQ6IG51bWJlciA9IDA7XG4gIGdldCB0aWxlQ291bnQoKTogbnVtYmVyIHtcbiAgICBpZiAodGhpcy5fdGlsZUNvdW50IDw9IDApIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHRoaXMuX3RpbGVDb3VudCA9IHRoaXMubWFjaGluZS5nZXRDaGlsZEJ5TmFtZSgnUmVlbCcpLmdldENoaWxkQnlOYW1lKCdJbicpLmdldENoaWxkQnlOYW1lKCdUaWxlJykuZ2V0Q29tcG9uZW50KCdUaWxlJykudGlsZUNvdW50O1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhpcy5fdGlsZUNvdW50ID0gMDtcbiAgICAgIH1cbiAgICB9XG4gICAgXG4gICAgcmV0dXJuIHRoaXMuX3RpbGVDb3VudDtcbiAgfVxuXG5cbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAvLyBNZXRob2RzXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgc3RhcnQoKTogdm9pZCB7XG4gICAgdGhpcy5tYWNoaW5lLmdldENvbXBvbmVudCgnTWFjaGluZScpLmNyZWF0ZU1hY2hpbmUoKTtcbiAgfVxuXG4gIHVwZGF0ZSgpOiB2b2lkIHtcbiAgICBpZiAodGhpcy5ibG9jayAmJiB0aGlzLnJlc3VsdCAhPSBudWxsKSB7XG4gICAgICB0aGlzLmluZm9ybVN0b3AoKTtcbiAgICAgIHRoaXMucmVzdWx0ID0gbnVsbDtcbiAgICB9XG4gIH1cblxuICBjbGljaygpOiB2b2lkIHtcbiAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuYXVkaW9DbGljaywgZmFsc2UpO1xuICAgIGlmICh0aGlzLm1hY2hpbmUuZ2V0Q29tcG9uZW50KCdNYWNoaW5lJykuc3Bpbm5pbmcgPT09IGZhbHNlKSB7XG4gICAgICB0aGlzLmJsb2NrID0gZmFsc2U7XG4gICAgICB0aGlzLm1hY2hpbmUuZ2V0Q29tcG9uZW50KCdNYWNoaW5lJykuc3BpbigpO1xuICAgICAgdGhpcy5yZXF1ZXN0UmVzdWx0KCk7XG4gICAgfSBlbHNlIGlmICghdGhpcy5ibG9jaykge1xuICAgICAgdGhpcy5ibG9jayA9IHRydWU7XG4gICAgICB0aGlzLm1hY2hpbmUuZ2V0Q29tcG9uZW50KCdNYWNoaW5lJykubG9jaygpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIHJlcXVlc3RSZXN1bHQoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdGhpcy5yZXN1bHQgPSBudWxsO1xuICAgIHRoaXMucmVzdWx0ID0gYXdhaXQgdGhpcy5nZXRBbnN3ZXIoKTtcbiAgfVxuXG4gIGdldEFuc3dlcigpOiBQcm9taXNlPElSZXN1bHQ+IHtcbiAgICByZXR1cm4gbmV3IFByb21pc2U8SVJlc3VsdD4ocmVzb2x2ZSA9PiB7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgY29uc3QgcmVzdWx0OiBJUmVzdWx0ID0gU2xvdFJvbGxlci5yb2xsKHRoaXMudGlsZUNvdW50LCB0aGlzLnJlZWxDb3VudCk7XG4gICAgICAgIHJlc29sdmUocmVzdWx0KTtcbiAgICAgICAgTmV0d29ya0xvZy5hcHBlbmRSZXN1bHQocmVzdWx0KTtcbiAgICAgIH0sIDEwMDAgKyA1MDAgKiBNYXRoLnJhbmRvbSgpKTtcbiAgICB9KTtcbiAgfVxuXG4gIGluZm9ybVN0b3AoKTogdm9pZCB7XG4gICAgdGhpcy5tYWNoaW5lLmdldENvbXBvbmVudCgnTWFjaGluZScpLnN0b3AodGhpcy5yZXN1bHQpO1xuICB9XG5cbiAgXG5cbn1cbiJdfQ==