
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/migration/use_reversed_rotateBy');
require('./assets/migration/use_v2.1-2.2.1_cc.Toggle_event');
require('./assets/scripts/Dice');
require('./assets/scripts/GameManager');
require('./assets/scripts/LogGenerator');
require('./assets/scripts/NetworkLog');
require('./assets/scripts/SlotEnum');
require('./assets/scripts/slots/IResult');
require('./assets/scripts/slots/Machine');
require('./assets/scripts/slots/Reel');
require('./assets/scripts/slots/SlotRoller');
require('./assets/scripts/slots/Tile');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/migration/use_reversed_rotateBy.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ed7dakMh5xHTr5n8dEFcWgu', 'use_reversed_rotateBy');
// migration/use_reversed_rotateBy.js

"use strict";

cc.RotateBy._reverse = true;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcbWlncmF0aW9uXFx1c2VfcmV2ZXJzZWRfcm90YXRlQnkuanMiXSwibmFtZXMiOlsiY2MiLCJSb3RhdGVCeSIsIl9yZXZlcnNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUNBQSxFQUFFLENBQUNDLFFBQUgsQ0FBWUMsUUFBWixHQUF1QixJQUF2QiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmNjLlJvdGF0ZUJ5Ll9yZXZlcnNlID0gdHJ1ZTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/slots/Machine.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e75a3lPjzhNLb8z3HrM6PP0', 'Machine');
// scripts/slots/Machine.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var SlotEnum_1 = require("../SlotEnum");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Machine = /** @class */ (function (_super) {
    __extends(Machine, _super);
    function Machine() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.button = null;
        _this.glows = null;
        _this._reelPrefab = null;
        _this.audioJackpot = null;
        _this.Jackpot = null;
        _this._numberOfReels = 3;
        _this.reels = [];
        _this.spinning = false;
        return _this;
    }
    Object.defineProperty(Machine.prototype, "reelPrefab", {
        get: function () {
            return this._reelPrefab;
        },
        set: function (newPrefab) {
            this._reelPrefab = newPrefab;
            this.node.removeAllChildren();
            if (newPrefab !== null) {
                this.createMachine();
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Machine.prototype, "numberOfReels", {
        get: function () {
            return this._numberOfReels;
        },
        set: function (newNumber) {
            this._numberOfReels = newNumber;
            if (this.reelPrefab !== null) {
                this.createMachine();
            }
        },
        enumerable: false,
        configurable: true
    });
    Machine.prototype.createMachine = function () {
        this.node.destroyAllChildren();
        this.reels = [];
        var newReel;
        for (var i = 0; i < this.numberOfReels; i += 1) {
            newReel = cc.instantiate(this.reelPrefab);
            this.node.addChild(newReel);
            this.reels[i] = newReel;
            var reelScript = newReel.getComponent('Reel');
            reelScript.shuffle();
            reelScript.reelAnchor.getComponent(cc.Layout).enabled = false;
        }
        this.node.getComponent(cc.Widget).updateAlignment();
    };
    Machine.prototype.spin = function () {
        this.spinning = true;
        this.button.getChildByName('Label').getComponent(cc.Label).string = 'STOP';
        this.disableGlow();
        for (var i = 0; i < this.numberOfReels; i += 1) {
            var theReel = this.reels[i].getComponent('Reel');
            if (i % 2) {
                theReel.spinDirection = SlotEnum_1.default.Direction.Down;
            }
            else {
                theReel.spinDirection = SlotEnum_1.default.Direction.Up;
            }
            theReel.doSpin(0.03 * i);
        }
    };
    Machine.prototype.lock = function () {
        this.button.getComponent(cc.Button).interactable = false;
    };
    Machine.prototype.stop = function (result) {
        var _this = this;
        if (result === void 0) { result = null; }
        setTimeout(function () {
            _this.spinning = false;
            _this.button.getComponent(cc.Button).interactable = true;
            _this.button.getChildByName('Label').getComponent(cc.Label).string = 'SPIN';
            _this.enableGlow(result);
        }, 2500);
        var rngMod = Math.random() / 2;
        var _loop_1 = function (i) {
            var spinDelay = i < 2 + rngMod ? i / 4 : rngMod * (i - 2) + i / 4;
            var theReel = this_1.reels[i].getComponent('Reel');
            setTimeout(function () {
                theReel.readyStop(result.reels[i]);
            }, spinDelay * 1000);
        };
        var this_1 = this;
        for (var i = 0; i < this.numberOfReels; i += 1) {
            _loop_1(i);
        }
    };
    Machine.prototype.enableGlow = function (result) {
        if (result === void 0) { result = null; }
        for (var _i = 0, _a = result.equalLines; _i < _a.length; _i++) {
            var lineIndex = _a[_i];
            try {
                var line = this.glows.children[lineIndex];
                for (var _b = 0, _c = line.children; _b < _c.length; _b++) {
                    var glow = _c[_b];
                    var skel = glow.getComponent('sp.Skeleton');
                    skel.animation = "loop";
                    cc.audioEngine.playEffect(this.audioJackpot, false);
                    this.Jackpot.active = true;
                }
            }
            catch (error) {
                console.log(error);
            }
        }
    };
    Machine.prototype.disableGlow = function () {
        try {
            for (var _i = 0, _a = this.glows.children; _i < _a.length; _i++) {
                var line = _a[_i];
                for (var _b = 0, _c = line.children; _b < _c.length; _b++) {
                    var glow = _c[_b];
                    var skel = glow.getComponent('sp.Skeleton');
                    skel.animation = null;
                    this.Jackpot.active = false;
                }
            }
        }
        catch (error) {
            console.log(error);
        }
    };
    __decorate([
        property(cc.Node)
    ], Machine.prototype, "button", void 0);
    __decorate([
        property(cc.Node)
    ], Machine.prototype, "glows", void 0);
    __decorate([
        property(cc.Prefab)
    ], Machine.prototype, "_reelPrefab", void 0);
    __decorate([
        property({ type: cc.AudioClip })
    ], Machine.prototype, "audioJackpot", void 0);
    __decorate([
        property(cc.Node)
    ], Machine.prototype, "Jackpot", void 0);
    __decorate([
        property({ type: cc.Prefab })
    ], Machine.prototype, "reelPrefab", null);
    __decorate([
        property({ type: cc.Integer })
    ], Machine.prototype, "_numberOfReels", void 0);
    __decorate([
        property({ type: cc.Integer, range: [3, 6], slide: true })
    ], Machine.prototype, "numberOfReels", null);
    Machine = __decorate([
        ccclass
    ], Machine);
    return Machine;
}(cc.Component));
exports.default = Machine;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcc2xvdHNcXE1hY2hpbmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsd0NBQThCO0FBRXhCLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQXFDLDJCQUFZO0lBQWpEO1FBQUEscUVBMElDO1FBeElRLFlBQU0sR0FBWSxJQUFJLENBQUM7UUFHdkIsV0FBSyxHQUFZLElBQUksQ0FBQztRQUd0QixpQkFBVyxHQUFHLElBQUksQ0FBQztRQUcxQixrQkFBWSxHQUFpQixJQUFJLENBQUM7UUFHM0IsYUFBTyxHQUFZLElBQUksQ0FBQztRQWlCeEIsb0JBQWMsR0FBRyxDQUFDLENBQUM7UUFlbEIsV0FBSyxHQUFHLEVBQUUsQ0FBQztRQUVaLGNBQVEsR0FBRyxLQUFLLENBQUM7O0lBMEYxQixDQUFDO0lBekhDLHNCQUFJLCtCQUFVO2FBQWQ7WUFDRSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDMUIsQ0FBQzthQUVELFVBQWUsU0FBb0I7WUFDakMsSUFBSSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUM7WUFDN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1lBRTlCLElBQUksU0FBUyxLQUFLLElBQUksRUFBRTtnQkFDdEIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2FBQ3RCO1FBQ0gsQ0FBQzs7O09BVEE7SUFlRCxzQkFBSSxrQ0FBYTthQUFqQjtZQUNFLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQztRQUM3QixDQUFDO2FBRUQsVUFBa0IsU0FBaUI7WUFDakMsSUFBSSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7WUFFaEMsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLElBQUksRUFBRTtnQkFDNUIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2FBQ3RCO1FBQ0gsQ0FBQzs7O09BUkE7SUFjRCwrQkFBYSxHQUFiO1FBQ0UsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQy9CLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBRWhCLElBQUksT0FBZ0IsQ0FBQztRQUNyQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzlDLE9BQU8sR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUMxQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUM1QixJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQztZQUV4QixJQUFNLFVBQVUsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2hELFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNyQixVQUFVLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztTQUMvRDtRQUVELElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUN0RCxDQUFDO0lBRUQsc0JBQUksR0FBSjtRQUNFLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUN6RSxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFFckIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUM5QyxJQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUVuRCxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ1QsT0FBTyxDQUFDLGFBQWEsR0FBRyxrQkFBRyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7YUFDNUM7aUJBQU07Z0JBQ0wsT0FBTyxDQUFDLGFBQWEsR0FBRyxrQkFBRyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7YUFDMUM7WUFFQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQztTQUM1QjtJQUNILENBQUM7SUFFRCxzQkFBSSxHQUFKO1FBQ0UsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7SUFDM0QsQ0FBQztJQUVELHNCQUFJLEdBQUosVUFBSyxNQUFzQjtRQUEzQixpQkFpQkM7UUFqQkksdUJBQUEsRUFBQSxhQUFzQjtRQUN6QixVQUFVLENBQUM7WUFDVCxLQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztZQUN0QixLQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztZQUN0RCxLQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7WUFDN0UsS0FBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMxQixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFVCxJQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dDQUN4QixDQUFDO1lBQ1IsSUFBTSxTQUFTLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3BFLElBQU0sT0FBTyxHQUFHLE9BQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUVuRCxVQUFVLENBQUM7Z0JBQ1QsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDckMsQ0FBQyxFQUFFLFNBQVMsR0FBRyxJQUFJLENBQUMsQ0FBQzs7O1FBTnZCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUMsSUFBSSxDQUFDO29CQUFyQyxDQUFDO1NBT1Q7SUFDSCxDQUFDO0lBRUMsNEJBQVUsR0FBVixVQUFXLE1BQXNCO1FBQXRCLHVCQUFBLEVBQUEsYUFBc0I7UUFDN0IsS0FBd0IsVUFBaUIsRUFBakIsS0FBQSxNQUFNLENBQUMsVUFBVSxFQUFqQixjQUFpQixFQUFqQixJQUFpQixFQUFFO1lBQXRDLElBQU0sU0FBUyxTQUFBO1lBQ3RCLElBQUk7Z0JBQ0YsSUFBTSxJQUFJLEdBQVksSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUE7Z0JBQ3BELEtBQW1CLFVBQWEsRUFBYixLQUFBLElBQUksQ0FBQyxRQUFRLEVBQWIsY0FBYSxFQUFiLElBQWEsRUFBRTtvQkFBN0IsSUFBTSxJQUFJLFNBQUE7b0JBQ2IsSUFBTSxJQUFJLEdBQWdCLElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUM7b0JBQ3pELElBQUksQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDO29CQUN4QixFQUFFLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO29CQUNwRCxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7aUJBQzlCO2FBQ0Y7WUFBQyxPQUFPLEtBQUssRUFBRTtnQkFDZCxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3BCO1NBQ0Y7SUFDSCxDQUFDO0lBRUQsNkJBQVcsR0FBWDtRQUNFLElBQUk7WUFDRixLQUFtQixVQUFtQixFQUFuQixLQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFuQixjQUFtQixFQUFuQixJQUFtQixFQUFFO2dCQUFuQyxJQUFNLElBQUksU0FBQTtnQkFDYixLQUFtQixVQUFhLEVBQWIsS0FBQSxJQUFJLENBQUMsUUFBUSxFQUFiLGNBQWEsRUFBYixJQUFhLEVBQUU7b0JBQTdCLElBQU0sSUFBSSxTQUFBO29CQUNiLElBQU0sSUFBSSxHQUFnQixJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO29CQUN6RCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztvQkFDdEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO2lCQUMvQjthQUNGO1NBQ0Y7UUFBQyxPQUFPLEtBQUssRUFBRTtZQUNkLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDcEI7SUFDSCxDQUFDO0lBdklEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7MkNBQ1k7SUFHOUI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzswQ0FDVztJQUc3QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDO2dEQUNNO0lBRzFCO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQztpREFDQztJQUdsQztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzRDQUNhO0lBRy9CO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQzs2Q0FHN0I7SUFZRDtRQURDLFFBQVEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7bURBQ0w7SUFHMUI7UUFEQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDO2dEQUcxRDtJQXBDa0IsT0FBTztRQUQzQixPQUFPO09BQ2EsT0FBTyxDQTBJM0I7SUFBRCxjQUFDO0NBMUlELEFBMElDLENBMUlvQyxFQUFFLENBQUMsU0FBUyxHQTBJaEQ7a0JBMUlvQixPQUFPIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEF1eCBmcm9tICcuLi9TbG90RW51bSc7XG5cbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNYWNoaW5lIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcbiAgQHByb3BlcnR5KGNjLk5vZGUpXG4gIHB1YmxpYyBidXR0b246IGNjLk5vZGUgPSBudWxsO1xuXG4gIEBwcm9wZXJ0eShjYy5Ob2RlKVxuICBwdWJsaWMgZ2xvd3M6IGNjLk5vZGUgPSBudWxsO1xuXG4gIEBwcm9wZXJ0eShjYy5QcmVmYWIpXG4gIHB1YmxpYyBfcmVlbFByZWZhYiA9IG51bGw7XG5cbiAgQHByb3BlcnR5KHsgdHlwZTogY2MuQXVkaW9DbGlwIH0pXG4gIGF1ZGlvSmFja3BvdDogY2MuQXVkaW9DbGlwID0gbnVsbDtcblxuICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgcHVibGljIEphY2twb3Q6IGNjLk5vZGUgPSBudWxsO1xuXG4gIEBwcm9wZXJ0eSh7IHR5cGU6IGNjLlByZWZhYiB9KVxuICBnZXQgcmVlbFByZWZhYigpOiBjYy5QcmVmYWIge1xuICAgIHJldHVybiB0aGlzLl9yZWVsUHJlZmFiO1xuICB9XG5cbiAgc2V0IHJlZWxQcmVmYWIobmV3UHJlZmFiOiBjYy5QcmVmYWIpIHtcbiAgICB0aGlzLl9yZWVsUHJlZmFiID0gbmV3UHJlZmFiO1xuICAgIHRoaXMubm9kZS5yZW1vdmVBbGxDaGlsZHJlbigpO1xuXG4gICAgaWYgKG5ld1ByZWZhYiAhPT0gbnVsbCkge1xuICAgICAgdGhpcy5jcmVhdGVNYWNoaW5lKCk7XG4gICAgfVxuICB9XG5cbiAgQHByb3BlcnR5KHsgdHlwZTogY2MuSW50ZWdlciB9KVxuICBwdWJsaWMgX251bWJlck9mUmVlbHMgPSAzO1xuXG4gIEBwcm9wZXJ0eSh7IHR5cGU6IGNjLkludGVnZXIsIHJhbmdlOiBbMywgNl0sIHNsaWRlOiB0cnVlIH0pXG4gIGdldCBudW1iZXJPZlJlZWxzKCk6IG51bWJlciB7XG4gICAgcmV0dXJuIHRoaXMuX251bWJlck9mUmVlbHM7XG4gIH1cblxuICBzZXQgbnVtYmVyT2ZSZWVscyhuZXdOdW1iZXI6IG51bWJlcikge1xuICAgIHRoaXMuX251bWJlck9mUmVlbHMgPSBuZXdOdW1iZXI7XG5cbiAgICBpZiAodGhpcy5yZWVsUHJlZmFiICE9PSBudWxsKSB7XG4gICAgICB0aGlzLmNyZWF0ZU1hY2hpbmUoKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHJlZWxzID0gW107XG5cbiAgcHVibGljIHNwaW5uaW5nID0gZmFsc2U7XG5cbiAgY3JlYXRlTWFjaGluZSgpOiB2b2lkIHtcbiAgICB0aGlzLm5vZGUuZGVzdHJveUFsbENoaWxkcmVuKCk7XG4gICAgdGhpcy5yZWVscyA9IFtdO1xuXG4gICAgbGV0IG5ld1JlZWw6IGNjLk5vZGU7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLm51bWJlck9mUmVlbHM7IGkgKz0gMSkge1xuICAgICAgbmV3UmVlbCA9IGNjLmluc3RhbnRpYXRlKHRoaXMucmVlbFByZWZhYik7XG4gICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQobmV3UmVlbCk7XG4gICAgICB0aGlzLnJlZWxzW2ldID0gbmV3UmVlbDtcblxuICAgICAgY29uc3QgcmVlbFNjcmlwdCA9IG5ld1JlZWwuZ2V0Q29tcG9uZW50KCdSZWVsJyk7XG4gICAgICByZWVsU2NyaXB0LnNodWZmbGUoKTtcbiAgICAgIHJlZWxTY3JpcHQucmVlbEFuY2hvci5nZXRDb21wb25lbnQoY2MuTGF5b3V0KS5lbmFibGVkID0gZmFsc2U7XG4gICAgfVxuXG4gICAgdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5XaWRnZXQpLnVwZGF0ZUFsaWdubWVudCgpO1xuICB9XG5cbiAgc3BpbigpOiB2b2lkIHtcbiAgICB0aGlzLnNwaW5uaW5nID0gdHJ1ZTtcbiAgICB0aGlzLmJ1dHRvbi5nZXRDaGlsZEJ5TmFtZSgnTGFiZWwnKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9ICdTVE9QJztcbiAgICAgIHRoaXMuZGlzYWJsZUdsb3coKTtcblxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5udW1iZXJPZlJlZWxzOyBpICs9IDEpIHtcbiAgICAgIGNvbnN0IHRoZVJlZWwgPSB0aGlzLnJlZWxzW2ldLmdldENvbXBvbmVudCgnUmVlbCcpO1xuXG4gICAgICBpZiAoaSAlIDIpIHtcbiAgICAgICAgdGhlUmVlbC5zcGluRGlyZWN0aW9uID0gQXV4LkRpcmVjdGlvbi5Eb3duO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhlUmVlbC5zcGluRGlyZWN0aW9uID0gQXV4LkRpcmVjdGlvbi5VcDtcbiAgICAgIH1cblxuICAgICAgICB0aGVSZWVsLmRvU3BpbigwLjAzICogaSk7XG4gICAgfVxuICB9XG5cbiAgbG9jaygpOiB2b2lkIHtcbiAgICB0aGlzLmJ1dHRvbi5nZXRDb21wb25lbnQoY2MuQnV0dG9uKS5pbnRlcmFjdGFibGUgPSBmYWxzZTtcbiAgfVxuXG4gIHN0b3AocmVzdWx0OiBJUmVzdWx0ID0gbnVsbCk6IHZvaWQge1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGhpcy5zcGlubmluZyA9IGZhbHNlO1xuICAgICAgdGhpcy5idXR0b24uZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikuaW50ZXJhY3RhYmxlID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5idXR0b24uZ2V0Q2hpbGRCeU5hbWUoJ0xhYmVsJykuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSAnU1BJTic7XG4gICAgICB0aGlzLmVuYWJsZUdsb3cocmVzdWx0KTtcbiAgICB9LCAyNTAwKTtcblxuICAgIGNvbnN0IHJuZ01vZCA9IE1hdGgucmFuZG9tKCkgLyAyO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5udW1iZXJPZlJlZWxzOyBpICs9IDEpIHtcbiAgICAgIGNvbnN0IHNwaW5EZWxheSA9IGkgPCAyICsgcm5nTW9kID8gaSAvIDQgOiBybmdNb2QgKiAoaSAtIDIpICsgaSAvIDQ7XG4gICAgICBjb25zdCB0aGVSZWVsID0gdGhpcy5yZWVsc1tpXS5nZXRDb21wb25lbnQoJ1JlZWwnKTtcblxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHRoZVJlZWwucmVhZHlTdG9wKHJlc3VsdC5yZWVsc1tpXSk7XG4gICAgICB9LCBzcGluRGVsYXkgKiAxMDAwKTtcbiAgICB9XG4gIH1cblxuICAgIGVuYWJsZUdsb3cocmVzdWx0OiBJUmVzdWx0ID0gbnVsbCk6IHZvaWQge1xuICAgICAgICBmb3IgKGNvbnN0IGxpbmVJbmRleCBvZiByZXN1bHQuZXF1YWxMaW5lcykge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgbGluZTogY2MuTm9kZSA9IHRoaXMuZ2xvd3MuY2hpbGRyZW5bbGluZUluZGV4XVxuICAgICAgICBmb3IgKGNvbnN0IGdsb3cgb2YgbGluZS5jaGlsZHJlbikge1xuICAgICAgICAgIGNvbnN0IHNrZWw6IHNwLlNrZWxldG9uID0gZ2xvdy5nZXRDb21wb25lbnQoJ3NwLlNrZWxldG9uJyk7XG4gICAgICAgICAgICBza2VsLmFuaW1hdGlvbiA9IFwibG9vcFwiO1xuICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLmF1ZGlvSmFja3BvdCwgZmFsc2UpO1xuICAgICAgICAgICAgdGhpcy5KYWNrcG90LmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBkaXNhYmxlR2xvdygpOiB2b2lkIHtcbiAgICB0cnkge1xuICAgICAgZm9yIChjb25zdCBsaW5lIG9mIHRoaXMuZ2xvd3MuY2hpbGRyZW4pIHtcbiAgICAgICAgZm9yIChjb25zdCBnbG93IG9mIGxpbmUuY2hpbGRyZW4pIHtcbiAgICAgICAgICBjb25zdCBza2VsOiBzcC5Ta2VsZXRvbiA9IGdsb3cuZ2V0Q29tcG9uZW50KCdzcC5Ta2VsZXRvbicpO1xuICAgICAgICAgICAgc2tlbC5hbmltYXRpb24gPSBudWxsO1xuICAgICAgICAgICAgdGhpcy5KYWNrcG90LmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcbiAgICB9XG4gIH1cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Dice.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8eabasLOYlMH6BvxJ0Lmor3', 'Dice');
// scripts/Dice.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Dice = void 0;
var Dice = /** @class */ (function () {
    function Dice() {
    }
    /**
     * Returns a random integer between min (inclusive) and max (exclusive).
     * @param min Minimum value (inclusive).
     * @param max Maximum value (exclusive).
     */
    Dice.randomInt = function (min, max) {
        return Math.floor(Math.random() * (max - min)) + min;
    };
    /**
     * Returns a random integer between 0 (inclusive) and max (exclusive).
     * @param max Maximum value (exclusive).
     */
    Dice.roll = function (max) {
        return Dice.randomInt(0, max);
    };
    /**
     * Returns a random integer between 0 (inclusive) and max (exclusive) that is different from a specific value.
     * @param max Maximum value (exclusive).
     * @param except Any result except by this number.
     */
    Dice.rollDifferent = function (max, except) {
        var roll = Dice.roll(max - 1);
        return (roll < except) ? roll : roll + 1;
    };
    return Dice;
}());
exports.Dice = Dice;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcRGljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtJQUFBO0lBMkJBLENBQUM7SUExQkc7Ozs7T0FJRztJQUNXLGNBQVMsR0FBdkIsVUFBeUIsR0FBVyxFQUFFLEdBQVc7UUFDN0MsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUN6RCxDQUFDO0lBRUQ7OztPQUdHO0lBQ1csU0FBSSxHQUFsQixVQUFvQixHQUFXO1FBQzNCLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDbEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDVyxrQkFBYSxHQUEzQixVQUE2QixHQUFXLEVBQUUsTUFBYztRQUNwRCxJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsQ0FBQztRQUM5QixPQUFPLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNMLFdBQUM7QUFBRCxDQTNCQSxBQTJCQyxJQUFBO0FBM0JxQixvQkFBSSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBhYnN0cmFjdCBjbGFzcyBEaWNlIHtcbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGEgcmFuZG9tIGludGVnZXIgYmV0d2VlbiBtaW4gKGluY2x1c2l2ZSkgYW5kIG1heCAoZXhjbHVzaXZlKS5cbiAgICAgKiBAcGFyYW0gbWluIE1pbmltdW0gdmFsdWUgKGluY2x1c2l2ZSkuXG4gICAgICogQHBhcmFtIG1heCBNYXhpbXVtIHZhbHVlIChleGNsdXNpdmUpLlxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgcmFuZG9tSW50IChtaW46IG51bWJlciwgbWF4OiBudW1iZXIpIHtcbiAgICAgICAgcmV0dXJuIE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIChtYXggLSBtaW4pKSArIG1pbjtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGEgcmFuZG9tIGludGVnZXIgYmV0d2VlbiAwIChpbmNsdXNpdmUpIGFuZCBtYXggKGV4Y2x1c2l2ZSkuXG4gICAgICogQHBhcmFtIG1heCBNYXhpbXVtIHZhbHVlIChleGNsdXNpdmUpLlxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgcm9sbCAobWF4OiBudW1iZXIpIHtcbiAgICAgICAgcmV0dXJuIERpY2UucmFuZG9tSW50KDAsIG1heCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyBhIHJhbmRvbSBpbnRlZ2VyIGJldHdlZW4gMCAoaW5jbHVzaXZlKSBhbmQgbWF4IChleGNsdXNpdmUpIHRoYXQgaXMgZGlmZmVyZW50IGZyb20gYSBzcGVjaWZpYyB2YWx1ZS5cbiAgICAgKiBAcGFyYW0gbWF4IE1heGltdW0gdmFsdWUgKGV4Y2x1c2l2ZSkuXG4gICAgICogQHBhcmFtIGV4Y2VwdCBBbnkgcmVzdWx0IGV4Y2VwdCBieSB0aGlzIG51bWJlci5cbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHJvbGxEaWZmZXJlbnQgKG1heDogbnVtYmVyLCBleGNlcHQ6IG51bWJlcikge1xuICAgICAgICBjb25zdCByb2xsID0gRGljZS5yb2xsKG1heC0xKTtcbiAgICAgICAgcmV0dXJuIChyb2xsIDwgZXhjZXB0KSA/IHJvbGwgOiByb2xsICsgMTtcbiAgICB9XG59Il19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/LogGenerator.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6c700uea35D1LbqeXU/UA+6', 'LogGenerator');
// scripts/LogGenerator.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogGenerator = void 0;
var SlotRoller_1 = require("./slots/SlotRoller");
/**
 * Generates javascript log files.
 * This class is a helper tool for debug purposes only.
 */
var LogGenerator = /** @class */ (function () {
    function LogGenerator() {
    }
    /**
     * Save text to file and download it.
     * @param filename Generated file name.
     * @param text Text to save.
     */
    LogGenerator.download = function (filename, text) {
        var element = document.createElement('a');
        element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
        element.setAttribute('download', filename);
        element.style.display = 'none';
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
    };
    /**
     * Generate javascript log file and download it.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     * @param length Amount of rolls (iterations) in log history.
     */
    LogGenerator.generateBaseLog = function (tileCount, reelCount, length) {
        var log = [];
        for (var i = 0; i < length; i++) {
            log.push(SlotRoller_1.SlotRoller.roll(tileCount, reelCount));
        }
        LogGenerator.download('log.js', "module.exports = {\n\thistory: " + JSON.stringify(log) + "\n}");
    };
    return LogGenerator;
}());
exports.LogGenerator = LogGenerator;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcTG9nR2VuZXJhdG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGlEQUErQztBQUUvQzs7O0dBR0c7QUFDSDtJQUFBO0lBK0JBLENBQUM7SUE3Qkc7Ozs7T0FJRztJQUNXLHFCQUFRLEdBQXRCLFVBQXVCLFFBQWdCLEVBQUUsSUFBWTtRQUNqRCxJQUFJLE9BQU8sR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLGdDQUFnQyxHQUFHLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDMUYsT0FBTyxDQUFDLFlBQVksQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFDM0MsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDO1FBQy9CLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ25DLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNoQixRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDVyw0QkFBZSxHQUE3QixVQUE4QixTQUFpQixFQUFFLFNBQWlCLEVBQUUsTUFBYztRQUM5RSxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7UUFDYixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzdCLEdBQUcsQ0FBQyxJQUFJLENBQUMsdUJBQVUsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUM7U0FDbkQ7UUFDRCxZQUFZLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxvQ0FBa0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBSyxDQUFDLENBQUM7SUFDaEcsQ0FBQztJQUVMLG1CQUFDO0FBQUQsQ0EvQkEsQUErQkMsSUFBQTtBQS9CcUIsb0NBQVkiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTbG90Um9sbGVyIH0gZnJvbSBcIi4vc2xvdHMvU2xvdFJvbGxlclwiXG5cbi8qKlxuICogR2VuZXJhdGVzIGphdmFzY3JpcHQgbG9nIGZpbGVzLlxuICogVGhpcyBjbGFzcyBpcyBhIGhlbHBlciB0b29sIGZvciBkZWJ1ZyBwdXJwb3NlcyBvbmx5LlxuICovXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgTG9nR2VuZXJhdG9yIHtcblxuICAgIC8qKlxuICAgICAqIFNhdmUgdGV4dCB0byBmaWxlIGFuZCBkb3dubG9hZCBpdC5cbiAgICAgKiBAcGFyYW0gZmlsZW5hbWUgR2VuZXJhdGVkIGZpbGUgbmFtZS5cbiAgICAgKiBAcGFyYW0gdGV4dCBUZXh0IHRvIHNhdmUuXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBkb3dubG9hZChmaWxlbmFtZTogc3RyaW5nLCB0ZXh0OiBzdHJpbmcpOiB2b2lkIHtcbiAgICAgICAgdmFyIGVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlKCdocmVmJywgJ2RhdGE6dGV4dC9wbGFpbjtjaGFyc2V0PXV0Zi04LCcgKyBlbmNvZGVVUklDb21wb25lbnQodGV4dCkpO1xuICAgICAgICBlbGVtZW50LnNldEF0dHJpYnV0ZSgnZG93bmxvYWQnLCBmaWxlbmFtZSk7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUuZGlzcGxheSA9ICdub25lJztcbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChlbGVtZW50KTtcbiAgICAgICAgZWxlbWVudC5jbGljaygpO1xuICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGVsZW1lbnQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdlbmVyYXRlIGphdmFzY3JpcHQgbG9nIGZpbGUgYW5kIGRvd25sb2FkIGl0LlxuICAgICAqIEBwYXJhbSB0aWxlQ291bnQgQW1vdW50IG9mIHVuaXF1ZSB0aWxlIHRleHR1cmVzLlxuICAgICAqIEBwYXJhbSByZWVsQ291bnQgQW1vdW50IG9mIHZlcnRpY2FsIHJvbGxpbmcgbGluZXMgaW4gdGhpcyBtYWNoaW5lLlxuICAgICAqIEBwYXJhbSBsZW5ndGggQW1vdW50IG9mIHJvbGxzIChpdGVyYXRpb25zKSBpbiBsb2cgaGlzdG9yeS5cbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGdlbmVyYXRlQmFzZUxvZyh0aWxlQ291bnQ6IG51bWJlciwgcmVlbENvdW50OiBudW1iZXIsIGxlbmd0aDogbnVtYmVyKSB7XG4gICAgICAgIGxldCBsb2cgPSBbXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgbG9nLnB1c2goU2xvdFJvbGxlci5yb2xsKHRpbGVDb3VudCwgcmVlbENvdW50KSk7XG4gICAgICAgIH1cbiAgICAgICAgTG9nR2VuZXJhdG9yLmRvd25sb2FkKCdsb2cuanMnLCBgbW9kdWxlLmV4cG9ydHMgPSB7XFxuXFx0aGlzdG9yeTogJHtKU09OLnN0cmluZ2lmeShsb2cpfVxcbn1gKTtcbiAgICB9XG4gICAgXG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/SlotEnum.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'cbbb2wH3jBHYJaS87r8RQdn', 'SlotEnum');
// scripts/SlotEnum.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var ccclass = cc._decorator.ccclass;
var Direction;
(function (Direction) {
    Direction[Direction["Up"] = 0] = "Up";
    Direction[Direction["Down"] = 1] = "Down";
})(Direction || (Direction = {}));
var SlotEnum = /** @class */ (function (_super) {
    __extends(SlotEnum, _super);
    function SlotEnum() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SlotEnum.Direction = Direction;
    SlotEnum = __decorate([
        ccclass
    ], SlotEnum);
    return SlotEnum;
}(cc.Component));
exports.default = SlotEnum;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcU2xvdEVudW0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQVEsSUFBQSxPQUFPLEdBQUssRUFBRSxDQUFDLFVBQVUsUUFBbEIsQ0FBbUI7QUFFbEMsSUFBSyxTQUdKO0FBSEQsV0FBSyxTQUFTO0lBQ1oscUNBQUUsQ0FBQTtJQUNGLHlDQUFJLENBQUE7QUFDTixDQUFDLEVBSEksU0FBUyxLQUFULFNBQVMsUUFHYjtBQUdEO0lBQXNDLDRCQUFZO0lBQWxEOztJQUVBLENBQUM7SUFEUSxrQkFBUyxHQUFHLFNBQVMsQ0FBQztJQURWLFFBQVE7UUFENUIsT0FBTztPQUNhLFFBQVEsQ0FFNUI7SUFBRCxlQUFDO0NBRkQsQUFFQyxDQUZxQyxFQUFFLENBQUMsU0FBUyxHQUVqRDtrQkFGb0IsUUFBUSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHsgY2NjbGFzcyB9ID0gY2MuX2RlY29yYXRvcjtcblxuZW51bSBEaXJlY3Rpb24ge1xuICBVcCxcbiAgRG93bixcbn1cblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFNsb3RFbnVtIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcbiAgc3RhdGljIERpcmVjdGlvbiA9IERpcmVjdGlvbjtcbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/slots/SlotRoller.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6abe1dbO/dPpKL6YIjM54sl', 'SlotRoller');
// scripts/slots/SlotRoller.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SlotRoller = void 0;
var Dice_1 = require("../Dice");
/**
 * Rolls the reels.
 */
var SlotRoller = /** @class */ (function () {
    function SlotRoller() {
    }
    // ====================================================
    // Public
    // ====================================================
    /**
     * Returns results based on a predefined probability list.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.roll = function (tileCount, reelCount) {
        var result = {
            reels: [],
            equalLines: [],
            equalTile: 0
        };
        var roll = Dice_1.Dice.roll(100);
        if (roll < SlotRoller.ROLL_ALL_EQUAL) {
            result = SlotRoller.allLinesResult(tileCount, reelCount);
        }
        else if (roll < SlotRoller.ROLL_TWO_LINES) {
            result = SlotRoller.twoLinesResult(tileCount, reelCount);
        }
        else if (roll < SlotRoller.ROLL_SINGLE_LINE) {
            result = SlotRoller.singleLineResult(tileCount, reelCount);
        }
        else {
            result = SlotRoller.noLinesResult(tileCount, reelCount);
        }
        return result;
    };
    // ====================================================
    // Private
    // ====================================================
    /**
     * Creates an empty matrix of a given size.
     * @param reelCount Column count.
     */
    SlotRoller.createEmptyMatrix = function (reelCount) {
        var result = [];
        for (var j = 0; j < reelCount; j++) {
            result.push([]);
        }
        return result;
    };
    /**
     * Generates a line containing at least one different tile.
     * @param reelCount Line length.
     */
    SlotRoller.createUnequalLine = function (tileCount, reelCount) {
        var result = [];
        var uniqueValues = [];
        for (var j = 0; j < reelCount; ++j) {
            result[j] = Dice_1.Dice.roll(tileCount);
            if (!uniqueValues.includes(result[j])) {
                uniqueValues.push(result[j]);
            }
        }
        if (uniqueValues.length <= 1) {
            var differentPosition = Dice_1.Dice.roll(length);
            var differentValue = Dice_1.Dice.rollDifferent(reelCount, uniqueValues[0]);
            result[differentPosition] = differentValue;
        }
        return result;
    };
    /**
     * Returns a result according to the following condition:
     *  - All lines are SOLELY composed by THE SAME tile.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.allLinesResult = function (tileCount, reelCount) {
        var result = {
            reels: SlotRoller.createEmptyMatrix(reelCount),
            equalLines: [],
            equalTile: Dice_1.Dice.roll(tileCount)
        };
        // Saves equal lines
        for (var i = 0; i < this.REEL_LENGTH; ++i) {
            result.equalLines.push(i);
        }
        SlotRoller.populateMatrix(result, tileCount, reelCount);
        return result;
    };
    /**
     * Returns a result according to the following condition:
     *  - All lines contain AT LEAST ONE different tile.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.noLinesResult = function (tileCount, reelCount) {
        var result = {
            reels: SlotRoller.createEmptyMatrix(reelCount),
            equalLines: [],
            equalTile: -1
        };
        SlotRoller.populateMatrix(result, tileCount, reelCount);
        return result;
    };
    /**
     * Returns a result according to the following condition:
     *  - There is one line that contains AT LEAST ONE different tile.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.twoLinesResult = function (tileCount, reelCount) {
        var result = {
            reels: SlotRoller.createEmptyMatrix(reelCount),
            equalLines: [],
            equalTile: Dice_1.Dice.roll(tileCount)
        };
        // Saves equal lines
        var differentLine = Dice_1.Dice.roll(this.REEL_LENGTH);
        for (var i = 0; i < this.REEL_LENGTH; i++) {
            if (i != differentLine) {
                result.equalLines.push(i);
            }
        }
        SlotRoller.populateMatrix(result, tileCount, reelCount);
        return result;
    };
    /**
     * Returns a result according to the following condition:
     * - There is ONLY ONE line whose tiles are all the same.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.singleLineResult = function (tileCount, reelCount) {
        var result = {
            reels: SlotRoller.createEmptyMatrix(reelCount),
            equalLines: [Dice_1.Dice.roll(this.REEL_LENGTH)],
            equalTile: Dice_1.Dice.roll(tileCount)
        };
        SlotRoller.populateMatrix(result, tileCount, reelCount);
        return result;
    };
    /**
     * Populates a tile matrix from an IResult interface.
     * @param result Contains the matrix to edit.
     * @param tileCount Amount of unique tile textures.
     * @param reelCount Amount of vertical rolling lines in this machine.
     */
    SlotRoller.populateMatrix = function (result, tileCount, reelCount) {
        for (var i = 0; i < this.REEL_LENGTH; ++i) {
            if (result.equalLines.includes(i)) {
                for (var j = 0; j < reelCount; ++j) {
                    result.reels[j][i] = result.equalTile;
                }
            }
            else {
                var unequalLine = this.createUnequalLine(tileCount, reelCount);
                for (var j = 0; j < reelCount; ++j) {
                    result.reels[j][i] = unequalLine[j];
                }
            }
        }
    };
    SlotRoller.ROLL_ALL_EQUAL = 7;
    SlotRoller.ROLL_TWO_LINES = 10 + SlotRoller.ROLL_ALL_EQUAL; // 17
    SlotRoller.ROLL_SINGLE_LINE = 33 + SlotRoller.ROLL_TWO_LINES; // 50
    SlotRoller.REEL_LENGTH = 3;
    return SlotRoller;
}());
exports.SlotRoller = SlotRoller;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcc2xvdHNcXFNsb3RSb2xsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0NBQStCO0FBRS9COztHQUVHO0FBQ0g7SUFBQTtJQTJMQSxDQUFDO0lBbkxHLHVEQUF1RDtJQUN2RCxTQUFTO0lBQ1QsdURBQXVEO0lBQ3ZEOzs7O09BSUc7SUFDVyxlQUFJLEdBQWxCLFVBQW1CLFNBQWlCLEVBQUUsU0FBaUI7UUFDbkQsSUFBSSxNQUFNLEdBQUc7WUFDVCxLQUFLLEVBQUUsRUFBRTtZQUNULFVBQVUsRUFBRSxFQUFFO1lBQ2QsU0FBUyxFQUFFLENBQUM7U0FDZixDQUFDO1FBRUYsSUFBTSxJQUFJLEdBQUcsV0FBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM1QixJQUFJLElBQUksR0FBRyxVQUFVLENBQUMsY0FBYyxFQUFFO1lBQ2xDLE1BQU0sR0FBRyxVQUFVLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQztTQUM1RDthQUNJLElBQUksSUFBSSxHQUFHLFVBQVUsQ0FBQyxjQUFjLEVBQUU7WUFDdkMsTUFBTSxHQUFHLFVBQVUsQ0FBQyxjQUFjLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1NBQzVEO2FBQ0ksSUFBSSxJQUFJLEdBQUcsVUFBVSxDQUFDLGdCQUFnQixFQUFFO1lBQ3pDLE1BQU0sR0FBRyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1NBQzlEO2FBQ0k7WUFDRCxNQUFNLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7U0FDM0Q7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBR0QsdURBQXVEO0lBQ3ZELFVBQVU7SUFDVix1REFBdUQ7SUFDdkQ7OztPQUdHO0lBQ1ksNEJBQWlCLEdBQWhDLFVBQWlDLFNBQWlCO1FBQzlDLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQztRQUNoQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2hDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDbkI7UUFDRCxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBRUQ7OztPQUdHO0lBQ1ksNEJBQWlCLEdBQWhDLFVBQWlDLFNBQWlCLEVBQUUsU0FBaUI7UUFDakUsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2hCLElBQUksWUFBWSxHQUFHLEVBQUUsQ0FBQztRQUV0QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ2hDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxXQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ2pDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNuQyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2hDO1NBQ0o7UUFFRCxJQUFHLFlBQVksQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO1lBQ3pCLElBQU0saUJBQWlCLEdBQUcsV0FBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUM1QyxJQUFNLGNBQWMsR0FBRyxXQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN0RSxNQUFNLENBQUMsaUJBQWlCLENBQUMsR0FBRyxjQUFjLENBQUM7U0FDOUM7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDWSx5QkFBYyxHQUE3QixVQUE4QixTQUFpQixFQUFFLFNBQWlCO1FBQzlELElBQUksTUFBTSxHQUFHO1lBQ1QsS0FBSyxFQUFFLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUM7WUFDOUMsVUFBVSxFQUFFLEVBQUU7WUFDZCxTQUFTLEVBQUUsV0FBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7U0FDbEMsQ0FBQztRQUVGLG9CQUFvQjtRQUNwQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUN2QyxNQUFNLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM3QjtRQUVELFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUV4RCxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDWSx3QkFBYSxHQUE1QixVQUE2QixTQUFpQixFQUFFLFNBQWlCO1FBQzdELElBQUksTUFBTSxHQUFHO1lBQ1QsS0FBSyxFQUFFLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUM7WUFDOUMsVUFBVSxFQUFFLEVBQUU7WUFDZCxTQUFTLEVBQUUsQ0FBQyxDQUFDO1NBQ2hCLENBQUM7UUFFRixVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFFeEQsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ1kseUJBQWMsR0FBN0IsVUFBOEIsU0FBaUIsRUFBRSxTQUFpQjtRQUM5RCxJQUFJLE1BQU0sR0FBRztZQUNULEtBQUssRUFBRSxVQUFVLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDO1lBQzlDLFVBQVUsRUFBRSxFQUFFO1lBQ2QsU0FBUyxFQUFFLFdBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1NBQ2xDLENBQUM7UUFFRixvQkFBb0I7UUFDcEIsSUFBTSxhQUFhLEdBQUcsV0FBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDbEQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDdkMsSUFBSSxDQUFDLElBQUksYUFBYSxFQUFFO2dCQUNwQixNQUFNLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM3QjtTQUNKO1FBRUQsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBRXhELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNZLDJCQUFnQixHQUEvQixVQUFnQyxTQUFpQixFQUFFLFNBQWlCO1FBQ2hFLElBQUksTUFBTSxHQUFHO1lBQ1QsS0FBSyxFQUFFLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUM7WUFDOUMsVUFBVSxFQUFFLENBQUMsV0FBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDekMsU0FBUyxFQUFFLFdBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1NBQ2xDLENBQUM7UUFFRixVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFFeEQsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ1kseUJBQWMsR0FBN0IsVUFBOEIsTUFBZSxFQUFFLFNBQWlCLEVBQUUsU0FBaUI7UUFDL0UsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDdkMsSUFBSSxNQUFNLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDL0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDaEMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDO2lCQUN6QzthQUNKO2lCQUNJO2dCQUNELElBQU0sV0FBVyxHQUFrQixJQUFJLENBQUMsaUJBQWlCLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUNoRixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUNoQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDdkM7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQXZMZSx5QkFBYyxHQUFXLENBQUMsQ0FBQztJQUMzQix5QkFBYyxHQUFXLEVBQUUsR0FBRyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUssS0FBSztJQUNsRSwyQkFBZ0IsR0FBVyxFQUFFLEdBQUcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFHLEtBQUs7SUFFbEUsc0JBQVcsR0FBVyxDQUFDLENBQUE7SUFxTDNDLGlCQUFDO0NBM0xELEFBMkxDLElBQUE7QUEzTFksZ0NBQVUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaWNlIH0gZnJvbSBcIi4uL0RpY2VcIjtcblxuLyoqXG4gKiBSb2xscyB0aGUgcmVlbHMuXG4gKi9cbmV4cG9ydCBjbGFzcyBTbG90Um9sbGVyIHtcblxuICAgIHN0YXRpYyByZWFkb25seSBST0xMX0FMTF9FUVVBTDogbnVtYmVyID0gNztcbiAgICBzdGF0aWMgcmVhZG9ubHkgUk9MTF9UV09fTElORVM6IG51bWJlciA9IDEwICsgU2xvdFJvbGxlci5ST0xMX0FMTF9FUVVBTDsgICAgIC8vIDE3XG4gICAgc3RhdGljIHJlYWRvbmx5IFJPTExfU0lOR0xFX0xJTkU6IG51bWJlciA9IDMzICsgU2xvdFJvbGxlci5ST0xMX1RXT19MSU5FUzsgICAvLyA1MFxuXG4gICAgc3RhdGljIHJlYWRvbmx5IFJFRUxfTEVOR1RIOiBudW1iZXIgPSAzXG5cbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgLy8gUHVibGljXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIC8qKlxuICAgICAqIFJldHVybnMgcmVzdWx0cyBiYXNlZCBvbiBhIHByZWRlZmluZWQgcHJvYmFiaWxpdHkgbGlzdC5cbiAgICAgKiBAcGFyYW0gdGlsZUNvdW50IEFtb3VudCBvZiB1bmlxdWUgdGlsZSB0ZXh0dXJlcy5cbiAgICAgKiBAcGFyYW0gcmVlbENvdW50IEFtb3VudCBvZiB2ZXJ0aWNhbCByb2xsaW5nIGxpbmVzIGluIHRoaXMgbWFjaGluZS5cbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHJvbGwodGlsZUNvdW50OiBudW1iZXIsIHJlZWxDb3VudDogbnVtYmVyKTogSVJlc3VsdCB7XG4gICAgICAgIHZhciByZXN1bHQgPSB7XG4gICAgICAgICAgICByZWVsczogW10sXG4gICAgICAgICAgICBlcXVhbExpbmVzOiBbXSxcbiAgICAgICAgICAgIGVxdWFsVGlsZTogMFxuICAgICAgICB9O1xuICAgIFxuICAgICAgICBjb25zdCByb2xsID0gRGljZS5yb2xsKDEwMCk7XG4gICAgICAgIGlmIChyb2xsIDwgU2xvdFJvbGxlci5ST0xMX0FMTF9FUVVBTCkge1xuICAgICAgICAgICAgcmVzdWx0ID0gU2xvdFJvbGxlci5hbGxMaW5lc1Jlc3VsdCh0aWxlQ291bnQsIHJlZWxDb3VudCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAocm9sbCA8IFNsb3RSb2xsZXIuUk9MTF9UV09fTElORVMpIHtcbiAgICAgICAgICAgIHJlc3VsdCA9IFNsb3RSb2xsZXIudHdvTGluZXNSZXN1bHQodGlsZUNvdW50LCByZWVsQ291bnQpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHJvbGwgPCBTbG90Um9sbGVyLlJPTExfU0lOR0xFX0xJTkUpIHtcbiAgICAgICAgICAgIHJlc3VsdCA9IFNsb3RSb2xsZXIuc2luZ2xlTGluZVJlc3VsdCh0aWxlQ291bnQsIHJlZWxDb3VudCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICByZXN1bHQgPSBTbG90Um9sbGVyLm5vTGluZXNSZXN1bHQodGlsZUNvdW50LCByZWVsQ291bnQpO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cblxuXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIC8vIFByaXZhdGVcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBhbiBlbXB0eSBtYXRyaXggb2YgYSBnaXZlbiBzaXplLlxuICAgICAqIEBwYXJhbSByZWVsQ291bnQgQ29sdW1uIGNvdW50LlxuICAgICAqL1xuICAgIHByaXZhdGUgc3RhdGljIGNyZWF0ZUVtcHR5TWF0cml4KHJlZWxDb3VudDogbnVtYmVyKTogQXJyYXk8QXJyYXk8bnVtYmVyPj4ge1xuICAgICAgICB2YXIgcmVzdWx0ID0gW107XG4gICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgcmVlbENvdW50OyBqKyspIHtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKFtdKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdlbmVyYXRlcyBhIGxpbmUgY29udGFpbmluZyBhdCBsZWFzdCBvbmUgZGlmZmVyZW50IHRpbGUuXG4gICAgICogQHBhcmFtIHJlZWxDb3VudCBMaW5lIGxlbmd0aC5cbiAgICAgKi9cbiAgICBwcml2YXRlIHN0YXRpYyBjcmVhdGVVbmVxdWFsTGluZSh0aWxlQ291bnQ6IG51bWJlciwgcmVlbENvdW50OiBudW1iZXIpOiBBcnJheTxudW1iZXI+IHtcbiAgICAgICAgdmFyIHJlc3VsdCA9IFtdO1xuICAgICAgICB2YXIgdW5pcXVlVmFsdWVzID0gW107XG5cbiAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCByZWVsQ291bnQ7ICsraikge1xuICAgICAgICAgICAgcmVzdWx0W2pdID0gRGljZS5yb2xsKHRpbGVDb3VudCk7XG4gICAgICAgICAgICBpZiAoIXVuaXF1ZVZhbHVlcy5pbmNsdWRlcyhyZXN1bHRbal0pKSB7XG4gICAgICAgICAgICAgICAgdW5pcXVlVmFsdWVzLnB1c2gocmVzdWx0W2pdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmKHVuaXF1ZVZhbHVlcy5sZW5ndGggPD0gMSkge1xuICAgICAgICAgICAgY29uc3QgZGlmZmVyZW50UG9zaXRpb24gPSBEaWNlLnJvbGwobGVuZ3RoKTtcbiAgICAgICAgICAgIGNvbnN0IGRpZmZlcmVudFZhbHVlID0gRGljZS5yb2xsRGlmZmVyZW50KHJlZWxDb3VudCwgdW5pcXVlVmFsdWVzWzBdKTtcbiAgICAgICAgICAgIHJlc3VsdFtkaWZmZXJlbnRQb3NpdGlvbl0gPSBkaWZmZXJlbnRWYWx1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyBhIHJlc3VsdCBhY2NvcmRpbmcgdG8gdGhlIGZvbGxvd2luZyBjb25kaXRpb246XG4gICAgICogIC0gQWxsIGxpbmVzIGFyZSBTT0xFTFkgY29tcG9zZWQgYnkgVEhFIFNBTUUgdGlsZS5cbiAgICAgKiBAcGFyYW0gdGlsZUNvdW50IEFtb3VudCBvZiB1bmlxdWUgdGlsZSB0ZXh0dXJlcy5cbiAgICAgKiBAcGFyYW0gcmVlbENvdW50IEFtb3VudCBvZiB2ZXJ0aWNhbCByb2xsaW5nIGxpbmVzIGluIHRoaXMgbWFjaGluZS5cbiAgICAgKi9cbiAgICBwcml2YXRlIHN0YXRpYyBhbGxMaW5lc1Jlc3VsdCh0aWxlQ291bnQ6IG51bWJlciwgcmVlbENvdW50OiBudW1iZXIpOiBJUmVzdWx0IHtcbiAgICAgICAgdmFyIHJlc3VsdCA9IHtcbiAgICAgICAgICAgIHJlZWxzOiBTbG90Um9sbGVyLmNyZWF0ZUVtcHR5TWF0cml4KHJlZWxDb3VudCksXG4gICAgICAgICAgICBlcXVhbExpbmVzOiBbXSxcbiAgICAgICAgICAgIGVxdWFsVGlsZTogRGljZS5yb2xsKHRpbGVDb3VudClcbiAgICAgICAgfTtcbiAgICAgICAgXG4gICAgICAgIC8vIFNhdmVzIGVxdWFsIGxpbmVzXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5SRUVMX0xFTkdUSDsgKytpKSB7XG4gICAgICAgICAgICByZXN1bHQuZXF1YWxMaW5lcy5wdXNoKGkpO1xuICAgICAgICB9XG5cbiAgICAgICAgU2xvdFJvbGxlci5wb3B1bGF0ZU1hdHJpeChyZXN1bHQsIHRpbGVDb3VudCwgcmVlbENvdW50KTtcblxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgYSByZXN1bHQgYWNjb3JkaW5nIHRvIHRoZSBmb2xsb3dpbmcgY29uZGl0aW9uOlxuICAgICAqICAtIEFsbCBsaW5lcyBjb250YWluIEFUIExFQVNUIE9ORSBkaWZmZXJlbnQgdGlsZS5cbiAgICAgKiBAcGFyYW0gdGlsZUNvdW50IEFtb3VudCBvZiB1bmlxdWUgdGlsZSB0ZXh0dXJlcy5cbiAgICAgKiBAcGFyYW0gcmVlbENvdW50IEFtb3VudCBvZiB2ZXJ0aWNhbCByb2xsaW5nIGxpbmVzIGluIHRoaXMgbWFjaGluZS5cbiAgICAgKi9cbiAgICBwcml2YXRlIHN0YXRpYyBub0xpbmVzUmVzdWx0KHRpbGVDb3VudDogbnVtYmVyLCByZWVsQ291bnQ6IG51bWJlcik6IElSZXN1bHQge1xuICAgICAgICB2YXIgcmVzdWx0ID0ge1xuICAgICAgICAgICAgcmVlbHM6IFNsb3RSb2xsZXIuY3JlYXRlRW1wdHlNYXRyaXgocmVlbENvdW50KSxcbiAgICAgICAgICAgIGVxdWFsTGluZXM6IFtdLFxuICAgICAgICAgICAgZXF1YWxUaWxlOiAtMVxuICAgICAgICB9O1xuXG4gICAgICAgIFNsb3RSb2xsZXIucG9wdWxhdGVNYXRyaXgocmVzdWx0LCB0aWxlQ291bnQsIHJlZWxDb3VudCk7XG5cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGEgcmVzdWx0IGFjY29yZGluZyB0byB0aGUgZm9sbG93aW5nIGNvbmRpdGlvbjpcbiAgICAgKiAgLSBUaGVyZSBpcyBvbmUgbGluZSB0aGF0IGNvbnRhaW5zIEFUIExFQVNUIE9ORSBkaWZmZXJlbnQgdGlsZS5cbiAgICAgKiBAcGFyYW0gdGlsZUNvdW50IEFtb3VudCBvZiB1bmlxdWUgdGlsZSB0ZXh0dXJlcy5cbiAgICAgKiBAcGFyYW0gcmVlbENvdW50IEFtb3VudCBvZiB2ZXJ0aWNhbCByb2xsaW5nIGxpbmVzIGluIHRoaXMgbWFjaGluZS5cbiAgICAgKi9cbiAgICBwcml2YXRlIHN0YXRpYyB0d29MaW5lc1Jlc3VsdCh0aWxlQ291bnQ6IG51bWJlciwgcmVlbENvdW50OiBudW1iZXIpOiBJUmVzdWx0IHtcbiAgICAgICAgdmFyIHJlc3VsdCA9IHtcbiAgICAgICAgICAgIHJlZWxzOiBTbG90Um9sbGVyLmNyZWF0ZUVtcHR5TWF0cml4KHJlZWxDb3VudCksXG4gICAgICAgICAgICBlcXVhbExpbmVzOiBbXSxcbiAgICAgICAgICAgIGVxdWFsVGlsZTogRGljZS5yb2xsKHRpbGVDb3VudClcbiAgICAgICAgfTtcblxuICAgICAgICAvLyBTYXZlcyBlcXVhbCBsaW5lc1xuICAgICAgICBjb25zdCBkaWZmZXJlbnRMaW5lID0gRGljZS5yb2xsKHRoaXMuUkVFTF9MRU5HVEgpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuUkVFTF9MRU5HVEg7IGkrKykge1xuICAgICAgICAgICAgaWYgKGkgIT0gZGlmZmVyZW50TGluZSkge1xuICAgICAgICAgICAgICAgIHJlc3VsdC5lcXVhbExpbmVzLnB1c2goaSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBTbG90Um9sbGVyLnBvcHVsYXRlTWF0cml4KHJlc3VsdCwgdGlsZUNvdW50LCByZWVsQ291bnQpO1xuXG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyBhIHJlc3VsdCBhY2NvcmRpbmcgdG8gdGhlIGZvbGxvd2luZyBjb25kaXRpb246XG4gICAgICogLSBUaGVyZSBpcyBPTkxZIE9ORSBsaW5lIHdob3NlIHRpbGVzIGFyZSBhbGwgdGhlIHNhbWUuXG4gICAgICogQHBhcmFtIHRpbGVDb3VudCBBbW91bnQgb2YgdW5pcXVlIHRpbGUgdGV4dHVyZXMuXG4gICAgICogQHBhcmFtIHJlZWxDb3VudCBBbW91bnQgb2YgdmVydGljYWwgcm9sbGluZyBsaW5lcyBpbiB0aGlzIG1hY2hpbmUuXG4gICAgICovXG4gICAgcHJpdmF0ZSBzdGF0aWMgc2luZ2xlTGluZVJlc3VsdCh0aWxlQ291bnQ6IG51bWJlciwgcmVlbENvdW50OiBudW1iZXIpOiBJUmVzdWx0IHtcbiAgICAgICAgdmFyIHJlc3VsdCA9IHtcbiAgICAgICAgICAgIHJlZWxzOiBTbG90Um9sbGVyLmNyZWF0ZUVtcHR5TWF0cml4KHJlZWxDb3VudCksXG4gICAgICAgICAgICBlcXVhbExpbmVzOiBbRGljZS5yb2xsKHRoaXMuUkVFTF9MRU5HVEgpXSxcbiAgICAgICAgICAgIGVxdWFsVGlsZTogRGljZS5yb2xsKHRpbGVDb3VudClcbiAgICAgICAgfTtcblxuICAgICAgICBTbG90Um9sbGVyLnBvcHVsYXRlTWF0cml4KHJlc3VsdCwgdGlsZUNvdW50LCByZWVsQ291bnQpO1xuXG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIFxuICAgIC8qKlxuICAgICAqIFBvcHVsYXRlcyBhIHRpbGUgbWF0cml4IGZyb20gYW4gSVJlc3VsdCBpbnRlcmZhY2UuXG4gICAgICogQHBhcmFtIHJlc3VsdCBDb250YWlucyB0aGUgbWF0cml4IHRvIGVkaXQuXG4gICAgICogQHBhcmFtIHRpbGVDb3VudCBBbW91bnQgb2YgdW5pcXVlIHRpbGUgdGV4dHVyZXMuXG4gICAgICogQHBhcmFtIHJlZWxDb3VudCBBbW91bnQgb2YgdmVydGljYWwgcm9sbGluZyBsaW5lcyBpbiB0aGlzIG1hY2hpbmUuXG4gICAgICovXG4gICAgcHJpdmF0ZSBzdGF0aWMgcG9wdWxhdGVNYXRyaXgocmVzdWx0OiBJUmVzdWx0LCB0aWxlQ291bnQ6IG51bWJlciwgcmVlbENvdW50OiBudW1iZXIpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLlJFRUxfTEVOR1RIOyArK2kpIHtcbiAgICAgICAgICAgIGlmIChyZXN1bHQuZXF1YWxMaW5lcy5pbmNsdWRlcyhpKSkge1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgcmVlbENvdW50OyArK2opIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnJlZWxzW2pdW2ldID0gcmVzdWx0LmVxdWFsVGlsZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zdCB1bmVxdWFsTGluZTogQXJyYXk8bnVtYmVyPiA9IHRoaXMuY3JlYXRlVW5lcXVhbExpbmUodGlsZUNvdW50LCByZWVsQ291bnQpO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgcmVlbENvdW50OyArK2opIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnJlZWxzW2pdW2ldID0gdW5lcXVhbExpbmVbal07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSAgIFxuXG59Il19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/slots/Reel.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '91e54zzGJ5Os6qxY73m4+B5', 'Reel');
// scripts/slots/Reel.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var SlotEnum_1 = require("../SlotEnum");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Reel = /** @class */ (function (_super) {
    __extends(Reel, _super);
    function Reel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.reelAnchor = null;
        _this.spinDirection = SlotEnum_1.default.Direction.Down;
        _this.tiles = [];
        _this._tilePrefab = null;
        _this.result = [];
        _this.stopSpinning = false;
        return _this;
    }
    Object.defineProperty(Reel.prototype, "tilePrefab", {
        get: function () {
            return this._tilePrefab;
        },
        set: function (newPrefab) {
            this._tilePrefab = newPrefab;
            this.reelAnchor.removeAllChildren();
            this.tiles = [];
            if (newPrefab !== null) {
                this.createReel();
                this.shuffle();
            }
        },
        enumerable: false,
        configurable: true
    });
    Reel.prototype.createReel = function () {
        var newTile;
        for (var i = 0; i < 5; i += 1) {
            newTile = cc.instantiate(this.tilePrefab);
            this.reelAnchor.addChild(newTile);
            this.tiles[i] = newTile;
        }
    };
    Reel.prototype.shuffle = function () {
        for (var i = 0; i < this.tiles.length; i += 1) {
            this.tiles[i].getComponent('Tile').setRandom();
        }
    };
    Reel.prototype.readyStop = function (newResult) {
        var check = this.spinDirection === SlotEnum_1.default.Direction.Down || newResult == null;
        this.result = check ? newResult : newResult.reverse();
        this.stopSpinning = true;
    };
    Reel.prototype.changeCallback = function (element) {
        if (element === void 0) { element = null; }
        var el = element;
        var dirModifier = this.spinDirection === SlotEnum_1.default.Direction.Down ? -1 : 1;
        if (el.position.y * dirModifier > 288) {
            el.position = cc.v2(0, -288 * dirModifier);
            var pop = null;
            if (this.result != null && this.result.length > 0) {
                pop = this.result.pop();
            }
            if (pop != null && pop >= 0) {
                el.getComponent('Tile').setTile(pop);
            }
            else {
                el.getComponent('Tile').setRandom();
            }
        }
    };
    Reel.prototype.checkEndCallback = function (element) {
        if (element === void 0) { element = null; }
        var el = element;
        if (this.stopSpinning) {
            this.getComponent(cc.AudioSource).play();
            this.doStop(el);
        }
        else {
            this.doSpinning(el);
        }
    };
    Reel.prototype.doSpin = function (windUp) {
        var _this = this;
        this.stopSpinning = false;
        this.reelAnchor.children.forEach(function (element) {
            var dirModifier = _this.spinDirection === SlotEnum_1.default.Direction.Down ? -1 : 1;
            var delay = cc.tween(element).delay(windUp);
            var start = cc.tween(element).by(0.25, { position: cc.v2(0, 144 * dirModifier) }, { easing: 'backIn' });
            var doChange = cc.tween().call(function () { return _this.changeCallback(element); });
            var callSpinning = cc.tween(element).call(function () { return _this.doSpinning(element, 5); });
            delay
                .then(start)
                .then(doChange)
                .then(callSpinning)
                .start();
        });
    };
    Reel.prototype.doSpinning = function (element, times) {
        var _this = this;
        if (element === void 0) { element = null; }
        if (times === void 0) { times = 1; }
        var dirModifier = this.spinDirection === SlotEnum_1.default.Direction.Down ? -1 : 1;
        var move = cc.tween().by(0.04, { position: cc.v2(0, 144 * dirModifier) });
        var doChange = cc.tween().call(function () { return _this.changeCallback(element); });
        var repeat = cc.tween(element).repeat(times, move.then(doChange));
        var checkEnd = cc.tween().call(function () { return _this.checkEndCallback(element); });
        repeat.then(checkEnd).start();
    };
    Reel.prototype.doStop = function (element) {
        var _this = this;
        if (element === void 0) { element = null; }
        var dirModifier = this.spinDirection === SlotEnum_1.default.Direction.Down ? -1 : 1;
        var move = cc.tween(element).by(0.04, { position: cc.v2(0, 144 * dirModifier) });
        var doChange = cc.tween().call(function () { return _this.changeCallback(element); });
        var end = cc.tween().by(0.2, { position: cc.v2(0, 144 * dirModifier) }, { easing: 'bounceOut' });
        move
            .then(doChange)
            .then(move)
            .then(doChange)
            .then(end)
            .then(doChange)
            .start();
    };
    __decorate([
        property({ type: cc.Node })
    ], Reel.prototype, "reelAnchor", void 0);
    __decorate([
        property({ type: cc.Enum(SlotEnum_1.default.Direction) })
    ], Reel.prototype, "spinDirection", void 0);
    __decorate([
        property({ type: [cc.Node], visible: false })
    ], Reel.prototype, "tiles", void 0);
    __decorate([
        property({ type: cc.Prefab })
    ], Reel.prototype, "_tilePrefab", void 0);
    __decorate([
        property({ type: cc.Prefab })
    ], Reel.prototype, "tilePrefab", null);
    Reel = __decorate([
        ccclass
    ], Reel);
    return Reel;
}(cc.Component));
exports.default = Reel;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcc2xvdHNcXFJlZWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsd0NBQThCO0FBRXhCLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQWtDLHdCQUFZO0lBQTlDO1FBQUEscUVBZ0lDO1FBOUhRLGdCQUFVLEdBQUcsSUFBSSxDQUFDO1FBR2xCLG1CQUFhLEdBQUcsa0JBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDO1FBR2xDLFdBQUssR0FBRyxFQUFFLENBQUM7UUFHWixpQkFBVyxHQUFHLElBQUksQ0FBQztRQWtCbEIsWUFBTSxHQUFrQixFQUFFLENBQUM7UUFFNUIsa0JBQVksR0FBRyxLQUFLLENBQUM7O0lBaUc5QixDQUFDO0lBbEhDLHNCQUFJLDRCQUFVO2FBQWQ7WUFDRSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDMUIsQ0FBQzthQUVELFVBQWUsU0FBb0I7WUFDakMsSUFBSSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUM7WUFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1lBQ3BDLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO1lBRWhCLElBQUksU0FBUyxLQUFLLElBQUksRUFBRTtnQkFDdEIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNsQixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDaEI7UUFDSCxDQUFDOzs7T0FYQTtJQWlCRCx5QkFBVSxHQUFWO1FBQ0UsSUFBSSxPQUFnQixDQUFDO1FBQ3JCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUM3QixPQUFPLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDMUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxPQUFPLENBQUM7U0FDekI7SUFDSCxDQUFDO0lBRUQsc0JBQU8sR0FBUDtRQUNFLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzdDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO1NBQ2hEO0lBQ0gsQ0FBQztJQUVELHdCQUFTLEdBQVQsVUFBVSxTQUF3QjtRQUNoQyxJQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxLQUFLLGtCQUFHLENBQUMsU0FBUyxDQUFDLElBQUksSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDO1FBQzdFLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUN0RCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztJQUMzQixDQUFDO0lBRUQsNkJBQWMsR0FBZCxVQUFlLE9BQXVCO1FBQXZCLHdCQUFBLEVBQUEsY0FBdUI7UUFDcEMsSUFBTSxFQUFFLEdBQUcsT0FBTyxDQUFDO1FBQ25CLElBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLEtBQUssa0JBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZFLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsV0FBVyxHQUFHLEdBQUcsRUFBRTtZQUNyQyxFQUFFLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLFdBQVcsQ0FBQyxDQUFDO1lBRTNDLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQztZQUNmLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUNqRCxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQzthQUN6QjtZQUVELElBQUksR0FBRyxJQUFJLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxFQUFFO2dCQUMzQixFQUFFLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUN0QztpQkFBTTtnQkFDTCxFQUFFLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO2FBQ3JDO1NBQ0Y7SUFDSCxDQUFDO0lBRUQsK0JBQWdCLEdBQWhCLFVBQWlCLE9BQXVCO1FBQXZCLHdCQUFBLEVBQUEsY0FBdUI7UUFDdEMsSUFBTSxFQUFFLEdBQUcsT0FBTyxDQUFDO1FBQ25CLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRTtZQUNyQixJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUN6QyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQ2pCO2FBQU07WUFDTCxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQ3JCO0lBQ0gsQ0FBQztJQUVELHFCQUFNLEdBQU4sVUFBTyxNQUFjO1FBQXJCLGlCQWlCQztRQWhCQyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztRQUUxQixJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsVUFBQSxPQUFPO1lBQ3RDLElBQU0sV0FBVyxHQUFHLEtBQUksQ0FBQyxhQUFhLEtBQUssa0JBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRXZFLElBQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzlDLElBQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLEdBQUcsV0FBVyxDQUFDLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1lBQzFHLElBQU0sUUFBUSxHQUFHLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBTSxPQUFBLEtBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEVBQTVCLENBQTRCLENBQUMsQ0FBQztZQUNyRSxJQUFNLFlBQVksR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFNLE9BQUEsS0FBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQTNCLENBQTJCLENBQUMsQ0FBQztZQUUvRSxLQUFLO2lCQUNGLElBQUksQ0FBQyxLQUFLLENBQUM7aUJBQ1gsSUFBSSxDQUFDLFFBQVEsQ0FBQztpQkFDZCxJQUFJLENBQUMsWUFBWSxDQUFDO2lCQUNsQixLQUFLLEVBQUUsQ0FBQztRQUNiLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELHlCQUFVLEdBQVYsVUFBVyxPQUF1QixFQUFFLEtBQVM7UUFBN0MsaUJBU0M7UUFUVSx3QkFBQSxFQUFBLGNBQXVCO1FBQUUsc0JBQUEsRUFBQSxTQUFTO1FBQzNDLElBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLEtBQUssa0JBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRXZFLElBQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsR0FBRyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDNUUsSUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFNLE9BQUEsS0FBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsRUFBNUIsQ0FBNEIsQ0FBQyxDQUFDO1FBQ3JFLElBQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDcEUsSUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFNLE9BQUEsS0FBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxFQUE5QixDQUE4QixDQUFDLENBQUM7UUFFdkUsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUNoQyxDQUFDO0lBRUQscUJBQU0sR0FBTixVQUFPLE9BQXVCO1FBQTlCLGlCQWNDO1FBZE0sd0JBQUEsRUFBQSxjQUF1QjtRQUM1QixJQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsYUFBYSxLQUFLLGtCQUFHLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV2RSxJQUFNLElBQUksR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxRQUFRLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxHQUFHLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNuRixJQUFNLFFBQVEsR0FBRyxFQUFFLENBQUMsS0FBSyxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQU0sT0FBQSxLQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxFQUE1QixDQUE0QixDQUFDLENBQUM7UUFDckUsSUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxRQUFRLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxHQUFHLFdBQVcsQ0FBQyxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUVuRyxJQUFJO2FBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQzthQUNkLElBQUksQ0FBQyxJQUFJLENBQUM7YUFDVixJQUFJLENBQUMsUUFBUSxDQUFDO2FBQ2QsSUFBSSxDQUFDLEdBQUcsQ0FBQzthQUNULElBQUksQ0FBQyxRQUFRLENBQUM7YUFDZCxLQUFLLEVBQUUsQ0FBQztJQUNiLENBQUM7SUE3SEQ7UUFEQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDOzRDQUNIO0lBR3pCO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsa0JBQUcsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDOytDQUNEO0lBRzFDO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQzt1Q0FDM0I7SUFHbkI7UUFEQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDOzZDQUNKO0lBRzFCO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQzswQ0FHN0I7SUFoQmtCLElBQUk7UUFEeEIsT0FBTztPQUNhLElBQUksQ0FnSXhCO0lBQUQsV0FBQztDQWhJRCxBQWdJQyxDQWhJaUMsRUFBRSxDQUFDLFNBQVMsR0FnSTdDO2tCQWhJb0IsSUFBSSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBBdXggZnJvbSAnLi4vU2xvdEVudW0nO1xuXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVlbCBleHRlbmRzIGNjLkNvbXBvbmVudCB7XG4gIEBwcm9wZXJ0eSh7IHR5cGU6IGNjLk5vZGUgfSlcbiAgcHVibGljIHJlZWxBbmNob3IgPSBudWxsO1xuXG4gIEBwcm9wZXJ0eSh7IHR5cGU6IGNjLkVudW0oQXV4LkRpcmVjdGlvbikgfSlcbiAgcHVibGljIHNwaW5EaXJlY3Rpb24gPSBBdXguRGlyZWN0aW9uLkRvd247XG5cbiAgQHByb3BlcnR5KHsgdHlwZTogW2NjLk5vZGVdLCB2aXNpYmxlOiBmYWxzZSB9KVxuICBwcml2YXRlIHRpbGVzID0gW107XG5cbiAgQHByb3BlcnR5KHsgdHlwZTogY2MuUHJlZmFiIH0pXG4gIHB1YmxpYyBfdGlsZVByZWZhYiA9IG51bGw7XG5cbiAgQHByb3BlcnR5KHsgdHlwZTogY2MuUHJlZmFiIH0pXG4gIGdldCB0aWxlUHJlZmFiKCk6IGNjLlByZWZhYiB7XG4gICAgcmV0dXJuIHRoaXMuX3RpbGVQcmVmYWI7XG4gIH1cblxuICBzZXQgdGlsZVByZWZhYihuZXdQcmVmYWI6IGNjLlByZWZhYikge1xuICAgIHRoaXMuX3RpbGVQcmVmYWIgPSBuZXdQcmVmYWI7XG4gICAgdGhpcy5yZWVsQW5jaG9yLnJlbW92ZUFsbENoaWxkcmVuKCk7XG4gICAgdGhpcy50aWxlcyA9IFtdO1xuXG4gICAgaWYgKG5ld1ByZWZhYiAhPT0gbnVsbCkge1xuICAgICAgdGhpcy5jcmVhdGVSZWVsKCk7XG4gICAgICB0aGlzLnNodWZmbGUoKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHJlc3VsdDogQXJyYXk8bnVtYmVyPiA9IFtdO1xuXG4gIHB1YmxpYyBzdG9wU3Bpbm5pbmcgPSBmYWxzZTtcblxuICBjcmVhdGVSZWVsKCk6IHZvaWQge1xuICAgIGxldCBuZXdUaWxlOiBjYy5Ob2RlO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgNTsgaSArPSAxKSB7XG4gICAgICBuZXdUaWxlID0gY2MuaW5zdGFudGlhdGUodGhpcy50aWxlUHJlZmFiKTtcbiAgICAgIHRoaXMucmVlbEFuY2hvci5hZGRDaGlsZChuZXdUaWxlKTtcbiAgICAgIHRoaXMudGlsZXNbaV0gPSBuZXdUaWxlO1xuICAgIH1cbiAgfVxuXG4gIHNodWZmbGUoKTogdm9pZCB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLnRpbGVzLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgICB0aGlzLnRpbGVzW2ldLmdldENvbXBvbmVudCgnVGlsZScpLnNldFJhbmRvbSgpO1xuICAgIH1cbiAgfVxuXG4gIHJlYWR5U3RvcChuZXdSZXN1bHQ6IEFycmF5PG51bWJlcj4pOiB2b2lkIHtcbiAgICBjb25zdCBjaGVjayA9IHRoaXMuc3BpbkRpcmVjdGlvbiA9PT0gQXV4LkRpcmVjdGlvbi5Eb3duIHx8IG5ld1Jlc3VsdCA9PSBudWxsO1xuICAgIHRoaXMucmVzdWx0ID0gY2hlY2sgPyBuZXdSZXN1bHQgOiBuZXdSZXN1bHQucmV2ZXJzZSgpO1xuICAgIHRoaXMuc3RvcFNwaW5uaW5nID0gdHJ1ZTtcbiAgfVxuXG4gIGNoYW5nZUNhbGxiYWNrKGVsZW1lbnQ6IGNjLk5vZGUgPSBudWxsKTogdm9pZCB7XG4gICAgY29uc3QgZWwgPSBlbGVtZW50O1xuICAgIGNvbnN0IGRpck1vZGlmaWVyID0gdGhpcy5zcGluRGlyZWN0aW9uID09PSBBdXguRGlyZWN0aW9uLkRvd24gPyAtMSA6IDE7XG4gICAgaWYgKGVsLnBvc2l0aW9uLnkgKiBkaXJNb2RpZmllciA+IDI4OCkge1xuICAgICAgZWwucG9zaXRpb24gPSBjYy52MigwLCAtMjg4ICogZGlyTW9kaWZpZXIpO1xuXG4gICAgICBsZXQgcG9wID0gbnVsbDtcbiAgICAgIGlmICh0aGlzLnJlc3VsdCAhPSBudWxsICYmIHRoaXMucmVzdWx0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgcG9wID0gdGhpcy5yZXN1bHQucG9wKCk7XG4gICAgICB9XG5cbiAgICAgIGlmIChwb3AgIT0gbnVsbCAmJiBwb3AgPj0gMCkge1xuICAgICAgICBlbC5nZXRDb21wb25lbnQoJ1RpbGUnKS5zZXRUaWxlKHBvcCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBlbC5nZXRDb21wb25lbnQoJ1RpbGUnKS5zZXRSYW5kb20oKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBjaGVja0VuZENhbGxiYWNrKGVsZW1lbnQ6IGNjLk5vZGUgPSBudWxsKTogdm9pZCB7XG4gICAgY29uc3QgZWwgPSBlbGVtZW50O1xuICAgIGlmICh0aGlzLnN0b3BTcGlubmluZykge1xuICAgICAgdGhpcy5nZXRDb21wb25lbnQoY2MuQXVkaW9Tb3VyY2UpLnBsYXkoKTtcbiAgICAgIHRoaXMuZG9TdG9wKGVsKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5kb1NwaW5uaW5nKGVsKTtcbiAgICB9XG4gIH1cblxuICBkb1NwaW4od2luZFVwOiBudW1iZXIpOiB2b2lkIHtcbiAgICB0aGlzLnN0b3BTcGlubmluZyA9IGZhbHNlO1xuXG4gICAgdGhpcy5yZWVsQW5jaG9yLmNoaWxkcmVuLmZvckVhY2goZWxlbWVudCA9PiB7XG4gICAgICBjb25zdCBkaXJNb2RpZmllciA9IHRoaXMuc3BpbkRpcmVjdGlvbiA9PT0gQXV4LkRpcmVjdGlvbi5Eb3duID8gLTEgOiAxO1xuXG4gICAgICBjb25zdCBkZWxheSA9IGNjLnR3ZWVuKGVsZW1lbnQpLmRlbGF5KHdpbmRVcCk7XG4gICAgICBjb25zdCBzdGFydCA9IGNjLnR3ZWVuKGVsZW1lbnQpLmJ5KDAuMjUsIHsgcG9zaXRpb246IGNjLnYyKDAsIDE0NCAqIGRpck1vZGlmaWVyKSB9LCB7IGVhc2luZzogJ2JhY2tJbicgfSk7XG4gICAgICBjb25zdCBkb0NoYW5nZSA9IGNjLnR3ZWVuKCkuY2FsbCgoKSA9PiB0aGlzLmNoYW5nZUNhbGxiYWNrKGVsZW1lbnQpKTtcbiAgICAgIGNvbnN0IGNhbGxTcGlubmluZyA9IGNjLnR3ZWVuKGVsZW1lbnQpLmNhbGwoKCkgPT4gdGhpcy5kb1NwaW5uaW5nKGVsZW1lbnQsIDUpKTtcblxuICAgICAgZGVsYXlcbiAgICAgICAgLnRoZW4oc3RhcnQpXG4gICAgICAgIC50aGVuKGRvQ2hhbmdlKVxuICAgICAgICAudGhlbihjYWxsU3Bpbm5pbmcpXG4gICAgICAgIC5zdGFydCgpO1xuICAgIH0pO1xuICB9XG5cbiAgZG9TcGlubmluZyhlbGVtZW50OiBjYy5Ob2RlID0gbnVsbCwgdGltZXMgPSAxKTogdm9pZCB7XG4gICAgY29uc3QgZGlyTW9kaWZpZXIgPSB0aGlzLnNwaW5EaXJlY3Rpb24gPT09IEF1eC5EaXJlY3Rpb24uRG93biA/IC0xIDogMTtcblxuICAgIGNvbnN0IG1vdmUgPSBjYy50d2VlbigpLmJ5KDAuMDQsIHsgcG9zaXRpb246IGNjLnYyKDAsIDE0NCAqIGRpck1vZGlmaWVyKSB9KTtcbiAgICBjb25zdCBkb0NoYW5nZSA9IGNjLnR3ZWVuKCkuY2FsbCgoKSA9PiB0aGlzLmNoYW5nZUNhbGxiYWNrKGVsZW1lbnQpKTtcbiAgICBjb25zdCByZXBlYXQgPSBjYy50d2VlbihlbGVtZW50KS5yZXBlYXQodGltZXMsIG1vdmUudGhlbihkb0NoYW5nZSkpO1xuICAgIGNvbnN0IGNoZWNrRW5kID0gY2MudHdlZW4oKS5jYWxsKCgpID0+IHRoaXMuY2hlY2tFbmRDYWxsYmFjayhlbGVtZW50KSk7XG5cbiAgICByZXBlYXQudGhlbihjaGVja0VuZCkuc3RhcnQoKTtcbiAgfVxuXG4gIGRvU3RvcChlbGVtZW50OiBjYy5Ob2RlID0gbnVsbCk6IHZvaWQge1xuICAgIGNvbnN0IGRpck1vZGlmaWVyID0gdGhpcy5zcGluRGlyZWN0aW9uID09PSBBdXguRGlyZWN0aW9uLkRvd24gPyAtMSA6IDE7XG5cbiAgICBjb25zdCBtb3ZlID0gY2MudHdlZW4oZWxlbWVudCkuYnkoMC4wNCwgeyBwb3NpdGlvbjogY2MudjIoMCwgMTQ0ICogZGlyTW9kaWZpZXIpIH0pO1xuICAgIGNvbnN0IGRvQ2hhbmdlID0gY2MudHdlZW4oKS5jYWxsKCgpID0+IHRoaXMuY2hhbmdlQ2FsbGJhY2soZWxlbWVudCkpO1xuICAgIGNvbnN0IGVuZCA9IGNjLnR3ZWVuKCkuYnkoMC4yLCB7IHBvc2l0aW9uOiBjYy52MigwLCAxNDQgKiBkaXJNb2RpZmllcikgfSwgeyBlYXNpbmc6ICdib3VuY2VPdXQnIH0pO1xuXG4gICAgbW92ZVxuICAgICAgLnRoZW4oZG9DaGFuZ2UpXG4gICAgICAudGhlbihtb3ZlKVxuICAgICAgLnRoZW4oZG9DaGFuZ2UpXG4gICAgICAudGhlbihlbmQpXG4gICAgICAudGhlbihkb0NoYW5nZSlcbiAgICAgIC5zdGFydCgpO1xuICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/NetworkLog.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '386b8/9dP1HiJFh4GLZAlPQ', 'NetworkLog');
// scripts/NetworkLog.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NetworkLog = void 0;
var NetworkLog = /** @class */ (function () {
    function NetworkLog() {
    }
    /**
     * Writes a reel-rolling result to history in local storage.
     * @param result The result to write.
     */
    NetworkLog.appendResult = function (result) {
        var xhr = new XMLHttpRequest();
        var url = "https://slot-test-server2.firebaseapp.com/result";
        xhr.open("POST", url, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.setRequestHeader("Accept", "*/*");
        // xhr.onreadystatechange = function () {
        //     if (xhr.readyState === 4 && xhr.status === 200) {
        //     }
        // };
        xhr.send(JSON.stringify(result));
    };
    return NetworkLog;
}());
exports.NetworkLog = NetworkLog;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcTmV0d29ya0xvZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtJQUFBO0lBb0JBLENBQUM7SUFsQkc7OztPQUdHO0lBQ1csdUJBQVksR0FBMUIsVUFBNEIsTUFBZTtRQUN2QyxJQUFJLEdBQUcsR0FBRyxJQUFJLGNBQWMsRUFBRSxDQUFDO1FBQy9CLElBQUksR0FBRyxHQUFHLGtEQUFrRCxDQUFDO1FBQzdELEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUM1QixHQUFHLENBQUMsZ0JBQWdCLENBQUMsY0FBYyxFQUFFLGtCQUFrQixDQUFDLENBQUM7UUFDekQsR0FBRyxDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN0Qyx5Q0FBeUM7UUFDekMsd0RBQXdEO1FBRXhELFFBQVE7UUFDUixLQUFLO1FBQ0wsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVMLGlCQUFDO0FBQUQsQ0FwQkEsQUFvQkMsSUFBQTtBQXBCcUIsZ0NBQVUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgYWJzdHJhY3QgY2xhc3MgTmV0d29ya0xvZyB7XG4gICAgXG4gICAgLyoqXG4gICAgICogV3JpdGVzIGEgcmVlbC1yb2xsaW5nIHJlc3VsdCB0byBoaXN0b3J5IGluIGxvY2FsIHN0b3JhZ2UuXG4gICAgICogQHBhcmFtIHJlc3VsdCBUaGUgcmVzdWx0IHRvIHdyaXRlLlxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgYXBwZW5kUmVzdWx0IChyZXN1bHQ6IElSZXN1bHQpIHtcbiAgICAgICAgdmFyIHhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuICAgICAgICB2YXIgdXJsID0gXCJodHRwczovL3Nsb3QtdGVzdC1zZXJ2ZXIyLmZpcmViYXNlYXBwLmNvbS9yZXN1bHRcIjtcbiAgICAgICAgeGhyLm9wZW4oXCJQT1NUXCIsIHVybCwgdHJ1ZSk7XG4gICAgICAgIHhoci5zZXRSZXF1ZXN0SGVhZGVyKFwiQ29udGVudC1UeXBlXCIsIFwiYXBwbGljYXRpb24vanNvblwiKTtcbiAgICAgICAgeGhyLnNldFJlcXVlc3RIZWFkZXIoXCJBY2NlcHRcIiwgXCIqLypcIik7XG4gICAgICAgIC8vIHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIC8vICAgICBpZiAoeGhyLnJlYWR5U3RhdGUgPT09IDQgJiYgeGhyLnN0YXR1cyA9PT0gMjAwKSB7XG5cbiAgICAgICAgLy8gICAgIH1cbiAgICAgICAgLy8gfTtcbiAgICAgICAgeGhyLnNlbmQoSlNPTi5zdHJpbmdpZnkocmVzdWx0KSk7XG4gICAgfVxuXG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/migration/use_v2.1-2.2.1_cc.Toggle_event.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0fc32FF05VJ2aZgCHs2Eysc', 'use_v2.1-2.2.1_cc.Toggle_event');
// migration/use_v2.1-2.2.1_cc.Toggle_event.js

"use strict";

if (cc.Toggle) {
  cc.Toggle._triggerEventInScript_isChecked = true;
}

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcbWlncmF0aW9uXFx1c2VfdjIuMS0yLjIuMV9jYy5Ub2dnbGVfZXZlbnQuanMiXSwibmFtZXMiOlsiY2MiLCJUb2dnbGUiLCJfdHJpZ2dlckV2ZW50SW5TY3JpcHRfaXNDaGVja2VkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUlBLEVBQUUsQ0FBQ0MsTUFBUCxFQUFlO0FBQ1hELEVBQUFBLEVBQUUsQ0FBQ0MsTUFBSCxDQUFVQywrQkFBVixHQUE0QyxJQUE1QztBQUNIIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpZiAoY2MuVG9nZ2xlKSB7XG4gICAgY2MuVG9nZ2xlLl90cmlnZ2VyRXZlbnRJblNjcmlwdF9pc0NoZWNrZWQgPSB0cnVlO1xufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/GameManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7462271VdFN4J38ivhu1fP1', 'GameManager');
// scripts/GameManager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var SlotRoller_1 = require("./slots/SlotRoller");
var NetworkLog_1 = require("./NetworkLog");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameManager = /** @class */ (function (_super) {
    __extends(GameManager, _super);
    function GameManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // ====================================================
        // Attributes
        // ====================================================
        _this.machine = null;
        _this.audioClick = null;
        _this.block = false;
        _this.result = null;
        _this._reelCount = 0;
        _this._tileCount = 0;
        return _this;
    }
    Object.defineProperty(GameManager.prototype, "reelCount", {
        get: function () {
            if (this._reelCount <= 0) {
                try {
                    this._reelCount = this.machine.getComponent('Machine').numberOfReels;
                }
                catch (error) {
                    this._reelCount = 0;
                }
            }
            return this._reelCount;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(GameManager.prototype, "tileCount", {
        get: function () {
            if (this._tileCount <= 0) {
                try {
                    this._tileCount = this.machine.getChildByName('Reel').getChildByName('In').getChildByName('Tile').getComponent('Tile').tileCount;
                }
                catch (error) {
                    this._tileCount = 0;
                }
            }
            return this._tileCount;
        },
        enumerable: false,
        configurable: true
    });
    // ====================================================
    // Methods
    // ====================================================
    GameManager.prototype.start = function () {
        this.machine.getComponent('Machine').createMachine();
    };
    GameManager.prototype.update = function () {
        if (this.block && this.result != null) {
            this.informStop();
            this.result = null;
        }
    };
    GameManager.prototype.click = function () {
        cc.audioEngine.playEffect(this.audioClick, false);
        if (this.machine.getComponent('Machine').spinning === false) {
            this.block = false;
            this.machine.getComponent('Machine').spin();
            this.requestResult();
        }
        else if (!this.block) {
            this.block = true;
            this.machine.getComponent('Machine').lock();
        }
    };
    GameManager.prototype.requestResult = function () {
        return __awaiter(this, void 0, Promise, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        this.result = null;
                        _a = this;
                        return [4 /*yield*/, this.getAnswer()];
                    case 1:
                        _a.result = _b.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    GameManager.prototype.getAnswer = function () {
        var _this = this;
        return new Promise(function (resolve) {
            setTimeout(function () {
                var result = SlotRoller_1.SlotRoller.roll(_this.tileCount, _this.reelCount);
                resolve(result);
                NetworkLog_1.NetworkLog.appendResult(result);
            }, 1000 + 500 * Math.random());
        });
    };
    GameManager.prototype.informStop = function () {
        this.machine.getComponent('Machine').stop(this.result);
    };
    __decorate([
        property(cc.Node)
    ], GameManager.prototype, "machine", void 0);
    __decorate([
        property({ type: cc.AudioClip })
    ], GameManager.prototype, "audioClick", void 0);
    GameManager = __decorate([
        ccclass
    ], GameManager);
    return GameManager;
}(cc.Component));
exports.default = GameManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcR2FtZU1hbmFnZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsaURBQStDO0FBQy9DLDJDQUEwQztBQUVwQyxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUF5QywrQkFBWTtJQUFyRDtRQUFBLHFFQXdGQztRQXRGQyx1REFBdUQ7UUFDdkQsYUFBYTtRQUNiLHVEQUF1RDtRQUV2RCxhQUFPLEdBQVksSUFBSSxDQUFDO1FBR3hCLGdCQUFVLEdBQWlCLElBQUksQ0FBQztRQUV4QixXQUFLLEdBQUcsS0FBSyxDQUFDO1FBQ2QsWUFBTSxHQUFZLElBQUksQ0FBQztRQUV2QixnQkFBVSxHQUFXLENBQUMsQ0FBQztRQWF2QixnQkFBVSxHQUFXLENBQUMsQ0FBQzs7SUE2RGpDLENBQUM7SUF6RUMsc0JBQUksa0NBQVM7YUFBYjtZQUNFLElBQUksSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLEVBQUU7Z0JBQ3hCLElBQUk7b0JBQ0YsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxhQUFhLENBQUM7aUJBQ3RFO2dCQUFDLE9BQU8sS0FBSyxFQUFFO29CQUNkLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO2lCQUNyQjthQUNGO1lBRUQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO1FBQ3pCLENBQUM7OztPQUFBO0lBR0Qsc0JBQUksa0NBQVM7YUFBYjtZQUNFLElBQUksSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLEVBQUU7Z0JBQ3hCLElBQUk7b0JBQ0YsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUM7aUJBQ2xJO2dCQUFDLE9BQU8sS0FBSyxFQUFFO29CQUNkLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO2lCQUNyQjthQUNGO1lBRUQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO1FBQ3pCLENBQUM7OztPQUFBO0lBR0QsdURBQXVEO0lBQ3ZELFVBQVU7SUFDVix1REFBdUQ7SUFDdkQsMkJBQUssR0FBTDtRQUNFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3ZELENBQUM7SUFFRCw0QkFBTSxHQUFOO1FBQ0UsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxFQUFFO1lBQ3JDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNsQixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztTQUNwQjtJQUNILENBQUM7SUFFRCwyQkFBSyxHQUFMO1FBQ0UsRUFBRSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUNsRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsS0FBSyxLQUFLLEVBQUU7WUFDM0QsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7WUFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDNUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1NBQ3RCO2FBQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDdEIsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7WUFDbEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7U0FDN0M7SUFDSCxDQUFDO0lBRUssbUNBQWEsR0FBbkI7dUNBQXVCLE9BQU87Ozs7O3dCQUM1QixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQzt3QkFDbkIsS0FBQSxJQUFJLENBQUE7d0JBQVUscUJBQU0sSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFBOzt3QkFBcEMsR0FBSyxNQUFNLEdBQUcsU0FBc0IsQ0FBQzs7Ozs7S0FDdEM7SUFFRCwrQkFBUyxHQUFUO1FBQUEsaUJBUUM7UUFQQyxPQUFPLElBQUksT0FBTyxDQUFVLFVBQUEsT0FBTztZQUNqQyxVQUFVLENBQUM7Z0JBQ1QsSUFBTSxNQUFNLEdBQVksdUJBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFNBQVMsRUFBRSxLQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ3hFLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDaEIsdUJBQVUsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbEMsQ0FBQyxFQUFFLElBQUksR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDakMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsZ0NBQVUsR0FBVjtRQUNFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDekQsQ0FBQztJQTlFRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO2dEQUNNO0lBR3hCO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQzttREFDRDtJQVRiLFdBQVc7UUFEL0IsT0FBTztPQUNhLFdBQVcsQ0F3Ri9CO0lBQUQsa0JBQUM7Q0F4RkQsQUF3RkMsQ0F4RndDLEVBQUUsQ0FBQyxTQUFTLEdBd0ZwRDtrQkF4Rm9CLFdBQVciLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTbG90Um9sbGVyIH0gZnJvbSBcIi4vc2xvdHMvU2xvdFJvbGxlclwiXG5pbXBvcnQgeyBOZXR3b3JrTG9nIH0gZnJvbSBcIi4vTmV0d29ya0xvZ1wiO1xuXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgR2FtZU1hbmFnZXIgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgLy8gQXR0cmlidXRlc1xuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gIEBwcm9wZXJ0eShjYy5Ob2RlKVxuICBtYWNoaW5lOiBjYy5Ob2RlID0gbnVsbDtcblxuICBAcHJvcGVydHkoeyB0eXBlOiBjYy5BdWRpb0NsaXAgfSlcbiAgYXVkaW9DbGljazogY2MuQXVkaW9DbGlwID0gbnVsbDtcblxuICBwcml2YXRlIGJsb2NrID0gZmFsc2U7XG4gIHByaXZhdGUgcmVzdWx0OiBJUmVzdWx0ID0gbnVsbDtcbiAgXG4gIHByaXZhdGUgX3JlZWxDb3VudDogbnVtYmVyID0gMDtcbiAgZ2V0IHJlZWxDb3VudCgpOiBudW1iZXIge1xuICAgIGlmICh0aGlzLl9yZWVsQ291bnQgPD0gMCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgdGhpcy5fcmVlbENvdW50ID0gdGhpcy5tYWNoaW5lLmdldENvbXBvbmVudCgnTWFjaGluZScpLm51bWJlck9mUmVlbHM7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aGlzLl9yZWVsQ291bnQgPSAwO1xuICAgICAgfVxuICAgIH1cbiAgICBcbiAgICByZXR1cm4gdGhpcy5fcmVlbENvdW50O1xuICB9XG4gIFxuICBwcml2YXRlIF90aWxlQ291bnQ6IG51bWJlciA9IDA7XG4gIGdldCB0aWxlQ291bnQoKTogbnVtYmVyIHtcbiAgICBpZiAodGhpcy5fdGlsZUNvdW50IDw9IDApIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHRoaXMuX3RpbGVDb3VudCA9IHRoaXMubWFjaGluZS5nZXRDaGlsZEJ5TmFtZSgnUmVlbCcpLmdldENoaWxkQnlOYW1lKCdJbicpLmdldENoaWxkQnlOYW1lKCdUaWxlJykuZ2V0Q29tcG9uZW50KCdUaWxlJykudGlsZUNvdW50O1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhpcy5fdGlsZUNvdW50ID0gMDtcbiAgICAgIH1cbiAgICB9XG4gICAgXG4gICAgcmV0dXJuIHRoaXMuX3RpbGVDb3VudDtcbiAgfVxuXG5cbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAvLyBNZXRob2RzXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgc3RhcnQoKTogdm9pZCB7XG4gICAgdGhpcy5tYWNoaW5lLmdldENvbXBvbmVudCgnTWFjaGluZScpLmNyZWF0ZU1hY2hpbmUoKTtcbiAgfVxuXG4gIHVwZGF0ZSgpOiB2b2lkIHtcbiAgICBpZiAodGhpcy5ibG9jayAmJiB0aGlzLnJlc3VsdCAhPSBudWxsKSB7XG4gICAgICB0aGlzLmluZm9ybVN0b3AoKTtcbiAgICAgIHRoaXMucmVzdWx0ID0gbnVsbDtcbiAgICB9XG4gIH1cblxuICBjbGljaygpOiB2b2lkIHtcbiAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuYXVkaW9DbGljaywgZmFsc2UpO1xuICAgIGlmICh0aGlzLm1hY2hpbmUuZ2V0Q29tcG9uZW50KCdNYWNoaW5lJykuc3Bpbm5pbmcgPT09IGZhbHNlKSB7XG4gICAgICB0aGlzLmJsb2NrID0gZmFsc2U7XG4gICAgICB0aGlzLm1hY2hpbmUuZ2V0Q29tcG9uZW50KCdNYWNoaW5lJykuc3BpbigpO1xuICAgICAgdGhpcy5yZXF1ZXN0UmVzdWx0KCk7XG4gICAgfSBlbHNlIGlmICghdGhpcy5ibG9jaykge1xuICAgICAgdGhpcy5ibG9jayA9IHRydWU7XG4gICAgICB0aGlzLm1hY2hpbmUuZ2V0Q29tcG9uZW50KCdNYWNoaW5lJykubG9jaygpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIHJlcXVlc3RSZXN1bHQoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdGhpcy5yZXN1bHQgPSBudWxsO1xuICAgIHRoaXMucmVzdWx0ID0gYXdhaXQgdGhpcy5nZXRBbnN3ZXIoKTtcbiAgfVxuXG4gIGdldEFuc3dlcigpOiBQcm9taXNlPElSZXN1bHQ+IHtcbiAgICByZXR1cm4gbmV3IFByb21pc2U8SVJlc3VsdD4ocmVzb2x2ZSA9PiB7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgY29uc3QgcmVzdWx0OiBJUmVzdWx0ID0gU2xvdFJvbGxlci5yb2xsKHRoaXMudGlsZUNvdW50LCB0aGlzLnJlZWxDb3VudCk7XG4gICAgICAgIHJlc29sdmUocmVzdWx0KTtcbiAgICAgICAgTmV0d29ya0xvZy5hcHBlbmRSZXN1bHQocmVzdWx0KTtcbiAgICAgIH0sIDEwMDAgKyA1MDAgKiBNYXRoLnJhbmRvbSgpKTtcbiAgICB9KTtcbiAgfVxuXG4gIGluZm9ybVN0b3AoKTogdm9pZCB7XG4gICAgdGhpcy5tYWNoaW5lLmdldENvbXBvbmVudCgnTWFjaGluZScpLnN0b3AodGhpcy5yZXN1bHQpO1xuICB9XG5cbiAgXG5cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/slots/IResult.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e75a2h7DDtBI4eby8Zd9t6q', 'IResult');
// scripts/slots/IResult.ts



cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcc2xvdHNcXElSZXN1bHQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImludGVyZmFjZSBJUmVzdWx0IHtcbiAgICByZWVsczogQXJyYXk8QXJyYXk8bnVtYmVyPj4sXG4gICAgZXF1YWxMaW5lczogQXJyYXk8bnVtYmVyPixcbiAgICBlcXVhbFRpbGU6IG51bWJlclxufSJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/slots/Tile.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '23da8goMpRLyoF0XDrNCKrG', 'Tile');
// scripts/slots/Tile.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Tile = /** @class */ (function (_super) {
    __extends(Tile, _super);
    function Tile() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.textures = [];
        return _this;
    }
    Object.defineProperty(Tile.prototype, "tileCount", {
        get: function () {
            return this.textures.length;
        },
        enumerable: false,
        configurable: true
    });
    Tile.prototype.onLoad = function () {
        return __awaiter(this, void 0, Promise, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadTextures()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    Tile.prototype.resetInEditor = function () {
        return __awaiter(this, void 0, Promise, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadTextures()];
                    case 1:
                        _a.sent();
                        this.setRandom();
                        return [2 /*return*/];
                }
            });
        });
    };
    Tile.prototype.loadTextures = function () {
        return __awaiter(this, void 0, Promise, function () {
            var self;
            return __generator(this, function (_a) {
                self = this;
                return [2 /*return*/, new Promise(function (resolve) {
                        cc.loader.loadResDir('gfx/Square', cc.SpriteFrame, function afterLoad(err, loadedTextures) {
                            self.textures = loadedTextures;
                            resolve(true);
                        });
                    })];
            });
        });
    };
    Tile.prototype.setTile = function (index) {
        this.node.getComponent(cc.Sprite).spriteFrame = this.textures[index];
    };
    Tile.prototype.setRandom = function () {
        var randomIndex = Math.floor(Math.random() * this.textures.length);
        this.setTile(randomIndex);
    };
    __decorate([
        property({ type: [cc.SpriteFrame], visible: true })
    ], Tile.prototype, "textures", void 0);
    Tile = __decorate([
        ccclass
    ], Tile);
    return Tile;
}(cc.Component));
exports.default = Tile;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcc2xvdHNcXFRpbGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQU0sSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFHNUM7SUFBa0Msd0JBQVk7SUFBOUM7UUFBQSxxRUFxQ0M7UUFuQ1MsY0FBUSxHQUFHLEVBQUUsQ0FBQzs7SUFtQ3hCLENBQUM7SUEvQkMsc0JBQUksMkJBQVM7YUFBYjtZQUNFLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7UUFDOUIsQ0FBQzs7O09BQUE7SUFFSyxxQkFBTSxHQUFaO3VDQUFnQixPQUFPOzs7NEJBQ3JCLHFCQUFNLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBQTs7d0JBQXpCLFNBQXlCLENBQUM7Ozs7O0tBQzNCO0lBRUssNEJBQWEsR0FBbkI7dUNBQXVCLE9BQU87Ozs0QkFDNUIscUJBQU0sSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFBOzt3QkFBekIsU0FBeUIsQ0FBQzt3QkFDMUIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDOzs7OztLQUNsQjtJQUVLLDJCQUFZLEdBQWxCO3VDQUFzQixPQUFPOzs7Z0JBQ3JCLElBQUksR0FBRyxJQUFJLENBQUM7Z0JBQ2xCLHNCQUFPLElBQUksT0FBTyxDQUFVLFVBQUEsT0FBTzt3QkFDakMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxXQUFXLEVBQUUsU0FBUyxTQUFTLENBQUMsR0FBRyxFQUFFLGNBQWM7NEJBQ3ZGLElBQUksQ0FBQyxRQUFRLEdBQUcsY0FBYyxDQUFDOzRCQUMvQixPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ2hCLENBQUMsQ0FBQyxDQUFDO29CQUNMLENBQUMsQ0FBQyxFQUFDOzs7S0FDSjtJQUVELHNCQUFPLEdBQVAsVUFBUSxLQUFhO1FBQ25CLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN2RSxDQUFDO0lBRUQsd0JBQVMsR0FBVDtRQUNFLElBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDckUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUM1QixDQUFDO0lBbENEO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FBQzswQ0FDOUI7SUFGSCxJQUFJO1FBRHhCLE9BQU87T0FDYSxJQUFJLENBcUN4QjtJQUFELFdBQUM7Q0FyQ0QsQUFxQ0MsQ0FyQ2lDLEVBQUUsQ0FBQyxTQUFTLEdBcUM3QztrQkFyQ29CLElBQUkiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgVGlsZSBleHRlbmRzIGNjLkNvbXBvbmVudCB7XG4gIEBwcm9wZXJ0eSh7IHR5cGU6IFtjYy5TcHJpdGVGcmFtZV0sIHZpc2libGU6IHRydWUgfSlcbiAgcHJpdmF0ZSB0ZXh0dXJlcyA9IFtdO1xuXG4gIHByaXZhdGUgdGV4dHVyZUNvdW50IDogbnVtYmVyO1xuXG4gIGdldCB0aWxlQ291bnQoKSB7XG4gICAgcmV0dXJuIHRoaXMudGV4dHVyZXMubGVuZ3RoO1xuICB9XG5cbiAgYXN5bmMgb25Mb2FkKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IHRoaXMubG9hZFRleHR1cmVzKCk7XG4gIH1cblxuICBhc3luYyByZXNldEluRWRpdG9yKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IHRoaXMubG9hZFRleHR1cmVzKCk7XG4gICAgdGhpcy5zZXRSYW5kb20oKTtcbiAgfVxuXG4gIGFzeW5jIGxvYWRUZXh0dXJlcygpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICByZXR1cm4gbmV3IFByb21pc2U8Ym9vbGVhbj4ocmVzb2x2ZSA9PiB7XG4gICAgICBjYy5sb2FkZXIubG9hZFJlc0RpcignZ2Z4L1NxdWFyZScsIGNjLlNwcml0ZUZyYW1lLCBmdW5jdGlvbiBhZnRlckxvYWQoZXJyLCBsb2FkZWRUZXh0dXJlcykge1xuICAgICAgICBzZWxmLnRleHR1cmVzID0gbG9hZGVkVGV4dHVyZXM7XG4gICAgICAgIHJlc29sdmUodHJ1ZSk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIHNldFRpbGUoaW5kZXg6IG51bWJlcik6IHZvaWQge1xuICAgIHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSA9IHRoaXMudGV4dHVyZXNbaW5kZXhdO1xuICB9XG5cbiAgc2V0UmFuZG9tKCk6IHZvaWQge1xuICAgIGNvbnN0IHJhbmRvbUluZGV4ID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogdGhpcy50ZXh0dXJlcy5sZW5ndGgpO1xuICAgIHRoaXMuc2V0VGlsZShyYW5kb21JbmRleCk7XG4gIH1cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------
