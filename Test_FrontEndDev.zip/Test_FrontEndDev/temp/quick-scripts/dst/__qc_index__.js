
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/migration/use_reversed_rotateBy');
require('./assets/migration/use_v2.1-2.2.1_cc.Toggle_event');
require('./assets/scripts/Dice');
require('./assets/scripts/GameManager');
require('./assets/scripts/LogGenerator');
require('./assets/scripts/NetworkLog');
require('./assets/scripts/SlotEnum');
require('./assets/scripts/slots/IResult');
require('./assets/scripts/slots/Machine');
require('./assets/scripts/slots/Reel');
require('./assets/scripts/slots/SlotRoller');
require('./assets/scripts/slots/Tile');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();